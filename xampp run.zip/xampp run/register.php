<?php
// Database connection details
$servername = "localhost";
$username = "root"; // default in XAMPP/WAMP
$password = "";     // leave empty if none
$dbname = "form login data";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get form data
$fullname = $_POST['fullname'];
$email = $_POST['email'];
$gender = $_POST['gender'];
$password = $_POST['password'];

// Insert into database
$sql = "INSERT INTO registration (fullname, email, gender, password)
        VALUES ('$fullname', '$email', '$gender', '$password')";

if ($conn->query($sql) === TRUE) {
    echo "Registration successful!";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close connection
$conn->close();
?>