<?php


session_start();
require_once 'config/database.php';
require_once 'check_access.php';

// Check if user is logged in
if(!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Only admin can access business intelligence
if($_SESSION['role'] !== 'admin') {
    $_SESSION['error'] = "⛔ Access Denied! Admin privileges required.";
    header('Location: index.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();

// Get KPIs
$kpis = [];

// Revenue Metrics
$stmt = $db->query("SELECT 
    COALESCE(SUM(total_price), 0) as total_revenue,
    COUNT(*) as total_transactions,
    COALESCE(AVG(total_price), 0) as avg_transaction,
    COUNT(DISTINCT cashier_id) as active_cashiers
    FROM sales WHERE MONTH(sale_date) = MONTH(CURDATE())");
$kpis['revenue'] = $stmt->fetch(PDO::FETCH_ASSOC);

// Product Metrics
$stmt = $db->query("SELECT 
    COUNT(*) as total_products,
    SUM(CASE WHEN quantity < 5 THEN 1 ELSE 0 END) as low_stock,
    SUM(CASE WHEN expiry_date < DATE_ADD(CURDATE(), INTERVAL 7 DAY) THEN 1 ELSE 0 END) as expiring_soon
    FROM products");
$kpis['products'] = $stmt->fetch(PDO::FETCH_ASSOC);

// Employee Metrics
$stmt = $db->query("SELECT 
    COUNT(*) as total_employees,
    SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active_employees,
    (SELECT COUNT(*) FROM attendance WHERE DATE(clock_in) = CURDATE()) as present_today
    FROM employees");
$kpis['employees'] = $stmt->fetch(PDO::FETCH_ASSOC);

// Growth Metrics
$stmt = $db->query("SELECT 
    (SELECT COALESCE(SUM(total_price), 0) FROM sales WHERE MONTH(sale_date) = MONTH(CURDATE())) as current_month,
    (SELECT COALESCE(SUM(total_price), 0) FROM sales WHERE MONTH(sale_date) = MONTH(DATE_SUB(CURDATE(), INTERVAL 1 MONTH))) as last_month");
$growth = $stmt->fetch(PDO::FETCH_ASSOC);
$growth_rate = $growth['last_month'] > 0 ? (($growth['current_month'] - $growth['last_month']) / $growth['last_month']) * 100 : 0;

// Get top products
$top_products = $db->query("SELECT p.name, SUM(s.quantity) as qty_sold, SUM(s.total_price) as revenue
    FROM sales s
    JOIN products p ON s.product_id = p.id
    WHERE MONTH(s.sale_date) = MONTH(CURDATE())
    GROUP BY p.id
    ORDER BY revenue DESC
    LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);

// Get daily sales for chart
$daily_sales = $db->query("SELECT 
    DATE_FORMAT(sale_date, '%Y-%m-%d') as date,
    SUM(total_price) as total
    FROM sales
    WHERE sale_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
    GROUP BY sale_date
    ORDER BY sale_date")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Theophile POS - Business Intelligence</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="dashboard-container">
        <!-- ==================== SIDEBAR - START ==================== -->
    <!-- SIDEBAR - NEW VERSION WITH ALL MENU ITEMS -->
<div class="sidebar">
    <div class="logo">
        <h2><i class="fas fa-cash-register"></i> Theophile</h2>
    </div>
    
    <!-- User Info -->
    <div class="user-info">
        <?php 
        if($_SESSION['role'] === 'admin') {
            echo '<span class="role-badge role-admin"><i class="fas fa-crown"></i> ADMIN</span>';
        } else {
            echo '<span class="role-badge role-cashier"><i class="fas fa-user"></i> CASHIER</span>';
        }
        ?>
        <p><i class="fas fa-user"></i> <?php echo htmlspecialchars($_SESSION['full_name']); ?></p>
        <p><i class="fas fa-building"></i> Branch: 
            <?php
            // Get user's branch
            if(isset($db)) {
                $branch_stmt = $db->prepare("SELECT branch_name FROM branches WHERE id = ?");
                $branch_stmt->execute([$_SESSION['branch_id'] ?? 1]);
                $user_branch = $branch_stmt->fetchColumn();
                echo $user_branch ?: 'Headquarters';
            } else {
                echo 'All Branches';
            }
            ?>
        </p>
    </div>
    
    <!-- Navigation Links -->
    <ul class="nav-links">
        <!-- DASHBOARD -->
        <li>
            <a href="index.php" <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-home"></i> <span>Dashboard</span>
            </a>
        </li>
        
        <!-- PRODUCTS -->
        <li>
            <a href="products.php" <?php echo basename($_SERVER['PHP_SELF']) == 'products.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-box"></i> <span>Products</span>
            </a>
        </li>
        
        <!-- ADMIN ONLY SECTION -->
        <?php if($_SESSION['role'] === 'admin'): ?>
        
        <!-- ===== BRANCH MANAGEMENT ===== -->
        <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
            <span>🏢 BRANCH MANAGEMENT</span>
        </li>
        
        <li>
            <a href="branches.php" <?php echo basename($_SERVER['PHP_SELF']) == 'branches.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-building"></i> <span>Branches</span>
            </a>
        </li>
        
        <!-- ===== SUPPLIER MANAGEMENT ===== -->
        <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
            <span>🤝 SUPPLIER MANAGEMENT</span>
        </li>
        
        <li>
            <a href="suppliers.php" <?php echo basename($_SERVER['PHP_SELF']) == 'suppliers.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-truck"></i> <span>Suppliers</span>
            </a>
        </li>
        
        <li>
            <a href="purchase_orders.php" <?php echo basename($_SERVER['PHP_SELF']) == 'purchase_orders.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-file-invoice"></i> <span>Purchase Orders</span>
            </a>
        </li>
        
        <li>
            <a href="supplier_performance.php" <?php echo basename($_SERVER['PHP_SELF']) == 'supplier_performance.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-chart-line"></i> <span>Supplier Analytics</span>
            </a>
        </li>
        
        <!-- ===== STOCK TRANSFERS ===== -->
        <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
            <span>🔄 STOCK TRANSFERS</span>
        </li>
        
        <li>
            <a href="transfers.php" <?php echo basename($_SERVER['PHP_SELF']) == 'transfers.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-exchange-alt"></i> <span>All Transfers</span>
            </a>
        </li>
        
        <!-- ===== REPORTS ===== -->
        <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
            <span>📊 REPORTS</span>
        </li>
        
        <li>
            <a href="reports.php" <?php echo basename($_SERVER['PHP_SELF']) == 'reports.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-chart-bar"></i> <span>Sales Reports</span>
            </a>
        </li>
        
        <li>
            <a href="tax_reports.php" <?php echo basename($_SERVER['PHP_SELF']) == 'tax_reports.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-percent"></i> <span>Tax Reports</span>
            </a>
        </li>
        
        <li>
            <a href="business_intelligence.php" <?php echo basename($_SERVER['PHP_SELF']) == 'business_intelligence.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-chart-line"></i> <span>Business IQ</span>
            </a>
        </li>
        
        <!-- ===== HR MANAGEMENT ===== -->
        <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
            <span>👥 HR MANAGEMENT</span>
        </li>
        
        <li>
            <a href="employees.php" <?php echo basename($_SERVER['PHP_SELF']) == 'employees.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-users"></i> <span>Employees</span>
            </a>
        </li>
        
        <li>
            <a href="attendance.php" <?php echo basename($_SERVER['PHP_SELF']) == 'attendance.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-clock"></i> <span>Attendance</span>
            </a>
        </li>
        
        <li>
            <a href="payroll.php" <?php echo basename($_SERVER['PHP_SELF']) == 'payroll.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-wallet"></i> <span>Payroll</span>
            </a>
        </li>
        
        <!-- ===== SYSTEM ===== -->
        <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
            <span>⚙️ SYSTEM</span>
        </li>
        
        <li>
            <a href="users.php" <?php echo basename($_SERVER['PHP_SELF']) == 'users.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-users-cog"></i> <span>Users</span>
            </a>
        </li>
        
        <?php endif; ?> <!-- End Admin Only -->
        
        <!-- LOGOUT - Always visible -->
        <li style="margin-top: auto; border-top: 1px solid rgba(255,255,255,0.1); padding-top: 10px;">
            <a href="logout.php">
                <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
            </a>
        </li>
    </ul>
</div>

        <!-- Main Content -->
        <div class="main-content">
            <!-- Header -->
            <div class="header">
                <h1><i class="fas fa-chart-line"></i> Business Intelligence Dashboard</h1>
                <div class="date">
                    <i class="fas fa-calendar-alt"></i> 
                    <?php echo date('l, F j, Y'); ?>
                </div>
            </div>

            <!-- Notifications -->
            <?php if(isset($_SESSION['success'])): ?>
            <div class="notification notification-success show" id="notification">
                <i class="fas fa-check-circle"></i>
                <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
            </div>
            <?php endif; ?>

            <?php if(isset($_SESSION['error'])): ?>
            <div class="notification notification-error show" id="notification">
                <i class="fas fa-exclamation-circle"></i>
                <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
            </div>
            <?php endif; ?>

            <!-- KPI Cards -->
            <div class="stats-container">
                <!-- Revenue Card -->
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-dollar-sign"></i></div>
                    <div class="stat-info">
                        <h3>Revenue (MTD)</h3>
                        <p><?php echo number_format($kpis['revenue']['total_revenue']); ?> RWF</p>
                        <small><?php echo $kpis['revenue']['total_transactions']; ?> transactions</small>
                    </div>
                </div>
                
                <!-- Growth Card -->
                <div class="stat-card">
                    <div class="stat-icon" style="background: <?php echo $growth_rate >= 0 ? 'var(--success)' : 'var(--danger)'; ?>;">
                        <i class="fas fa-chart-line"></i>
                    </div>
                    <div class="stat-info">
                        <h3>Growth Rate</h3>
                        <p style="color: <?php echo $growth_rate >= 0 ? 'var(--success)' : 'var(--danger)'; ?>;">
                            <?php echo round($growth_rate, 2); ?>%
                        </p>
                        <small>vs last month</small>
                    </div>
                </div>
                
                <!-- Average Transaction Card -->
                <div class="stat-card">
                    <div class="stat-icon" style="background: var(--warning);"><i class="fas fa-shopping-basket"></i></div>
                    <div class="stat-info">
                        <h3>Avg Transaction</h3>
                        <p><?php echo number_format($kpis['revenue']['avg_transaction']); ?> RWF</p>
                        <small>Per sale</small>
                    </div>
                </div>
                
                <!-- Low Stock Card -->
                <div class="stat-card">
                    <div class="stat-icon" style="background: var(--primary);"><i class="fas fa-clock"></i></div>
                    <div class="stat-info">
                        <h3>Low Stock Alert</h3>
                        <p class="status-low"><?php echo $kpis['products']['low_stock']; ?> products</p>
                        <small>Need reorder</small>
                    </div>
                </div>
            </div>

            <!-- Charts Row -->
            <div class="grid-2">
                <!-- Sales Trend Chart -->
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-chart-line"></i> 30-Day Sales Trend</h3>
                    </div>
                    <div class="chart-container" style="height: 300px;">
                        <canvas id="salesTrendChart"></canvas>
                    </div>
                </div>

                <!-- Top Products Chart -->
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-chart-pie"></i> Top Products</h3>
                    </div>
                    <div class="chart-container" style="height: 300px;">
                        <canvas id="topProductsChart"></canvas>
                    </div>
                </div>
            </div>

            <!-- Business Health Indicators -->
            <div class="grid-3">
                <!-- Inventory Health -->
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-box"></i> Inventory Health</h3>
                    </div>
                    <div style="padding: 1rem;">
                        <?php 
                        $healthy_stock = $kpis['products']['total_products'] - $kpis['products']['low_stock'];
                        $health_percentage = $kpis['products']['total_products'] > 0 ? round(($healthy_stock / $kpis['products']['total_products']) * 100, 1) : 0;
                        ?>
                        <div style="display: flex; justify-content: space-between; margin-bottom: 0.5rem;">
                            <span>Stock Level</span>
                            <span><?php echo $health_percentage; ?>%</span>
                        </div>
                        <div style="height: 20px; background: #f0f0f0; border-radius: 10px; margin-bottom: 1rem;">
                            <div style="width: <?php echo $health_percentage; ?>%; height: 100%; background: linear-gradient(90deg, var(--success), var(--primary)); border-radius: 10px;"></div>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <span>Total Products: <strong><?php echo $kpis['products']['total_products']; ?></strong></span>
                            <span>Low Stock: <strong class="status-low"><?php echo $kpis['products']['low_stock']; ?></strong></span>
                            <span>Expiring: <strong class="status-expiring"><?php echo $kpis['products']['expiring_soon']; ?></strong></span>
                        </div>
                    </div>
                </div>

                <!-- Employee Productivity -->
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-users"></i> Staff Productivity</h3>
                    </div>
                    <div style="padding: 1rem;">
                        <?php 
                        $attendance_rate = $kpis['employees']['active_employees'] > 0 ? round(($kpis['employees']['present_today'] / $kpis['employees']['active_employees']) * 100, 1) : 0;
                        ?>
                        <div style="display: flex; justify-content: space-between; margin-bottom: 0.5rem;">
                            <span>Today's Attendance</span>
                            <span><?php echo $attendance_rate; ?>%</span>
                        </div>
                        <div style="height: 20px; background: #f0f0f0; border-radius: 10px; margin-bottom: 1rem;">
                            <div style="width: <?php echo $attendance_rate; ?>%; height: 100%; background: linear-gradient(90deg, var(--primary), var(--success)); border-radius: 10px;"></div>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <span>Active Staff: <strong><?php echo $kpis['employees']['active_employees']; ?></strong></span>
                            <span>Present: <strong class="status-normal"><?php echo $kpis['employees']['present_today']; ?></strong></span>
                            <span>Cashiers: <strong><?php echo $kpis['revenue']['active_cashiers']; ?></strong></span>
                        </div>
                    </div>
                </div>

                <!-- Tax Compliance -->
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-percent"></i> Tax Compliance</h3>
                    </div>
                    <?php
                    $tax_due = $db->query("SELECT COALESCE(SUM(tax_amount), 0) as tax_due FROM tax_transactions tt JOIN sales s ON tt.sale_id = s.id WHERE MONTH(s.sale_date) = MONTH(CURDATE())")->fetch()['tax_due'];
                    $total_sales = $kpis['revenue']['total_revenue'];
                    $tax_percentage = $total_sales > 0 ? round(($tax_due / $total_sales) * 100, 2) : 0;
                    ?>
                    <div style="padding: 1rem; text-align: center;">
                        <p style="font-size: 2.5rem; color: var(--warning); font-weight: bold;"><?php echo number_format($tax_due); ?> RWF</p>
                        <p>Tax Due This Month</p>
                        <div style="display: flex; justify-content: center; gap: 2rem; margin-top: 1rem;">
                            <div>
                                <p style="font-size: 1.2rem; color: var(--primary);"><?php echo $tax_percentage; ?>%</p>
                                <small>Effective Rate</small>
                            </div>
                            <div>
                                <p style="font-size: 1.2rem; color: var(--success);"><?php echo number_format($total_sales); ?> RWF</p>
                                <small>Total Sales</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Top Products Table -->
            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-trophy"></i> Top Selling Products (This Month)</h3>
                </div>
                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Quantity Sold</th>
                                <th>Revenue</th>
                                <th>Contribution</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $total_revenue = array_sum(array_column($top_products, 'revenue'));
                            foreach($top_products as $product): 
                                $contribution = $total_revenue > 0 ? round(($product['revenue'] / $total_revenue) * 100, 1) : 0;
                            ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($product['name']); ?></strong></td>
                                <td><?php echo $product['qty_sold']; ?> units</td>
                                <td><?php echo number_format($product['revenue']); ?> RWF</td>
                                <td>
                                    <div style="display: flex; align-items: center; gap: 10px;">
                                        <div style="width: 100px; height: 8px; background: #f0f0f0; border-radius: 4px;">
                                            <div style="width: <?php echo $contribution; ?>%; height: 100%; background: linear-gradient(90deg, var(--primary), var(--success)); border-radius: 4px;"></div>
                                        </div>
                                        <span><?php echo $contribution; ?>%</span>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="assets/js/script.js"></script>
    <script>
        // Sales Trend Chart
        new Chart(document.getElementById('salesTrendChart'), {
            type: 'line',
            data: {
                labels: [<?php foreach($daily_sales as $sale) echo "'" . date('d M', strtotime($sale['date'])) . "',"; ?>],
                datasets: [{
                    label: 'Daily Sales',
                    data: [<?php foreach($daily_sales as $sale) echo $sale['total'] . ","; ?>],
                    borderColor: '#4361ee',
                    backgroundColor: 'rgba(67, 97, 238, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return 'Sales: ' + context.parsed.y.toLocaleString() + ' RWF';
                            }
                        }
                    }
                }
            }
        });

        // Top Products Chart
        new Chart(document.getElementById('topProductsChart'), {
            type: 'doughnut',
            data: {
                labels: [<?php foreach($top_products as $p) echo "'" . $p['name'] . "',"; ?>],
                datasets: [{
                    data: [<?php foreach($top_products as $p) echo $p['revenue'] . ","; ?>],
                    backgroundColor: ['#4361ee', '#4cc9f0', '#f72585', '#f8961e', '#43aa8b']
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });

        // Auto-hide notifications
        setTimeout(() => {
            const notification = document.getElementById('notification');
            if(notification) {
                notification.classList.remove('show');
            }
        }, 3000);
    </script>
</body>
</html>