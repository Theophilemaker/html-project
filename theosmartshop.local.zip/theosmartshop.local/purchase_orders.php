<?php
session_start();
require_once 'config/database.php';
require_once 'check_access.php';

if(!isset($_SESSION['user_id'])) { 
    header('Location: login.php'); 
    exit(); 
}

// Only admin can manage purchase orders
if($_SESSION['role'] !== 'admin') {
    $_SESSION['error'] = "Access Denied!";
    header('Location: index.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();

// Get suppliers for dropdown
$suppliers = $db->query("SELECT id, company_name FROM suppliers ORDER BY company_name")->fetchAll();

// Get branches for dropdown
$branches = $db->query("SELECT id, branch_name FROM branches WHERE is_active = 1 ORDER BY branch_name")->fetchAll();

// Get products for dropdown
$products = $db->query("SELECT id, name, buying_price FROM products ORDER BY name")->fetchAll();

// Handle new purchase order
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_po'])) {
    $po_number = 'PO' . date('Ymd') . str_pad(rand(1,999), 3, '0', STR_PAD_LEFT);
    
    $db->beginTransaction();
    try {
        // Insert PO header
        $stmt = $db->prepare("INSERT INTO purchase_orders (po_number, supplier_id, branch_id, order_date, expected_date, status, subtotal, tax_amount, total_amount, notes, created_by) VALUES (?,?,?,?,?,?,?,?,?,?,?)");
        $stmt->execute([
            $po_number,
            $_POST['supplier_id'],
            $_POST['branch_id'],
            $_POST['order_date'],
            $_POST['expected_date'],
            'sent',
            $_POST['subtotal'],
            $_POST['tax_amount'],
            $_POST['total_amount'],
            $_POST['notes'],
            $_SESSION['user_id']
        ]);
        $po_id = $db->lastInsertId();
        
        // Insert PO items
        $products = json_decode($_POST['products_json'], true);
        $item_stmt = $db->prepare("INSERT INTO po_items (po_id, product_id, quantity, unit_price, total_price) VALUES (?,?,?,?,?)");
        foreach($products as $item) {
            $item_stmt->execute([$po_id, $item['id'], $item['quantity'], $item['price'], $item['total']]);
        }
        
        $db->commit();
        $_SESSION['success'] = "Purchase Order #$po_number created successfully!";
    } catch(Exception $e) {
        $db->rollBack();
        $_SESSION['error'] = "Error creating PO: " . $e->getMessage();
    }
    header('Location: purchase_orders.php');
    exit();
}

// Get all purchase orders
$pos = $db->query("SELECT po.*, s.company_name as supplier, b.branch_name 
    FROM purchase_orders po
    JOIN suppliers s ON po.supplier_id = s.id
    JOIN branches b ON po.branch_id = b.id
    ORDER BY po.created_at DESC")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Theophile POS - Purchase Orders</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .po-card {
            background: white;
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            border-left: 5px solid;
        }
        .po-card:hover {
            transform: translateX(5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.15);
        }
        .status-draft { border-left-color: #999; }
        .status-sent { border-left-color: var(--primary); }
        .status-received { border-left-color: var(--success); }
        .status-cancelled { border-left-color: var(--danger); }
        
        .product-row {
            display: flex;
            gap: 10px;
            margin-bottom: 10px;
            align-items: center;
        }
        .remove-btn {
            background: var(--danger);
            color: white;
            border: none;
            border-radius: 5px;
            width: 30px;
            height: 30px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="logo">
                <h2><i class="fas fa-cash-register"></i> Theophile</h2>
            </div>
            <div class="user-info">
                <span class="role-badge role-admin">ADMIN</span>
                <p><i class="fas fa-user"></i> <?php echo htmlspecialchars($_SESSION['full_name']); ?></p>
            </div>
            <ul class="nav-links">
                <li><a href="index.php"><i class="fas fa-home"></i> <span>Dashboard</span></a></li>
                <li><a href="products.php"><i class="fas fa-box"></i> <span>Products</span></a></li>
                <li><a href="branches.php"><i class="fas fa-building"></i> <span>Branches</span></a></li>
                <li><a href="suppliers.php"><i class="fas fa-truck"></i> <span>Suppliers</span></a></li>
                <li><a href="purchase_orders.php" class="active"><i class="fas fa-file-invoice"></i> <span>Purchase Orders</span></a></li>
                <li><a href="transfers.php"><i class="fas fa-exchange-alt"></i> <span>Transfers</span></a></li>
                <li><a href="reports.php"><i class="fas fa-chart-bar"></i> <span>Reports</span></a></li>
                <li><a href="users.php"><i class="fas fa-users-cog"></i> <span>Users</span></a></li>
                <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> <span>Logout</span></a></li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1><i class="fas fa-file-invoice"></i> Purchase Orders</h1>
                <div class="date">
                    <i class="fas fa-calendar-alt"></i> <?php echo date('l, F j, Y'); ?>
                </div>
            </div>

            <?php if(isset($_SESSION['success'])): ?>
            <div class="notification notification-success show"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
            <?php endif; ?>

            <?php if(isset($_SESSION['error'])): ?>
            <div class="notification notification-error show"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
            <?php endif; ?>

            <!-- New PO Button -->
            <button onclick="showPOForm()" class="btn" style="margin-bottom: 20px;">
                <i class="fas fa-plus-circle"></i> Create Purchase Order
            </button>

            <!-- PO Form -->
            <div id="poForm" class="card" style="display: none; margin-bottom: 20px;">
                <div class="card-header">
                    <h3>Create New Purchase Order</h3>
                    <button onclick="hidePOForm()" class="btn-small" style="background: #999;"><i class="fas fa-times"></i></button>
                </div>
                <form method="POST" id="poFormElement">
                    <div class="grid-2">
                        <div class="form-group">
                            <label>Supplier</label>
                            <select name="supplier_id" class="form-control" required>
                                <option value="">Select Supplier</option>
                                <?php foreach($suppliers as $s): ?>
                                <option value="<?php echo $s['id']; ?>"><?php echo htmlspecialchars($s['company_name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Branch</label>
                            <select name="branch_id" class="form-control" required>
                                <option value="">Select Branch</option>
                                <?php foreach($branches as $b): ?>
                                <option value="<?php echo $b['id']; ?>"><?php echo htmlspecialchars($b['branch_name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Order Date</label>
                            <input type="date" name="order_date" class="form-control" value="<?php echo date('Y-m-d'); ?>" required>
                        </div>
                        <div class="form-group">
                            <label>Expected Delivery</label>
                            <input type="date" name="expected_date" class="form-control" value="<?php echo date('Y-m-d', strtotime('+7 days')); ?>" required>
                        </div>
                    </div>

                    <!-- Products Section -->
                    <h4>Products</h4>
                    <div id="products-container">
                        <!-- Products will be added here dynamically -->
                    </div>
                    
                    <button type="button" onclick="addProductRow()" class="btn-small" style="background: var(--primary); margin: 10px 0;">
                        <i class="fas fa-plus"></i> Add Product
                    </button>

                    <!-- Totals -->
                    <div style="margin-top: 20px; padding: 15px; background: #f8f9fa; border-radius: 8px;">
                        <div style="display: flex; justify-content: flex-end; gap: 20px;">
                            <div><strong>Subtotal:</strong> <span id="subtotal">0</span> RWF</div>
                            <div><strong>Tax (16%):</strong> <span id="tax">0</span> RWF</div>
                            <div><strong>Total:</strong> <span id="total">0</span> RWF</div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Notes</label>
                        <textarea name="notes" class="form-control" rows="3"></textarea>
                    </div>

                    <input type="hidden" name="subtotal" id="hidden_subtotal">
                    <input type="hidden" name="tax_amount" id="hidden_tax">
                    <input type="hidden" name="total_amount" id="hidden_total">
                    <input type="hidden" name="products_json" id="products_json">

                    <button type="submit" name="create_po" class="btn" onclick="prepareSubmit()">
                        <i class="fas fa-save"></i> Create Purchase Order
                    </button>
                </form>
            </div>

            <!-- Purchase Orders List -->
            <?php if(empty($pos)): ?>
            <div class="card" style="text-align: center; padding: 40px;">
                <i class="fas fa-file-invoice" style="font-size: 48px; color: #ccc; margin-bottom: 15px;"></i>
                <h3>No Purchase Orders Found</h3>
                <p>Click "Create Purchase Order" to create your first PO.</p>
            </div>
            <?php else: ?>
                <?php foreach($pos as $po): 
                    $statusClass = 'status-' . $po['status'];
                ?>
                <div class="po-card <?php echo $statusClass; ?>">
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <div>
                            <h3 style="margin: 0;">PO #<?php echo $po['po_number']; ?></h3>
                            <p style="color: #666; margin: 5px 0;">
                                <i class="fas fa-building"></i> <?php echo htmlspecialchars($po['supplier']); ?> | 
                                <i class="fas fa-store"></i> <?php echo htmlspecialchars($po['branch_name']); ?> |
                                <i class="fas fa-calendar"></i> <?php echo date('d M Y', strtotime($po['order_date'])); ?>
                            </p>
                        </div>
                        <div style="text-align: right;">
                            <div style="font-size: 1.2rem; font-weight: bold;"><?php echo number_format($po['total_amount']); ?> RWF</div>
                            <span style="padding: 3px 10px; border-radius: 15px; background: <?php 
                                echo $po['status'] == 'received' ? '#d4edda' : ($po['status'] == 'sent' ? '#cce5ff' : '#f8d7da'); 
                            ?>;">
                                <?php echo ucfirst($po['status']); ?>
                            </span>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <script>
        let products = <?php echo json_encode($products); ?>;
        let rowCount = 0;

        function showPOForm() {
            document.getElementById('poForm').style.display = 'block';
            document.getElementById('poForm').scrollIntoView({ behavior: 'smooth' });
            addProductRow();
        }

        function hidePOForm() {
            document.getElementById('poForm').style.display = 'none';
        }

        function addProductRow() {
            let container = document.getElementById('products-container');
            let row = document.createElement('div');
            row.className = 'product-row';
            row.id = 'row_' + rowCount;
            
            row.innerHTML = `
                <select class="form-control" style="flex: 3;" onchange="updatePrice(${rowCount})" id="product_${rowCount}">
                    <option value="">Select Product</option>
                    ${products.map(p => `<option value="${p.id}" data-price="${p.buying_price}">${p.name}</option>`).join('')}
                </select>
                <input type="number" class="form-control" style="flex: 1;" placeholder="Qty" id="qty_${rowCount}" value="1" min="1" onchange="calculateTotal(${rowCount})">
                <input type="text" class="form-control" style="flex: 1;" placeholder="Price" id="price_${rowCount}" readonly>
                <span style="flex: 1; font-weight: bold;" id="total_${rowCount}">0</span>
                <button type="button" class="remove-btn" onclick="removeRow(${rowCount})"><i class="fas fa-times"></i></button>
            `;
            
            container.appendChild(row);
            rowCount++;
        }

        function updatePrice(rowId) {
            let select = document.getElementById('product_' + rowId);
            let priceInput = document.getElementById('price_' + rowId);
            let selected = select.options[select.selectedIndex];
            
            if(selected.value) {
                priceInput.value = selected.dataset.price;
                calculateTotal(rowId);
            }
        }

        function calculateTotal(rowId) {
            let price = document.getElementById('price_' + rowId).value;
            let qty = document.getElementById('qty_' + rowId).value;
            let totalSpan = document.getElementById('total_' + rowId);
            
            let total = price * qty;
            totalSpan.innerHTML = total.toFixed(0);
            
            calculateGrandTotal();
        }

        function calculateGrandTotal() {
            let subtotal = 0;
            for(let i = 0; i < rowCount; i++) {
                let totalSpan = document.getElementById('total_' + i);
                if(totalSpan) {
                    subtotal += parseFloat(totalSpan.innerHTML) || 0;
                }
            }
            
            let tax = subtotal * 0.16;
            let total = subtotal + tax;
            
            document.getElementById('subtotal').innerHTML = subtotal.toFixed(0);
            document.getElementById('tax').innerHTML = tax.toFixed(0);
            document.getElementById('total').innerHTML = total.toFixed(0);
            
            document.getElementById('hidden_subtotal').value = subtotal;
            document.getElementById('hidden_tax').value = tax;
            document.getElementById('hidden_total').value = total;
        }

        function removeRow(rowId) {
            let row = document.getElementById('row_' + rowId);
            if(row) row.remove();
            calculateGrandTotal();
        }

        function prepareSubmit() {
            let items = [];
            for(let i = 0; i < rowCount; i++) {
                let select = document.getElementById('product_' + i);
                let qty = document.getElementById('qty_' + i);
                
                if(select && select.value && qty && qty.value) {
                    items.push({
                        id: select.value,
                        quantity: qty.value,
                        price: document.getElementById('price_' + i).value,
                        total: document.getElementById('total_' + i).innerHTML
                    });
                }
            }
            document.getElementById('products_json').value = JSON.stringify(items);
        }

        setTimeout(() => {
            document.querySelectorAll('.notification').forEach(n => n.classList.remove('show'));
        }, 3000);
    </script>
    <script src="assets/js/script.js"></script>
</body>
</html>