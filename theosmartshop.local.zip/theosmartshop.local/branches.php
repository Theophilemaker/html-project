<?php
session_start();
require_once 'config/database.php';
require_once 'check_access.php';

if(!isset($_SESSION['user_id'])) { 
    header('Location: login.php'); 
    exit(); 
}

// Only admin can manage branches
if($_SESSION['role'] !== 'admin') {
    $_SESSION['error'] = "Access Denied!";
    header('Location: index.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();

// Handle Add Branch
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_branch'])) {
    $branch_code = strtoupper(trim($_POST['branch_code']));
    $branch_name = trim($_POST['branch_name']);
    $location = trim($_POST['location']);
    $phone = trim($_POST['phone']);
    $email = trim($_POST['email']);
    $manager = trim($_POST['manager']);
    $address = trim($_POST['address']);
    $tax_id = trim($_POST['tax_id']);
    
    $stmt = $db->prepare("INSERT INTO branches (branch_code, branch_name, location, phone, email, manager, address, tax_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    if($stmt->execute([$branch_code, $branch_name, $location, $phone, $email, $manager, $address, $tax_id])) {
        $_SESSION['success'] = "Branch added successfully!";
    } else {
        $_SESSION['error'] = "Error adding branch!";
    }
    header('Location: branches.php');
    exit();
}

// Handle Edit Branch
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_branch'])) {
    $branch_id = $_POST['branch_id'];
    $branch_name = trim($_POST['branch_name']);
    $location = trim($_POST['location']);
    $phone = trim($_POST['phone']);
    $email = trim($_POST['email']);
    $manager = trim($_POST['manager']);
    $address = trim($_POST['address']);
    $tax_id = trim($_POST['tax_id']);
    $is_active = isset($_POST['is_active']) ? 1 : 0;
    
    $stmt = $db->prepare("UPDATE branches SET branch_name=?, location=?, phone=?, email=?, manager=?, address=?, tax_id=?, is_active=? WHERE id=?");
    if($stmt->execute([$branch_name, $location, $phone, $email, $manager, $address, $tax_id, $is_active, $branch_id])) {
        $_SESSION['success'] = "Branch updated successfully!";
    } else {
        $_SESSION['error'] = "Error updating branch!";
    }
    header('Location: branches.php');
    exit();
}

// Handle Delete Branch
if(isset($_GET['delete'])) {
    $branch_id = $_GET['delete'];
    
    // Check if branch has products
    $check = $db->prepare("SELECT COUNT(*) FROM products WHERE branch_id = ?");
    $check->execute([$branch_id]);
    $product_count = $check->fetchColumn();
    
    if($product_count > 0) {
        $_SESSION['error'] = "Cannot delete branch with products!";
    } else {
        $stmt = $db->prepare("DELETE FROM branches WHERE id = ?");
        if($stmt->execute([$branch_id])) {
            $_SESSION['success'] = "Branch deleted successfully!";
        } else {
            $_SESSION['error'] = "Error deleting branch!";
        }
    }
    header('Location: branches.php');
    exit();
}

// Get all branches
$branches = $db->query("SELECT b.*, 
    (SELECT COUNT(*) FROM products WHERE branch_id = b.id) as total_products,
    (SELECT COUNT(*) FROM users WHERE branch_id = b.id) as total_users,
    (SELECT COUNT(*) FROM employees WHERE branch_id = b.id) as total_employees,
    (SELECT COALESCE(SUM(total_price),0) FROM sales WHERE branch_id = b.id AND DATE(sale_date) = CURDATE()) as today_sales
    FROM branches b ORDER BY b.id")->fetchAll(PDO::FETCH_ASSOC);

// Get branch for editing
$edit_branch = null;
if(isset($_GET['edit'])) {
    $stmt = $db->prepare("SELECT * FROM branches WHERE id = ?");
    $stmt->execute([$_GET['edit']]);
    $edit_branch = $stmt->fetch(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Theophile POS - Branches</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .branch-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        .branch-card {
            background: white;
            border-radius: 15px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            border-left: 5px solid var(--primary);
            position: relative;
            overflow: hidden;
        }
        .branch-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
        }
        .branch-card::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(67,97,238,0.05) 0%, transparent 70%);
            transition: all 0.5s ease;
        }
        .branch-card:hover::before {
            transform: scale(1.2);
        }
        .branch-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }
        .branch-code {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            padding: 5px 15px;
            border-radius: 20px;
            font-weight: bold;
            font-size: 0.9rem;
        }
        .status-badge {
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: bold;
        }
        .status-active {
            background: #d4edda;
            color: #155724;
        }
        .status-inactive {
            background: #f8d7da;
            color: #721c24;
        }
        .branch-stats {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 10px;
            margin: 15px 0;
            padding: 15px 0;
            border-top: 1px solid #f0f0f0;
            border-bottom: 1px solid #f0f0f0;
        }
        .stat-item {
            text-align: center;
        }
        .stat-value {
            font-size: 1.2rem;
            font-weight: bold;
            color: var(--primary);
        }
        .stat-label {
            font-size: 0.75rem;
            color: #666;
        }
        .action-buttons {
            display: flex;
            gap: 10px;
            margin-top: 15px;
        }
        .action-btn {
            flex: 1;
            padding: 8px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 0.8rem;
            text-align: center;
            text-decoration: none;
            color: white;
            transition: all 0.3s ease;
        }
        .action-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 10px rgba(0,0,0,0.2);
        }
        .btn-view { background: var(--primary); }
        .btn-edit { background: var(--warning); }
        .btn-delete { background: var(--danger); }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="logo">
                <h2><i class="fas fa-cash-register"></i> Theophile</h2>
            </div>
            <div class="user-info">
                <span class="role-badge role-admin">ADMIN</span>
                <p><i class="fas fa-user"></i> <?php echo htmlspecialchars($_SESSION['full_name']); ?></p>
            </div>
            <ul class="nav-links">
                <li><a href="index.php"><i class="fas fa-home"></i> <span>Dashboard</span></a></li>
                <li><a href="products.php"><i class="fas fa-box"></i> <span>Products</span></a></li>
                <li><a href="branches.php" class="active"><i class="fas fa-building"></i> <span>Branches</span></a></li>
                <li><a href="suppliers.php"><i class="fas fa-truck"></i> <span>Suppliers</span></a></li>
                <li><a href="purchase_orders.php"><i class="fas fa-file-invoice"></i> <span>Purchase Orders</span></a></li>
                <li><a href="transfers.php"><i class="fas fa-exchange-alt"></i> <span>Transfers</span></a></li>
                <li><a href="reports.php"><i class="fas fa-chart-bar"></i> <span>Reports</span></a></li>
                <li><a href="users.php"><i class="fas fa-users-cog"></i> <span>Users</span></a></li>
                <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> <span>Logout</span></a></li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1><i class="fas fa-building"></i> Branch Management</h1>
                <div class="date">
                    <i class="fas fa-calendar-alt"></i> <?php echo date('l, F j, Y'); ?>
                </div>
            </div>

            <?php if(isset($_SESSION['success'])): ?>
            <div class="notification notification-success show"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
            <?php endif; ?>

            <?php if(isset($_SESSION['error'])): ?>
            <div class="notification notification-error show"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
            <?php endif; ?>

            <!-- Add Branch Button -->
            <button onclick="showAddForm()" class="btn" style="margin-bottom: 20px;">
                <i class="fas fa-plus-circle"></i> Add New Branch
            </button>

            <!-- Add/Edit Branch Form -->
            <div id="branchForm" class="card" style="display: <?php echo $edit_branch ? 'block' : 'none'; ?>; margin-bottom: 20px;">
                <div class="card-header">
                    <h3><?php echo $edit_branch ? 'Edit Branch' : 'Add New Branch'; ?></h3>
                    <button onclick="hideForm()" class="btn-small" style="background: #999;"><i class="fas fa-times"></i></button>
                </div>
                <form method="POST">
                    <?php if($edit_branch): ?>
                    <input type="hidden" name="branch_id" value="<?php echo $edit_branch['id']; ?>">
                    <?php endif; ?>
                    
                    <div class="grid-3">
                        <div class="form-group">
                            <label>Branch Code</label>
                            <input type="text" name="branch_code" class="form-control" value="<?php echo $edit_branch['branch_code'] ?? ''; ?>" <?php echo $edit_branch ? 'readonly' : 'required'; ?>>
                        </div>
                        <div class="form-group">
                            <label>Branch Name</label>
                            <input type="text" name="branch_name" class="form-control" value="<?php echo $edit_branch['branch_name'] ?? ''; ?>" required>
                        </div>
                        <div class="form-group">
                            <label>Location</label>
                            <input type="text" name="location" class="form-control" value="<?php echo $edit_branch['location'] ?? ''; ?>" required>
                        </div>
                        <div class="form-group">
                            <label>Phone</label>
                            <input type="text" name="phone" class="form-control" value="<?php echo $edit_branch['phone'] ?? ''; ?>" required>
                        </div>
                        <div class="form-group">
                            <label>Email</label>
                            <input type="email" name="email" class="form-control" value="<?php echo $edit_branch['email'] ?? ''; ?>" required>
                        </div>
                        <div class="form-group">
                            <label>Manager</label>
                            <input type="text" name="manager" class="form-control" value="<?php echo $edit_branch['manager'] ?? ''; ?>" required>
                        </div>
                        <div class="form-group">
                            <label>Tax ID</label>
                            <input type="text" name="tax_id" class="form-control" value="<?php echo $edit_branch['tax_id'] ?? ''; ?>">
                        </div>
                        <div class="form-group">
                            <label>Address</label>
                            <textarea name="address" class="form-control" rows="2"><?php echo $edit_branch['address'] ?? ''; ?></textarea>
                        </div>
                        <?php if($edit_branch): ?>
                        <div class="form-group">
                            <label>
                                <input type="checkbox" name="is_active" <?php echo $edit_branch['is_active'] ? 'checked' : ''; ?>> Active Branch
                            </label>
                        </div>
                        <?php endif; ?>
                    </div>
                    
                    <button type="submit" name="<?php echo $edit_branch ? 'edit_branch' : 'add_branch'; ?>" class="btn">
                        <i class="fas fa-save"></i> <?php echo $edit_branch ? 'Update Branch' : 'Save Branch'; ?>
                    </button>
                </form>
            </div>

            <!-- Branches Grid -->
            <?php if(empty($branches)): ?>
            <div class="card" style="text-align: center; padding: 40px;">
                <i class="fas fa-building" style="font-size: 48px; color: #ccc; margin-bottom: 15px;"></i>
                <h3>No Branches Found</h3>
                <p>Click "Add New Branch" to create your first branch.</p>
            </div>
            <?php else: ?>
            <div class="branch-grid">
                <?php foreach($branches as $branch): ?>
                <div class="branch-card">
                    <div class="branch-header">
                        <span class="branch-code"><?php echo $branch['branch_code']; ?></span>
                        <span class="status-badge <?php echo $branch['is_active'] ? 'status-active' : 'status-inactive'; ?>">
                            <?php echo $branch['is_active'] ? 'Active' : 'Inactive'; ?>
                        </span>
                    </div>
                    
                    <h3 style="margin: 0 0 5px 0;"><?php echo htmlspecialchars($branch['branch_name']); ?></h3>
                    <p style="color: #666; margin-bottom: 10px;">
                        <i class="fas fa-map-marker-alt"></i> <?php echo htmlspecialchars($branch['location']); ?><br>
                        <i class="fas fa-phone"></i> <?php echo $branch['phone']; ?><br>
                        <i class="fas fa-envelope"></i> <?php echo $branch['email']; ?><br>
                        <i class="fas fa-user-tie"></i> <?php echo htmlspecialchars($branch['manager']); ?>
                    </p>

                    <div class="branch-stats">
                        <div class="stat-item">
                            <div class="stat-value"><?php echo $branch['total_products']; ?></div>
                            <div class="stat-label">Products</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-value"><?php echo $branch['total_employees']; ?></div>
                            <div class="stat-label">Staff</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-value"><?php echo number_format($branch['today_sales']); ?></div>
                            <div class="stat-label">Today's Sales</div>
                        </div>
                    </div>

                    <div class="action-buttons">
                        <a href="?edit=<?php echo $branch['id']; ?>" class="action-btn btn-edit">
                            <i class="fas fa-edit"></i> Edit
                        </a>
                        <a href="?delete=<?php echo $branch['id']; ?>" class="action-btn btn-delete" onclick="return confirm('Delete this branch?')">
                            <i class="fas fa-trash"></i> Delete
                        </a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <script>
        function showAddForm() {
            document.getElementById('branchForm').style.display = 'block';
            document.getElementById('branchForm').scrollIntoView({ behavior: 'smooth' });
        }
        
        function hideForm() {
            document.getElementById('branchForm').style.display = 'none';
        }
        
        setTimeout(() => {
            document.querySelectorAll('.notification').forEach(n => n.classList.remove('show'));
        }, 3000);
    </script>
    <script src="assets/js/script.js"></script>
</body>
</html>