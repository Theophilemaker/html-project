<?php

session_start();
require_once 'config/database.php';
require_once 'check_access.php';

// Check if user is logged in
if(!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();

$user_role = $_SESSION['role'];
$is_admin = ($user_role === 'admin');
$user_id = $_SESSION['user_id'];

// Get statistics
$stats = [];

// Total Products
$query = "SELECT COUNT(*) as total FROM products";
$stmt = $db->prepare($query);
$stmt->execute();
$stats['total_products'] = $stmt->fetch(PDO::FETCH_ASSOC)['total'];

// Low Stock
$query = "SELECT COUNT(*) as total FROM products WHERE quantity < 5";
$stmt = $db->prepare($query);
$stmt->execute();
$stats['low_stock'] = $stmt->fetch(PDO::FETCH_ASSOC)['total'];

// Expiring Soon
$query = "SELECT COUNT(*) as total FROM products WHERE expiry_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY)";
$stmt = $db->prepare($query);
$stmt->execute();
$stats['expiring'] = $stmt->fetch(PDO::FETCH_ASSOC)['total'];

// Today's Sales (filtered by role)
$cashier_filter = getCashierFilter();
$query = "SELECT COALESCE(SUM(total_price), 0) as total FROM sales WHERE sale_date = CURDATE()" . $cashier_filter;
$stmt = $db->prepare($query);
$stmt->execute();
$stats['today_sales'] = $stmt->fetch(PDO::FETCH_ASSOC)['total'];

// Low Stock Items
$query = "SELECT name, quantity FROM products WHERE quantity < 5 ORDER BY quantity ASC LIMIT 5";
$stmt = $db->prepare($query);
$stmt->execute();
$low_stock_items = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Expiring Soon Items
$query = "SELECT name, DATEDIFF(expiry_date, CURDATE()) as days_left FROM products WHERE expiry_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY) ORDER BY days_left ASC LIMIT 5";
$stmt = $db->prepare($query);
$stmt->execute();
$expiring_items = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Recent Sales (filtered by role)
$query = "SELECT p.name, s.quantity, s.total_price, s.sale_date, u.full_name as cashier 
          FROM sales s 
          JOIN products p ON s.product_id = p.id 
          JOIN users u ON s.cashier_id = u.id
          WHERE 1=1" . getCashierFilter() . "
          ORDER BY s.sale_date DESC, s.created_at DESC 
          LIMIT 5";
$stmt = $db->prepare($query);
$stmt->execute();
$recent_sales = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Products for dropdown (only in stock)
$query = "SELECT id, name, selling_price FROM products WHERE quantity > 0 ORDER BY name";
$stmt = $db->prepare($query);
$stmt->execute();
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Admin-only data
$daily_sales = $monthly_sales = $total_profit = 0;
$top_product = ['name' => 'N/A'];
$top_products = [];
$sales_chart_data = [];

if($is_admin) {
    // Daily Sales
    $query = "SELECT COALESCE(SUM(total_price), 0) as total FROM sales WHERE sale_date = CURDATE()";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $daily_sales = $stmt->fetch(PDO::FETCH_ASSOC)['total'];

    // Monthly Sales
    $query = "SELECT COALESCE(SUM(total_price), 0) as total FROM sales WHERE MONTH(sale_date) = MONTH(CURDATE()) AND YEAR(sale_date) = YEAR(CURDATE())";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $monthly_sales = $stmt->fetch(PDO::FETCH_ASSOC)['total'];

    // Top Product
    $query = "SELECT p.name, SUM(s.quantity) as total_qty 
              FROM sales s 
              JOIN products p ON s.product_id = p.id 
              GROUP BY p.id 
              ORDER BY total_qty DESC 
              LIMIT 1";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $top_product = $stmt->fetch(PDO::FETCH_ASSOC);

    // Total Profit
    $query = "SELECT SUM((p.selling_price - p.buying_price) * s.quantity) as profit 
              FROM sales s 
              JOIN products p ON s.product_id = p.id";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $total_profit = $stmt->fetch(PDO::FETCH_ASSOC)['profit'];

    // Top Selling Products
    $query = "SELECT p.name, SUM(s.quantity) as total_qty, SUM(s.total_price) as total_sales 
              FROM sales s 
              JOIN products p ON s.product_id = p.id 
              GROUP BY p.id 
              ORDER BY total_qty DESC 
              LIMIT 5";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $top_products = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Sales chart data (last 7 days)
    $query = "SELECT DATE_FORMAT(sale_date, '%a') as day, COALESCE(SUM(total_price), 0) as total 
              FROM sales 
              WHERE sale_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) 
              GROUP BY sale_date 
              ORDER BY sale_date";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $sales_chart_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Theophile POS - Dashboard</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <!-- SIDEBAR - NEW VERSION WITH ALL MENU ITEMS -->
<div class="sidebar">
    <div class="logo">
        <h2><i class="fas fa-cash-register"></i> Theophile</h2>
    </div>
    
    <!-- User Info -->
    <div class="user-info">
        <?php 
        if($_SESSION['role'] === 'admin') {
            echo '<span class="role-badge role-admin"><i class="fas fa-crown"></i> ADMIN</span>';
        } else {
            echo '<span class="role-badge role-cashier"><i class="fas fa-user"></i> CASHIER</span>';
        }
        ?>
        <p><i class="fas fa-user"></i> <?php echo htmlspecialchars($_SESSION['full_name']); ?></p>
        <p><i class="fas fa-building"></i> Branch: 
            <?php
            // Get user's branch
            if(isset($db)) {
                $branch_stmt = $db->prepare("SELECT branch_name FROM branches WHERE id = ?");
                $branch_stmt->execute([$_SESSION['branch_id'] ?? 1]);
                $user_branch = $branch_stmt->fetchColumn();
                echo $user_branch ?: 'Headquarters';
            } else {
                echo 'All Branches';
            }
            ?>
        </p>
    </div>
    
    <!-- Navigation Links -->
    <ul class="nav-links">
        <!-- DASHBOARD -->
        <li>
            <a href="index.php" <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-home"></i> <span>Dashboard</span>
            </a>
        </li>
        
        <!-- PRODUCTS -->
        <li>
            <a href="products.php" <?php echo basename($_SERVER['PHP_SELF']) == 'products.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-box"></i> <span>Products</span>
            </a>
        </li>
        
        <!-- ADMIN ONLY SECTION -->
        <?php if($_SESSION['role'] === 'admin'): ?>
        
        <!-- ===== BRANCH MANAGEMENT ===== -->
        <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
            <span>🏢 BRANCH MANAGEMENT</span>
        </li>
        
        <li>
            <a href="branches.php" <?php echo basename($_SERVER['PHP_SELF']) == 'branches.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-building"></i> <span>Branches</span>
            </a>
        </li>
        
        <!-- ===== SUPPLIER MANAGEMENT ===== -->
        <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
            <span>🤝 SUPPLIER MANAGEMENT</span>
        </li>
        
        <li>
            <a href="suppliers.php" <?php echo basename($_SERVER['PHP_SELF']) == 'suppliers.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-truck"></i> <span>Suppliers</span>
            </a>
        </li>
        
        <li>
            <a href="purchase_orders.php" <?php echo basename($_SERVER['PHP_SELF']) == 'purchase_orders.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-file-invoice"></i> <span>Purchase Orders</span>
            </a>
        </li>
        
        <li>
            <a href="supplier_performance.php" <?php echo basename($_SERVER['PHP_SELF']) == 'supplier_performance.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-chart-line"></i> <span>Supplier Analytics</span>
            </a>
        </li>
        
        <!-- ===== STOCK TRANSFERS ===== -->
        <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
            <span>🔄 STOCK TRANSFERS</span>
        </li>
        
        <li>
            <a href="transfers.php" <?php echo basename($_SERVER['PHP_SELF']) == 'transfers.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-exchange-alt"></i> <span>All Transfers</span>
            </a>
        </li>
        
        <!-- ===== REPORTS ===== -->
        <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
            <span>📊 REPORTS</span>
        </li>
        
        <li>
            <a href="reports.php" <?php echo basename($_SERVER['PHP_SELF']) == 'reports.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-chart-bar"></i> <span>Sales Reports</span>
            </a>
        </li>
        
        <li>
            <a href="tax_reports.php" <?php echo basename($_SERVER['PHP_SELF']) == 'tax_reports.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-percent"></i> <span>Tax Reports</span>
            </a>
        </li>
        
        <li>
            <a href="business_intelligence.php" <?php echo basename($_SERVER['PHP_SELF']) == 'business_intelligence.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-chart-line"></i> <span>Business IQ</span>
            </a>
        </li>
        
        <!-- ===== HR MANAGEMENT ===== -->
        <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
            <span>👥 HR MANAGEMENT</span>
        </li>
        
        <li>
            <a href="employees.php" <?php echo basename($_SERVER['PHP_SELF']) == 'employees.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-users"></i> <span>Employees</span>
            </a>
        </li>
        
        <li>
            <a href="attendance.php" <?php echo basename($_SERVER['PHP_SELF']) == 'attendance.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-clock"></i> <span>Attendance</span>
            </a>
        </li>
        
        <li>
            <a href="payroll.php" <?php echo basename($_SERVER['PHP_SELF']) == 'payroll.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-wallet"></i> <span>Payroll</span>
            </a>
        </li>
        
        <!-- ===== SYSTEM ===== -->
        <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
            <span>⚙️ SYSTEM</span>
        </li>
        
        <li>
            <a href="users.php" <?php echo basename($_SERVER['PHP_SELF']) == 'users.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-users-cog"></i> <span>Users</span>
            </a>
        </li>
        
        <?php endif; ?> <!-- End Admin Only -->
        
        <!-- LOGOUT - Always visible -->
        <li style="margin-top: auto; border-top: 1px solid rgba(255,255,255,0.1); padding-top: 10px;">
            <a href="logout.php">
                <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
            </a>
        </li>
    </ul>
</div>

        <!-- Main Content -->
        <div class="main-content">
            <!-- Header -->
            <div class="header">
                <h1><i class="fas fa-tachometer-alt"></i> Dashboard Overview</h1>
                <div class="date">
                    <i class="fas fa-calendar-alt"></i> 
                    <?php echo date('l, F j, Y'); ?>
                </div>
            </div>

            <!-- Notification Area -->
            <?php if(isset($_SESSION['success'])): ?>
            <div class="notification notification-success show" id="notification">
                <i class="fas fa-check-circle"></i>
                <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
            </div>
            <?php endif; ?>

            <?php if(isset($_SESSION['error'])): ?>
            <div class="notification notification-error show" id="notification">
                <i class="fas fa-exclamation-circle"></i>
                <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
            </div>
            <?php endif; ?>

            <!-- Stats Cards -->
            <div class="stats-container">
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-boxes"></i>
                    </div>
                    <div class="stat-info">
                        <h3>Total Products</h3>
                        <p><?php echo $stats['total_products']; ?></p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-exclamation-triangle"></i>
                    </div>
                    <div class="stat-info">
                        <h3>Low Stock</h3>
                        <p class="status-low"><?php echo $stats['low_stock']; ?></p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-hourglass-half"></i>
                    </div>
                    <div class="stat-info">
                        <h3>Expiring Soon</h3>
                        <p class="status-expiring"><?php echo $stats['expiring']; ?></p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-money-bill-wave"></i>
                    </div>
                    <div class="stat-info">
                        <h3>Today's Sales</h3>
                        <p><?php echo number_format($stats['today_sales']); ?> RWF</p>
                    </div>
                </div>
            </div>
            <!-- Tax Summary Card - Add to Dashboard -->
<div class="card" style="margin-bottom: 1.5rem;">
    <div class="card-header">
        <h3><i class="fas fa-calculator" style="color: var(--primary);"></i> Tax Summary (Today)</h3>
        <span class="role-badge role-admin">TAX REPORT</span>
    </div>
    <?php
    // Get today's tax summary
    $stmt = $db->prepare("SELECT 
        COUNT(*) as transactions,
        COALESCE(SUM(subtotal), 0) as total_sales,
        COALESCE(SUM(tax_amount), 0) as total_tax,
        COALESCE(SUM(total_with_tax), 0) as total_with_tax
        FROM tax_transactions tt
        JOIN sales s ON tt.sale_id = s.id
        WHERE s.sale_date = CURDATE()" . getCashierFilter());
    $stmt->execute();
    $tax_today = $stmt->fetch(PDO::FETCH_ASSOC);
    ?>
    <div class="grid-3" style="margin-top: 1rem;">
        <div class="stat-card" style="padding: 1rem;">
            <div class="stat-icon" style="width: 40px; height: 40px;"><i class="fas fa-receipt"></i></div>
            <div class="stat-info"><h3>Subtotal</h3><p style="font-size: 1.2rem;"><?php echo number_format($tax_today['total_sales']); ?> RWF</p></div>
        </div>
        <div class="stat-card" style="padding: 1rem; background: linear-gradient(135deg, #fff5f5 0%, #fff 100%);">
            <div class="stat-icon" style="width: 40px; height: 40px; background: var(--warning);"><i class="fas fa-percent"></i></div>
            <div class="stat-info"><h3>Tax Collected</h3><p style="font-size: 1.2rem; color: var(--warning);"><?php echo number_format($tax_today['total_tax']); ?> RWF</p></div>
        </div>
        <div class="stat-card" style="padding: 1rem;">
            <div class="stat-icon" style="width: 40px; height: 40px; background: var(--success);"><i class="fas fa-hand-holding-usd"></i></div>
            <div class="stat-info"><h3>Total with Tax</h3><p style="font-size: 1.2rem;"><?php echo number_format($tax_today['total_with_tax']); ?> RWF</p></div>
        </div>
    </div>
</div>

<!-- Tax Breakdown Chart -->
<div class="card">
    <div class="card-header">
        <h3><i class="fas fa-chart-pie"></i> Tax Breakdown</h3>
        <select id="taxPeriod" class="form-control" style="width: 150px;">
            <option value="today">Today</option>
            <option value="week">This Week</option>
            <option value="month">This Month</option>
        </select>
    </div>
    <div class="grid-2">
        <div class="chart-container" style="height: 250px;">
            <canvas id="taxPieChart"></canvas>
        </div>
        <div class="chart-container" style="height: 250px;">
            <canvas id="taxBarChart"></canvas>
        </div>
    </div>
</div>

            <!-- Low Stock and Expiring Section -->
            <div class="grid-2">
                <!-- Low Stock Items -->
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-exclamation-triangle" style="color: var(--danger-color);"></i> Low Stock Items</h3>
                        <span class="role-badge role-<?php echo $_SESSION['role']; ?>"><?php echo ucfirst($_SESSION['role']); ?> View</span>
                    </div>
                    <div class="table-container">
                        <table>
                            <thead>
                                <tr>
                                    <th>Product</th>
                                    <th>Quantity</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(empty($low_stock_items)): ?>
                                <tr>
                                    <td colspan="3" style="text-align: center; color: #999;">No low stock items</td>
                                </tr>
                                <?php else: ?>
                                    <?php foreach($low_stock_items as $item): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($item['name']); ?></td>
                                        <td class="status-low"><?php echo $item['quantity']; ?> left</td>
                                        <td><span class="status-low">Critical</span></td>
                                    </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Expiring Soon -->
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-clock" style="color: var(--warning-color);"></i> Expiring Soon</h3>
                        <span class="role-badge role-<?php echo $_SESSION['role']; ?>"><?php echo ucfirst($_SESSION['role']); ?> View</span>
                    </div>
                    <div class="table-container">
                        <table>
                            <thead>
                                <tr>
                                    <th>Product</th>
                                    <th>Days Left</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(empty($expiring_items)): ?>
                                <tr>
                                    <td colspan="3" style="text-align: center; color: #999;">No expiring items</td>
                                </tr>
                                <?php else: ?>
                                    <?php foreach($expiring_items as $item): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($item['name']); ?></td>
                                        <td class="status-expiring"><?php echo $item['days_left']; ?> days</td>
                                        <td><span class="status-expiring">Expiring</span></td>
                                    </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Sales Entry and Recent Sales -->
            <div class="grid-2">
                <!-- Sales Entry Form -->
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-cash-register"></i> New Sale</h3>
                        <span class="role-badge role-<?php echo $_SESSION['role']; ?>"><?php echo ucfirst($_SESSION['role']); ?></span>
                    </div>
                    <form id="salesForm" action="process_sale.php" method="POST">
                        <div class="form-group">
                            <label><i class="fas fa-box"></i> Select Product</label>
                            <select name="product_id" class="form-control" id="productSelect" required>
                                <option value="">-- Choose Product --</option>
                                <?php foreach($products as $product): ?>
                                <option value="<?php echo $product['id']; ?>" data-price="<?php echo $product['selling_price']; ?>">
                                    <?php echo htmlspecialchars($product['name']); ?> - <?php echo number_format($product['selling_price']); ?> RWF
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-sort-numeric-up"></i> Quantity</label>
                            <input type="number" name="quantity" class="form-control" id="quantity" min="1" value="1" required>
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-calculator"></i> Total Price</label>
                            <input type="text" class="form-control" id="totalPrice" readonly value="0 RWF" style="background: #f8f9fa; font-weight: bold;">
                        </div>
                        <button type="submit" class="btn glow-effect" style="width: 100%;">
                            <i class="fas fa-check-circle"></i> Complete Sale
                        </button>
                    </form>
                </div>

                <!-- Recent Sales -->
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-history"></i> Recent Sales</h3>
                        <span class="role-badge role-<?php echo $_SESSION['role']; ?>"><?php echo ucfirst($_SESSION['role']); ?> View</span>
                    </div>
                    <div class="table-container">
                        <table>
                            <thead>
                                <tr>
                                    <th>Product</th>
                                    <th>Qty</th>
                                    <th>Total</th>
                                    <th>Cashier</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(empty($recent_sales)): ?>
                                <tr>
                                    <td colspan="5" style="text-align: center; color: #999;">No recent sales</td>
                                </tr>
                                <?php else: ?>
                                    <?php foreach($recent_sales as $sale): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($sale['name']); ?></td>
                                        <td><?php echo $sale['quantity']; ?></td>
                                        <td><?php echo number_format($sale['total_price']); ?> RWF</td>
                                        <td>
                                            <span class="role-badge role-<?php echo $sale['cashier'] == $_SESSION['full_name'] ? 'cashier' : 'admin'; ?>" style="font-size: 10px;">
                                                <?php echo htmlspecialchars($sale['cashier']); ?>
                                            </span>
                                        </td>
                                        <td><?php echo date('d-m-Y', strtotime($sale['sale_date'])); ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Admin Only Section -->
            <?php if($is_admin): ?>
            <!-- Sales Reports -->
            <div class="grid-3">
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-sun"></i> Daily Sales</h3>
                    </div>
                    <p style="font-size: 2rem; color: var(--primary-color); font-weight: bold;">
                        <?php echo number_format($daily_sales); ?> RWF
                    </p>
                    <small style="color: #999;"><?php echo date('F j, Y'); ?></small>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-calendar-alt"></i> Monthly Sales</h3>
                    </div>
                    <p style="font-size: 2rem; color: var(--primary-color); font-weight: bold;">
                        <?php echo number_format($monthly_sales); ?> RWF
                    </p>
                    <small style="color: #999;"><?php echo date('F Y'); ?></small>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-star"></i> Top Product</h3>
                    </div>
                    <p style="font-size: 2rem; color: var(--primary-color); font-weight: bold;">
                        <?php echo $top_product['name'] ?? 'N/A'; ?>
                    </p>
                    <small style="color: #999;">Best selling item</small>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-chart-line"></i> Total Profit</h3>
                    </div>
                    <p style="font-size: 2rem; color: var(--success-color); font-weight: bold;">
                        <?php echo number_format($total_profit ?? 0); ?> RWF
                    </p>
                    <small style="color: #999;">Overall profit</small>
                </div>
            </div>

            <!-- Sales Chart -->
            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-chart-line"></i> Sales Overview (Last 7 Days)</h3>
                </div>
                <div class="chart-container">
                    <canvas id="salesChart"></canvas>
                </div>
            </div>

            <!-- Top Selling Products -->
            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-trophy"></i> Top Selling Products</h3>
                </div>
                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Quantity Sold</th>
                                <th>Total Sales</th>
                                <th>Performance</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($top_products as $product): ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($product['name']); ?></strong></td>
                                <td><?php echo $product['total_qty']; ?> units</td>
                                <td><?php echo number_format($product['total_sales']); ?> RWF</td>
                                <td>
                                    <div style="width: 100px; height: 5px; background: #f0f0f0; border-radius: 5px;">
                                        <div style="width: <?php echo min(100, ($product['total_qty'] / $top_products[0]['total_qty']) * 100); ?>%; height: 100%; background: linear-gradient(90deg, var(--primary-color), var(--success-color)); border-radius: 5px;"></div>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php else: ?>
            <!-- Cashier Info Message -->
            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-info-circle"></i> Cashier Dashboard</h3>
                </div>
                <div style="text-align: center; padding: 20px;">
                    <i class="fas fa-smile" style="font-size: 48px; color: var(--primary-color); margin-bottom: 15px;"></i>
                    <p style="font-size: 16px; color: #666;">You are logged in as a Cashier. You can process sales and view products.</p>
                    <p style="font-size: 14px; color: #999; margin-top: 10px;">Only admins can view reports, profits, and manage users.</p>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <script src="assets/js/script.js"></script>
    <script>
        <?php if($is_admin && !empty($sales_chart_data)): ?>
        // Sales Chart
        const ctx = document.getElementById('salesChart').getContext('2d');
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: [<?php foreach($sales_chart_data as $data) { echo "'" . $data['day'] . "', "; } ?>],
                datasets: [{
                    label: 'Sales (RWF)',
                    data: [<?php foreach($sales_chart_data as $data) { echo $data['total'] . ", "; } ?>],
                    borderColor: '#4361ee',
                    backgroundColor: 'rgba(67, 97, 238, 0.1)',
                    borderWidth: 3,
                    tension: 0.4,
                    fill: true,
                    pointBackgroundColor: '#4361ee',
                    pointBorderColor: 'white',
                    pointBorderWidth: 2,
                    pointRadius: 5,
                    pointHoverRadius: 8
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return 'Sales: ' + context.parsed.y.toLocaleString() + ' RWF';
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            display: true,
                            color: 'rgba(0, 0, 0, 0.05)'
                        },
                        ticks: {
                            callback: function(value) {
                                return value.toLocaleString() + ' RWF';
                            }
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });
        <?php endif; ?>

        // Calculate total price
        document.getElementById('productSelect').addEventListener('change', calculateTotal);
        document.getElementById('quantity').addEventListener('input', calculateTotal);

        function calculateTotal() {
            const select = document.getElementById('productSelect');
            const quantity = document.getElementById('quantity').value;
            const selectedOption = select.options[select.selectedIndex];
            
            if (selectedOption.value && quantity > 0) {
                const price = selectedOption.dataset.price;
                const total = price * quantity;
                document.getElementById('totalPrice').value = total.toLocaleString() + ' RWF';
            } else {
                document.getElementById('totalPrice').value = '0 RWF';
            }
        }

        // Auto-hide notifications after 3 seconds
        setTimeout(() => {
            const notification = document.getElementById('notification');
            if(notification) {
                notification.classList.remove('show');
            }
        }, 3000);
        // Tax Charts
fetch('get_tax_data.php?period=today')
    .then(response => response.json())
    .then(data => {
        // Tax Pie Chart
        new Chart(document.getElementById('taxPieChart'), {
            type: 'doughnut',
            data: {
                labels: ['Subtotal', 'Tax Collected'],
                datasets: [{
                    data: [data.subtotal, data.tax],
                    backgroundColor: ['#4361ee', '#f8961e'],
                    borderWidth: 0
                }]
            },
            options: {
                cutout: '70%',
                plugins: { legend: { position: 'bottom' } }
            }
        });
        
        // Tax Bar Chart
        new Chart(document.getElementById('taxBarChart'), {
            type: 'bar',
            data: {
                labels: data.dates,
                datasets: [{
                    label: 'Tax Collected',
                    data: data.tax_by_day,
                    backgroundColor: '#f8961e'
                }]
            }
        });
    });
    </script>
</body>
</html>