<?php
// Transfer history component
function renderTransferHistory($db, $transfer_id) {
    $stmt = $db->prepare("SELECT th.*, u.full_name as user_name 
        FROM transfer_history th
        LEFT JOIN users u ON th.user_id = u.id
        WHERE th.transfer_id = ?
        ORDER BY th.created_at ASC");
    $stmt->execute([$transfer_id]);
    $history = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $html = '<div class="transfer-timeline">';
    foreach($history as $event) {
        $html .= '<div class="timeline-item">';
        $html .= '<div class="timeline-date">' . date('M j, Y H:i', strtotime($event['created_at'])) . '</div>';
        $html .= '<div class="timeline-action">' . ucfirst($event['action']);
        if($event['user_name']) {
            $html .= ' by ' . $event['user_name'];
        }
        $html .= '</div>';
        if($event['notes']) {
            $html .= '<div class="timeline-notes">' . nl2br(htmlspecialchars($event['notes'])) . '</div>';
        }
        $html .= '</div>';
    }
    $html .= '</div>';
    
    return $html;
}
?>