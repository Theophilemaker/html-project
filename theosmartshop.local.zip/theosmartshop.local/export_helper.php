<?php

/**
 * Export Helper Functions
 * Include this in pages that need export functionality
 */

function exportToCSV($data, $filename, $headers = []) {
    // Set headers
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    
    // Create output stream
    $output = fopen('php://output', 'w');
    
    // Add UTF-8 BOM for Excel
    fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));
    
    // Add headers if provided
    if(!empty($headers)) {
        fputcsv($output, $headers);
    }
    
    // Add data
    foreach($data as $row) {
        fputcsv($output, $row);
    }
    
    fclose($output);
    exit();
}

function exportToPDF($data, $filename, $title = 'Report') {
    // This would require a PDF library like DOMPDF or TCPDF
    // For now, redirect to CSV as fallback
    header('Location: ' . str_replace('pdf', 'csv', $_SERVER['REQUEST_URI']));
    exit();
}

function getMonthName($monthNumber) {
    $months = [
        1 => 'January', 2 => 'February', 3 => 'March', 4 => 'April',
        5 => 'May', 6 => 'June', 7 => 'July', 8 => 'August',
        9 => 'September', 10 => 'October', 11 => 'November', 12 => 'December'
    ];
    return $months[intval($monthNumber)] ?? 'Unknown';
}
?>