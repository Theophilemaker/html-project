<?php
session_start();
require_once 'config/database.php';
require_once 'check_access.php';

if(!isset($_SESSION['user_id'])) { header('Location: login.php'); exit(); }
checkAdmin();

$database = new Database();
$db = $database->getConnection();

$po_id = $_GET['id'] ?? 0;

// Get PO details
$stmt = $db->prepare("SELECT po.*, s.company_name as supplier, s.phone as supplier_phone, s.email as supplier_email,
    b.branch_name, u.full_name as created_by_name
    FROM purchase_orders po
    JOIN suppliers s ON po.supplier_id = s.id
    JOIN branches b ON po.branch_id = b.id
    LEFT JOIN users u ON po.created_by = u.id
    WHERE po.id = ?");
$stmt->execute([$po_id]);
$po = $stmt->fetch(PDO::FETCH_ASSOC);

if(!$po) {
    $_SESSION['error'] = "Purchase order not found!";
    header('Location: purchase_orders.php');
    exit();
}

// Get PO items
$items = $db->prepare("SELECT poi.*, p.name as product_name 
    FROM po_items poi
    JOIN products p ON poi.product_id = p.id
    WHERE poi.po_id = ?");
$items->execute([$po_id]);
$po_items = $items->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>PO Details - Theophile POS</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .detail-card {
            background: white;
            border-radius: 15px;
            padding: 2rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 1.5rem;
        }
        .status-badge {
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 0.9rem;
            font-weight: bold;
            display: inline-block;
        }
        .status-draft { background: #e0e0e0; color: #666; }
        .status-sent { background: #cce5ff; color: #004085; }
        .status-received { background: #d4edda; color: #155724; }
        .status-cancelled { background: #f8d7da; color: #721c24; }
        .info-row {
            display: flex;
            margin-bottom: 1rem;
            padding: 0.5rem;
            border-bottom: 1px solid #f0f0f0;
        }
        .info-label {
            font-weight: bold;
            width: 150px;
            color: #666;
        }
        .info-value {
            flex: 1;
        }
        .action-buttons {
            display: flex;
            gap: 10px;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
       <!-- SIDEBAR - NEW VERSION WITH ALL MENU ITEMS -->
<div class="sidebar">
    <div class="logo">
        <h2><i class="fas fa-cash-register"></i> Theophile</h2>
    </div>
    
    <!-- User Info -->
    <div class="user-info">
        <?php 
        if($_SESSION['role'] === 'admin') {
            echo '<span class="role-badge role-admin"><i class="fas fa-crown"></i> ADMIN</span>';
        } else {
            echo '<span class="role-badge role-cashier"><i class="fas fa-user"></i> CASHIER</span>';
        }
        ?>
        <p><i class="fas fa-user"></i> <?php echo htmlspecialchars($_SESSION['full_name']); ?></p>
        <p><i class="fas fa-building"></i> Branch: 
            <?php
            // Get user's branch
            if(isset($db)) {
                $branch_stmt = $db->prepare("SELECT branch_name FROM branches WHERE id = ?");
                $branch_stmt->execute([$_SESSION['branch_id'] ?? 1]);
                $user_branch = $branch_stmt->fetchColumn();
                echo $user_branch ?: 'Headquarters';
            } else {
                echo 'All Branches';
            }
            ?>
        </p>
    </div>
    
    <!-- Navigation Links -->
    <ul class="nav-links">
        <!-- DASHBOARD -->
        <li>
            <a href="index.php" <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-home"></i> <span>Dashboard</span>
            </a>
        </li>
        
        <!-- PRODUCTS -->
        <li>
            <a href="products.php" <?php echo basename($_SERVER['PHP_SELF']) == 'products.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-box"></i> <span>Products</span>
            </a>
        </li>
        
        <!-- ADMIN ONLY SECTION -->
        <?php if($_SESSION['role'] === 'admin'): ?>
        
        <!-- ===== BRANCH MANAGEMENT ===== -->
        <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
            <span>🏢 BRANCH MANAGEMENT</span>
        </li>
        
        <li>
            <a href="branches.php" <?php echo basename($_SERVER['PHP_SELF']) == 'branches.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-building"></i> <span>Branches</span>
            </a>
        </li>
        
        <!-- ===== SUPPLIER MANAGEMENT ===== -->
        <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
            <span>🤝 SUPPLIER MANAGEMENT</span>
        </li>
        
        <li>
            <a href="suppliers.php" <?php echo basename($_SERVER['PHP_SELF']) == 'suppliers.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-truck"></i> <span>Suppliers</span>
            </a>
        </li>
        
        <li>
            <a href="purchase_orders.php" <?php echo basename($_SERVER['PHP_SELF']) == 'purchase_orders.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-file-invoice"></i> <span>Purchase Orders</span>
            </a>
        </li>
        
        <li>
            <a href="supplier_performance.php" <?php echo basename($_SERVER['PHP_SELF']) == 'supplier_performance.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-chart-line"></i> <span>Supplier Analytics</span>
            </a>
        </li>
        
        <!-- ===== STOCK TRANSFERS ===== -->
        <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
            <span>🔄 STOCK TRANSFERS</span>
        </li>
        
        <li>
            <a href="transfers.php" <?php echo basename($_SERVER['PHP_SELF']) == 'transfers.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-exchange-alt"></i> <span>All Transfers</span>
            </a>
        </li>
        
        <!-- ===== REPORTS ===== -->
        <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
            <span>📊 REPORTS</span>
        </li>
        
        <li>
            <a href="reports.php" <?php echo basename($_SERVER['PHP_SELF']) == 'reports.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-chart-bar"></i> <span>Sales Reports</span>
            </a>
        </li>
        
        <li>
            <a href="tax_reports.php" <?php echo basename($_SERVER['PHP_SELF']) == 'tax_reports.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-percent"></i> <span>Tax Reports</span>
            </a>
        </li>
        
        <li>
            <a href="business_intelligence.php" <?php echo basename($_SERVER['PHP_SELF']) == 'business_intelligence.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-chart-line"></i> <span>Business IQ</span>
            </a>
        </li>
        
        <!-- ===== HR MANAGEMENT ===== -->
        <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
            <span>👥 HR MANAGEMENT</span>
        </li>
        
        <li>
            <a href="employees.php" <?php echo basename($_SERVER['PHP_SELF']) == 'employees.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-users"></i> <span>Employees</span>
            </a>
        </li>
        
        <li>
            <a href="attendance.php" <?php echo basename($_SERVER['PHP_SELF']) == 'attendance.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-clock"></i> <span>Attendance</span>
            </a>
        </li>
        
        <li>
            <a href="payroll.php" <?php echo basename($_SERVER['PHP_SELF']) == 'payroll.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-wallet"></i> <span>Payroll</span>
            </a>
        </li>
        
        <!-- ===== SYSTEM ===== -->
        <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
            <span>⚙️ SYSTEM</span>
        </li>
        
        <li>
            <a href="users.php" <?php echo basename($_SERVER['PHP_SELF']) == 'users.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-users-cog"></i> <span>Users</span>
            </a>
        </li>
        
        <?php endif; ?> <!-- End Admin Only -->
        
        <!-- LOGOUT - Always visible -->
        <li style="margin-top: auto; border-top: 1px solid rgba(255,255,255,0.1); padding-top: 10px;">
            <a href="logout.php">
                <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
            </a>
        </li>
    </ul>
</div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1><i class="fas fa-file-invoice"></i> Purchase Order Details</h1>
                <div class="date"><?php echo date('l, F j, Y'); ?></div>
            </div>

            <!-- Action Buttons -->
            <div class="action-buttons">
                <a href="purchase_orders.php" class="btn-small" style="background: var(--primary);">
                    <i class="fas fa-arrow-left"></i> Back
                </a>
                <a href="po_pdf.php?id=<?php echo $po_id; ?>" class="btn-small" style="background: var(--success);">
                    <i class="fas fa-file-pdf"></i> Download PDF
                </a>
                <?php if($po['status'] == 'sent'): ?>
                <a href="po_receive.php?id=<?php echo $po_id; ?>" class="btn-small" style="background: var(--warning);">
                    <i class="fas fa-check-circle"></i> Receive Order
                </a>
                <?php endif; ?>
                <?php if($po['status'] == 'draft'): ?>
                <a href="po_edit.php?id=<?php echo $po_id; ?>" class="btn-small" style="background: var(--primary);">
                    <i class="fas fa-edit"></i> Edit
                </a>
                <a href="po_send.php?id=<?php echo $po_id; ?>" class="btn-small" style="background: var(--success);">
                    <i class="fas fa-paper-plane"></i> Send to Supplier
                </a>
                <?php endif; ?>
            </div>

            <!-- PO Header -->
            <div class="detail-card">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                    <h2>PO #<?php echo $po['po_number']; ?></h2>
                    <span class="status-badge status-<?php echo $po['status']; ?>">
                        <?php echo ucfirst($po['status']); ?>
                    </span>
                </div>

                <div class="info-row">
                    <div class="info-label">Order Date:</div>
                    <div class="info-value"><?php echo date('F j, Y', strtotime($po['order_date'])); ?></div>
                </div>
                <div class="info-row">
                    <div class="info-label">Expected Delivery:</div>
                    <div class="info-value"><?php echo date('F j, Y', strtotime($po['expected_date'])); ?></div>
                </div>
                <div class="info-row">
                    <div class="info-label">Supplier:</div>
                    <div class="info-value">
                        <strong><?php echo htmlspecialchars($po['supplier']); ?></strong><br>
                        <small>Phone: <?php echo $po['supplier_phone']; ?> | Email: <?php echo $po['supplier_email']; ?></small>
                    </div>
                </div>
                <div class="info-row">
                    <div class="info-label">Branch:</div>
                    <div class="info-value"><?php echo htmlspecialchars($po['branch_name']); ?></div>
                </div>
                <div class="info-row">
                    <div class="info-label">Created By:</div>
                    <div class="info-value"><?php echo $po['created_by_name'] ?? 'System'; ?></div>
                </div>
                <?php if($po['notes']): ?>
                <div class="info-row">
                    <div class="info-label">Notes:</div>
                    <div class="info-value"><?php echo nl2br(htmlspecialchars($po['notes'])); ?></div>
                </div>
                <?php endif; ?>
            </div>

            <!-- PO Items -->
            <div class="detail-card">
                <h3>Order Items</h3>
                <table>
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>Quantity</th>
                            <th>Unit Price</th>
                            <th>Total</th>
                            <th>Received</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($po_items as $item): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                            <td><?php echo $item['quantity']; ?></td>
                            <td><?php echo number_format($item['unit_price']); ?> RWF</td>
                            <td><?php echo number_format($item['total_price']); ?> RWF</td>
                            <td>
                                <?php if($item['received_quantity'] > 0): ?>
                                <span class="status-normal"><?php echo $item['received_quantity']; ?> received</span>
                                <?php else: ?>
                                <span class="status-low">Pending</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="3" style="text-align: right;"><strong>Subtotal:</strong></td>
                            <td colspan="2"><?php echo number_format($po['subtotal']); ?> RWF</td>
                        </tr>
                        <tr>
                            <td colspan="3" style="text-align: right;"><strong>Tax:</strong></td>
                            <td colspan="2"><?php echo number_format($po['tax_amount']); ?> RWF</td>
                        </tr>
                        <tr>
                            <td colspan="3" style="text-align: right;"><strong>Total:</strong></td>
                            <td colspan="2"><strong><?php echo number_format($po['total_amount']); ?> RWF</strong></td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
    <script src="assets/js/script.js"></script>
</body>
</html>