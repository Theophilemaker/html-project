<?php
session_start();
require_once 'config/database.php';
require_once 'check_access.php';
checkAdmin();

$database = new Database();
$db = $database->getConnection();

// Handle Add Employee
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_employee'])) {
    $employee_id = 'EMP' . str_pad(rand(1, 9999), 4, '0', STR_PAD_LEFT);
    $stmt = $db->prepare("INSERT INTO employees (employee_id, full_name, position, department, base_salary, hire_date, phone, email, address) VALUES (?,?,?,?,?,?,?,?,?)");
    $stmt->execute([
        $employee_id,
        $_POST['full_name'],
        $_POST['position'],
        $_POST['department'],
        $_POST['base_salary'],
        $_POST['hire_date'],
        $_POST['phone'],
        $_POST['email'],
        $_POST['address']
    ]);
    $_SESSION['success'] = "Employee added successfully!";
    header('Location: employees.php');
    exit();
}

// Get all employees
$employees = $db->query("SELECT e.*, 
    (SELECT COUNT(*) FROM attendance WHERE employee_id = e.id AND DATE(clock_in) = CURDATE() AND status = 'present') as present_today,
    (SELECT SUM(hours_worked) FROM attendance WHERE employee_id = e.id AND WEEK(clock_in) = WEEK(CURDATE())) as weekly_hours
    FROM employees e ORDER BY e.created_at DESC")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Employees - Theophile POS</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        

<!-- SIDEBAR - NEW VERSION WITH ALL MENU ITEMS -->
<div class="sidebar">
    <div class="logo">
        <h2><i class="fas fa-cash-register"></i> Theophile</h2>
    </div>
    
    <!-- User Info -->
    <div class="user-info">
        <?php 
        if($_SESSION['role'] === 'admin') {
            echo '<span class="role-badge role-admin"><i class="fas fa-crown"></i> ADMIN</span>';
        } else {
            echo '<span class="role-badge role-cashier"><i class="fas fa-user"></i> CASHIER</span>';
        }
        ?>
        <p><i class="fas fa-user"></i> <?php echo htmlspecialchars($_SESSION['full_name']); ?></p>
        <p><i class="fas fa-building"></i> Branch: 
            <?php
            // Get user's branch
            if(isset($db)) {
                $branch_stmt = $db->prepare("SELECT branch_name FROM branches WHERE id = ?");
                $branch_stmt->execute([$_SESSION['branch_id'] ?? 1]);
                $user_branch = $branch_stmt->fetchColumn();
                echo $user_branch ?: 'Headquarters';
            } else {
                echo 'All Branches';
            }
            ?>
        </p>
    </div>
    
    <!-- Navigation Links -->
    <ul class="nav-links">
        <!-- DASHBOARD -->
        <li>
            <a href="index.php" <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-home"></i> <span>Dashboard</span>
            </a>
        </li>
        
        <!-- PRODUCTS -->
        <li>
            <a href="products.php" <?php echo basename($_SERVER['PHP_SELF']) == 'products.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-box"></i> <span>Products</span>
            </a>
        </li>
        
        <!-- ADMIN ONLY SECTION -->
        <?php if($_SESSION['role'] === 'admin'): ?>
        
        <!-- ===== BRANCH MANAGEMENT ===== -->
        <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
            <span>🏢 BRANCH MANAGEMENT</span>
        </li>
        
        <li>
            <a href="branches.php" <?php echo basename($_SERVER['PHP_SELF']) == 'branches.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-building"></i> <span>Branches</span>
            </a>
        </li>
        
        <!-- ===== SUPPLIER MANAGEMENT ===== -->
        <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
            <span>🤝 SUPPLIER MANAGEMENT</span>
        </li>
        
        <li>
            <a href="suppliers.php" <?php echo basename($_SERVER['PHP_SELF']) == 'suppliers.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-truck"></i> <span>Suppliers</span>
            </a>
        </li>
        
        <li>
            <a href="purchase_orders.php" <?php echo basename($_SERVER['PHP_SELF']) == 'purchase_orders.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-file-invoice"></i> <span>Purchase Orders</span>
            </a>
        </li>
        
        <li>
            <a href="supplier_performance.php" <?php echo basename($_SERVER['PHP_SELF']) == 'supplier_performance.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-chart-line"></i> <span>Supplier Analytics</span>
            </a>
        </li>
        
        <!-- ===== STOCK TRANSFERS ===== -->
        <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
            <span>🔄 STOCK TRANSFERS</span>
        </li>
        
        <li>
            <a href="transfers.php" <?php echo basename($_SERVER['PHP_SELF']) == 'transfers.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-exchange-alt"></i> <span>All Transfers</span>
            </a>
        </li>
        
        <!-- ===== REPORTS ===== -->
        <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
            <span>📊 REPORTS</span>
        </li>
        
        <li>
            <a href="reports.php" <?php echo basename($_SERVER['PHP_SELF']) == 'reports.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-chart-bar"></i> <span>Sales Reports</span>
            </a>
        </li>
        
        <li>
            <a href="tax_reports.php" <?php echo basename($_SERVER['PHP_SELF']) == 'tax_reports.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-percent"></i> <span>Tax Reports</span>
            </a>
        </li>
        
        <li>
            <a href="business_intelligence.php" <?php echo basename($_SERVER['PHP_SELF']) == 'business_intelligence.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-chart-line"></i> <span>Business IQ</span>
            </a>
        </li>
        
        <!-- ===== HR MANAGEMENT ===== -->
        <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
            <span>👥 HR MANAGEMENT</span>
        </li>
        
        <li>
            <a href="employees.php" <?php echo basename($_SERVER['PHP_SELF']) == 'employees.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-users"></i> <span>Employees</span>
            </a>
        </li>
        
        <li>
            <a href="attendance.php" <?php echo basename($_SERVER['PHP_SELF']) == 'attendance.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-clock"></i> <span>Attendance</span>
            </a>
        </li>
        
        <li>
            <a href="payroll.php" <?php echo basename($_SERVER['PHP_SELF']) == 'payroll.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-wallet"></i> <span>Payroll</span>
            </a>
        </li>
        
        <!-- ===== SYSTEM ===== -->
        <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
            <span>⚙️ SYSTEM</span>
        </li>
        
        <li>
            <a href="users.php" <?php echo basename($_SERVER['PHP_SELF']) == 'users.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-users-cog"></i> <span>Users</span>
            </a>
        </li>
        
        <?php endif; ?> <!-- End Admin Only -->
        
        <!-- LOGOUT - Always visible -->
        <li style="margin-top: auto; border-top: 1px solid rgba(255,255,255,0.1); padding-top: 10px;">
            <a href="logout.php">
                <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
            </a>
        </li>
    </ul>
</div>
        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1><i class="fas fa-users"></i> Employee Management</h1>
                <div class="date"><?php echo date('l, F j, Y'); ?></div>
            </div>

            <!-- Add Employee Form -->
            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-user-plus"></i> Add New Employee</h3>
                </div>
                <form method="POST" class="grid-3">
                    <div class="form-group">
                        <label>Full Name</label>
                        <input type="text" name="full_name" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>Position</label>
                        <input type="text" name="position" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>Department</label>
                        <select name="department" class="form-control">
                            <option>Management</option>
                            <option>Sales</option>
                            <option>Inventory</option>
                            <option>Accounting</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Base Salary (RWF)</label>
                        <input type="number" name="base_salary" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>Hire Date</label>
                        <input type="date" name="hire_date" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>Phone</label>
                        <input type="text" name="phone" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" name="email" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>Address</label>
                        <textarea name="address" class="form-control" rows="1"></textarea>
                    </div>
                    <div class="form-group">
                        <button type="submit" name="add_employee" class="btn" style="margin-top: 24px;">
                            <i class="fas fa-save"></i> Save Employee
                        </button>
                    </div>
                </form>
            </div>

            <!-- Employees List -->
            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-list"></i> Employees Directory</h3>
                    <div class="search-box">
                        <input type="text" id="searchEmployee" class="form-control" placeholder="Search employees...">
                    </div>
                </div>

                <!-- Stats Cards -->
                <div class="stats-container" style="margin-bottom: 1rem;">
                    <div class="stat-card" style="padding: 1rem;">
                        <div class="stat-icon" style="width: 40px; height: 40px;"><i class="fas fa-users"></i></div>
                        <div><h3>Total</h3><p><?php echo count($employees); ?></p></div>
                    </div>
                    <div class="stat-card" style="padding: 1rem;">
                        <div class="stat-icon" style="width: 40px; height: 40px; background: var(--success);"><i class="fas fa-check-circle"></i></div>
                        <div><h3>Active</h3><p><?php echo count(array_filter($employees, fn($e) => $e['status'] == 'active')); ?></p></div>
                    </div>
                    <div class="stat-card" style="padding: 1rem;">
                        <div class="stat-icon" style="width: 40px; height: 40px; background: var(--success);"><i class="fas fa-clock"></i></div>
                        <div><h3>Present Today</h3><p><?php echo count(array_filter($employees, fn($e) => $e['present_today'] > 0)); ?></p></div>
                    </div>
                    <div class="stat-card" style="padding: 1rem;">
                        <div class="stat-icon" style="width: 40px; height: 40px; background: var(--primary);"><i class="fas fa-money-bill"></i></div>
                        <div><h3>Monthly Payroll</h3><p><?php echo number_format(array_sum(array_column($employees, 'base_salary'))); ?> RWF</p></div>
                    </div>
                </div>

                <!-- Employees Table -->
                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Employee</th>
                                <th>Position</th>
                                <th>Department</th>
                                <th>Base Salary</th>
                                <th>Status</th>
                                <th>Today</th>
                                <th>Weekly Hours</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($employees as $emp): ?>
                            <tr>
                                <td><span class="role-badge" style="background: var(--primary);"><?php echo $emp['employee_id']; ?></span></td>
                                <td>
                                    <strong><?php echo $emp['full_name']; ?></strong><br>
                                    <small><?php echo $emp['email']; ?></small>
                                </td>
                                <td><?php echo $emp['position']; ?></td>
                                <td><?php echo $emp['department']; ?></td>
                                <td><strong><?php echo number_format($emp['base_salary']); ?> RWF</strong></td>
                                <td>
                                    <?php if($emp['status'] == 'active'): ?>
                                    <span class="status-normal"><i class="fas fa-circle"></i> Active</span>
                                    <?php elseif($emp['status'] == 'on_leave'): ?>
                                    <span class="status-expiring"><i class="fas fa-circle"></i> On Leave</span>
                                    <?php else: ?>
                                    <span class="status-low"><i class="fas fa-circle"></i> Inactive</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($emp['present_today'] > 0): ?>
                                    <span class="status-normal"><i class="fas fa-check"></i> Present</span>
                                    <?php else: ?>
                                    <span class="status-low"><i class="fas fa-times"></i> Absent</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo $emp['weekly_hours'] ?? 0; ?> hrs</td>
                                <td>
                                    <a href="employee_view.php?id=<?php echo $emp['id']; ?>" class="btn-small" style="background: var(--primary);">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="employee_edit.php?id=<?php echo $emp['id']; ?>" class="btn-small" style="background: var(--success);">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <button onclick="clockInOut(<?php echo $emp['id']; ?>)" class="btn-small" style="background: var(--warning);">
                                        <i class="fas fa-clock"></i>
                                    </button>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script>
    // Search functionality
    document.getElementById('searchEmployee').addEventListener('keyup', function() {
        const term = this.value.toLowerCase();
        document.querySelectorAll('tbody tr').forEach(row => {
            const text = row.textContent.toLowerCase();
            row.style.display = text.includes(term) ? '' : 'none';
        });
    });

    function clockInOut(empId) {
        fetch('process_attendance.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({employee_id: empId})
        })
        .then(response => response.json())
        .then(data => {
            if(data.success) {
                location.reload();
            }
        });
    }
    </script>
</body>
</html>