// Main JavaScript file for Theophile POS

document.addEventListener('DOMContentLoaded', function() {
    
    // Initialize all components
    initRippleEffect();
    initTooltips();
    initCharts();
    initFormValidation();
    initAutoHideNotifications();
    
    // Ripple effect for buttons
    function initRippleEffect() {
        const buttons = document.querySelectorAll('.btn, .stat-card, .btn-small');
        buttons.forEach(button => {
            button.addEventListener('click', function(e) {
                const ripple = document.createElement('span');
                ripple.classList.add('ripple');
                this.appendChild(ripple);
                
                const rect = this.getBoundingClientRect();
                const x = e.clientX - rect.left;
                const y = e.clientY - rect.top;
                
                ripple.style.left = `${x}px`;
                ripple.style.top = `${y}px`;
                ripple.style.width = '10px';
                ripple.style.height = '10px';
                
                setTimeout(() => {
                    ripple.remove();
                }, 600);
            });
        });
    }
    
    // Initialize tooltips
    function initTooltips() {
        const tooltipElements = document.querySelectorAll('[data-tooltip]');
        tooltipElements.forEach(el => {
            el.addEventListener('mouseenter', showTooltip);
            el.addEventListener('mouseleave', hideTooltip);
        });
    }
    
    function showTooltip(e) {
        const tooltip = document.createElement('div');
        tooltip.className = 'tooltip';
        tooltip.textContent = e.target.dataset.tooltip;
        tooltip.style.position = 'absolute';
        tooltip.style.background = '#1e1e2f';
        tooltip.style.color = 'white';
        tooltip.style.padding = '5px 10px';
        tooltip.style.borderRadius = '5px';
        tooltip.style.fontSize = '12px';
        tooltip.style.zIndex = '10000';
        tooltip.style.pointerEvents = 'none';
        tooltip.style.whiteSpace = 'nowrap';
        
        const rect = e.target.getBoundingClientRect();
        tooltip.style.top = rect.top - 30 + 'px';
        tooltip.style.left = rect.left + (rect.width / 2) - 20 + 'px';
        
        document.body.appendChild(tooltip);
        
        setTimeout(() => {
            tooltip.style.opacity = '1';
        }, 10);
        
        e.target._tooltip = tooltip;
    }
    
    function hideTooltip(e) {
        if(e.target._tooltip) {
            e.target._tooltip.remove();
            e.target._tooltip = null;
        }
    }
    
    // Initialize charts if they exist
    function initCharts() {
        // Charts are initialized in their respective pages
        // This is just a placeholder for any global chart settings
    }
    
    // Form validation
    function initFormValidation() {
        const forms = document.querySelectorAll('form');
        forms.forEach(form => {
            form.addEventListener('submit', function(e) {
                const requiredFields = this.querySelectorAll('[required]');
                let isValid = true;
                
                requiredFields.forEach(field => {
                    if(!field.value.trim()) {
                        isValid = false;
                        field.style.borderColor = '#f72585';
                        field.style.animation = 'shake 0.5s';
                        
                        setTimeout(() => {
                            field.style.animation = '';
                        }, 500);
                    } else {
                        field.style.borderColor = '#4cc9f0';
                    }
                });
                
                if(!isValid) {
                    e.preventDefault();
                    showNotification('Please fill all required fields', 'error');
                }
            });
        });
    }
    
    // Auto-hide notifications
    function initAutoHideNotifications() {
        const notifications = document.querySelectorAll('.notification');
        notifications.forEach(notification => {
            setTimeout(() => {
                notification.classList.remove('show');
            }, 3000);
            
            notification.addEventListener('click', function() {
                this.classList.remove('show');
            });
        });
    }
    
    // Show notification function
    window.showNotification = function(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.innerHTML = `
            <i class="fas ${type === 'success' ? 'fa-check-circle' : type === 'error' ? 'fa-exclamation-circle' : 'fa-info-circle'}"></i>
            <span>${message}</span>
        `;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.classList.add('show');
        }, 100);
        
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => {
                notification.remove();
            }, 300);
        }, 3000);
    };
    
    // Print functionality
    window.printReport = function(elementId) {
        const printContent = document.getElementById(elementId);
        const originalContent = document.body.innerHTML;
        
        document.body.innerHTML = printContent.innerHTML;
        window.print();
        document.body.innerHTML = originalContent;
        location.reload();
    };
    
    // Export to CSV
    window.exportToCSV = function(tableId, filename) {
        const table = document.getElementById(tableId);
        const rows = table.querySelectorAll('tr');
        const csv = [];
        
        rows.forEach(row => {
            const cells = row.querySelectorAll('td, th');
            const rowData = [];
            cells.forEach(cell => {
                rowData.push('"' + cell.innerText.replace(/"/g, '""') + '"');
            });
            csv.push(rowData.join(','));
        });
        
        const csvContent = csv.join('\n');
        const blob = new Blob([csvContent], { type: 'text/csv' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename + '.csv';
        a.click();
        window.URL.revokeObjectURL(url);
    };
    
    // Keyboard shortcuts
    document.addEventListener('keydown', function(e) {
        // Ctrl + S for quick sale
        if(e.ctrlKey && e.key === 's') {
            e.preventDefault();
            const salesForm = document.getElementById('salesForm');
            if(salesForm) {
                salesForm.querySelector('button[type="submit"]').click();
            }
        }
        
        // Ctrl + P for print
        if(e.ctrlKey && e.key === 'p') {
            e.preventDefault();
            if(window.printReport) {
                window.printReport('report-content');
            }
        }
        
        // Esc to close notifications
        if(e.key === 'Escape') {
            const notifications = document.querySelectorAll('.notification');
            notifications.forEach(n => n.classList.remove('show'));
        }
    });
    
    // Add loading animation
    window.showLoading = function() {
        const loader = document.createElement('div');
        loader.className = 'loader';
        loader.innerHTML = '<div class="spinner"></div>';
        document.body.appendChild(loader);
    };
    
    window.hideLoading = function() {
        const loader = document.querySelector('.loader');
        if(loader) {
            loader.remove();
        }
    };
    
    // Confirmation dialog
    window.confirmAction = function(message, callback) {
        if(confirm(message)) {
            callback();
        }
    };
});

// Add CSS for loader and tooltips
const style = document.createElement('style');
style.textContent = `
    .loader {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(255,255,255,0.8);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 9999;
    }
    
    .spinner {
        width: 50px;
        height: 50px;
        border: 5px solid #f3f3f3;
        border-top: 5px solid var(--primary-color);
        border-radius: 50%;
        animation: spin 1s linear infinite;
    }
    
    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }
    
    .tooltip {
        opacity: 0;
        transition: opacity 0.3s ease;
        box-shadow: 0 2px 10px rgba(0,0,0,0.2);
    }
    
    .tooltip::after {
        content: '';
        position: absolute;
        top: 100%;
        left: 50%;
        margin-left: -5px;
        border-width: 5px;
        border-style: solid;
        border-color: #1e1e2f transparent transparent transparent;
    }
    
    @keyframes slideIn {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .fade-in {
        animation: fadeIn 0.5s ease;
    }
    
    @keyframes fadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
    }
`;

document.head.appendChild(style);