<?php

session_start();
if(isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Theophile POS - Login</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .login-container {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 20px;
        }
        .login-box {
            background: white;
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
            width: 100%;
            max-width: 400px;
            animation: slideIn 0.5s ease;
            position: relative;
            overflow: hidden;
        }
        .login-box::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 5px;
            background: linear-gradient(90deg, #667eea, #764ba2, #667eea);
            animation: slide 3s infinite;
        }
        @keyframes slide {
            0% { left: -100%; }
            100% { left: 100%; }
        }
        .login-box h2 {
            text-align: center;
            margin-bottom: 30px;
            color: var(--dark-color);
            font-size: 28px;
            font-weight: 600;
        }
        .login-box h2 i {
            color: var(--primary-color);
            margin-right: 10px;
        }
        .role-badge {
            display: inline-block;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
            margin: 5px;
        }
        .role-admin {
            background: linear-gradient(135deg, #f72585 0%, #b5179e 100%);
            color: white;
        }
        .role-cashier {
            background: linear-gradient(135deg, #4cc9f0 0%, #4361ee 100%);
            color: white;
        }
        .demo-credentials {
            margin-top: 30px;
            padding: 20px;
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            border-radius: 15px;
            font-size: 14px;
            border: 1px solid rgba(0,0,0,0.05);
        }
        .demo-credentials h4 {
            margin-bottom: 15px;
            color: var(--dark-color);
            font-size: 16px;
        }
        .demo-credentials p {
            margin: 8px 0;
            padding: 8px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            transition: all 0.3s ease;
        }
        .demo-credentials p:hover {
            transform: translateX(5px);
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }
        .input-group {
            position: relative;
            margin-bottom: 20px;
        }
        .input-group i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #999;
            transition: all 0.3s ease;
        }
        .input-group input {
            width: 100%;
            padding: 15px 15px 15px 45px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            font-size: 14px;
            transition: all 0.3s ease;
        }
        .input-group input:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(67,97,238,0.1);
            outline: none;
        }
        .input-group input:focus + i {
            color: var(--primary-color);
        }
        .login-btn {
            width: 100%;
            padding: 15px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        .login-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(102,126,234,0.4);
        }
        .login-btn:active {
            transform: translateY(0);
        }
        .login-btn i {
            margin-right: 10px;
        }
        .error-message {
            background: linear-gradient(135deg, #f72585 0%, #b5179e 100%);
            color: white;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: shake 0.5s;
        }
        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            10%, 30%, 50%, 70%, 90% { transform: translateX(-5px); }
            20%, 40%, 60%, 80% { transform: translateX(5px); }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-box">
            <h2><i class="fas fa-cash-register"></i> Theophile smartshop system</h2>
            
            <?php if(isset($_GET['error'])): ?>
            <div class="error-message">
                <i class="fas fa-exclamation-circle"></i>
                Invalid username or password!
            </div>
            <?php endif; ?>

            <?php if(isset($_GET['loggedout'])): ?>
            <div class="error-message" style="background: linear-gradient(135deg, #4cc9f0 0%, #4361ee 100%);">
                <i class="fas fa-check-circle"></i>
                You have been logged out successfully!
            </div>
            <?php endif; ?>

            <form action="authenticate.php" method="POST">
                <div class="input-group">
                    <i class="fas fa-user"></i>
                    <input type="text" name="username" placeholder="Username" required>
                </div>
                <div class="input-group">
                    <i class="fas fa-lock"></i>
                    <input type="password" name="password" placeholder="Password" required>
                </div>
                <button type="submit" class="login-btn">
                    <i class="fas fa-sign-in-alt"></i> Login
                </button>
            </form>

            <div class="demo-credentials">
                <h4><i class="fas fa-info-circle"></i> USERS OF SMARTSHOP SYSTEM :</h4>
                <p>
                    <span class="role-badge role-admin">ADMIN</span>
                    <strong>owner</strong>
                </p>
                <p>
                    <span class="role-badge role-cashier">CASHIER</span>
                    <strong>cashier1</strong> 
                </p>
                <p>
                    <span class="role-badge role-cashier">CASHIER</span>
                    <strong>cashier2</strong> 
                </p>
            </div>
        </div>
    </div>
</body>
</html>