<?php
session_start();
require_once 'config/database.php';
require_once 'check_access.php';

// Check login and admin
if(!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('HTTP/1.0 403 Forbidden');
    exit('Access denied');
}

$database = new Database();
$db = $database->getConnection();

// Get parameters
$month = isset($_GET['month']) ? $_GET['month'] : date('Y-m');
$format = isset($_GET['format']) ? $_GET['format'] : 'csv';

$year = date('Y', strtotime($month));
$month_num = date('m', strtotime($month));

// Get tax data
$query = "SELECT 
    s.sale_date,
    p.name as product_name,
    c.name as category,
    tt.subtotal,
    tt.tax_amount,
    tt.total_with_tax,
    tt.tax_rate,
    u.full_name as cashier
    FROM tax_transactions tt
    JOIN sales s ON tt.sale_id = s.id
    JOIN products p ON tt.product_id = p.id
    JOIN categories c ON p.category_id = c.id
    JOIN users u ON s.cashier_id = u.id
    WHERE MONTH(s.sale_date) = ? AND YEAR(s.sale_date) = ?
    ORDER BY s.sale_date DESC";

$stmt = $db->prepare($query);
$stmt->execute([$month_num, $year]);
$data = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Calculate totals
$total_subtotal = 0;
$total_tax = 0;
$total_with_tax = 0;

foreach($data as $row) {
    $total_subtotal += $row['subtotal'];
    $total_tax += $row['tax_amount'];
    $total_with_tax += $row['total_with_tax'];
}

// Set headers for download
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="tax_report_' . $month . '.csv"');

// Create output stream
$output = fopen('php://output', 'w');

// Add UTF-8 BOM for Excel
fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));

// Add headers
fputcsv($output, [
    'Date',
    'Product',
    'Category',
    'Subtotal (RWF)',
    'Tax Amount (RWF)',
    'Total (RWF)',
    'Tax Rate (%)',
    'Cashier'
]);

// Add data rows
foreach($data as $row) {
    fputcsv($output, [
        $row['sale_date'],
        $row['product_name'],
        $row['category'],
        number_format($row['subtotal'], 0),
        number_format($row['tax_amount'], 0),
        number_format($row['total_with_tax'], 0),
        $row['tax_rate'],
        $row['cashier']
    ]);
}

// Add summary row
fputcsv($output, []); // Empty row
fputcsv($output, ['SUMMARY', '', '', '', '', '', '', '']);
fputcsv($output, [
    'Total',
    '',
    '',
    number_format($total_subtotal, 0),
    number_format($total_tax, 0),
    number_format($total_with_tax, 0),
    $total_subtotal > 0 ? round(($total_tax / $total_subtotal) * 100, 2) . '%' : '0%',
    ''
]);

fclose($output);
exit();
?>