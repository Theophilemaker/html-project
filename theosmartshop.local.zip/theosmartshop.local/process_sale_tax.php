<?php
session_start();
require_once 'config/database.php';
require_once 'check_access.php';

if(!isset($_SESSION['user_id'])) { header('Location: login.php'); exit(); }

$database = new Database();
$db = $database->getConnection();

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_id = $_POST['product_id'];
    $quantity = $_POST['quantity'];
    $cashier_id = $_SESSION['user_id'];
    
    // Get product with tax info
    $stmt = $db->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->execute([$product_id]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if($product && $product['quantity'] >= $quantity) {
        // Calculate with tax
        $subtotal = $product['selling_price'] * $quantity;
        $tax_rate = $product['tax_rate'];
        
        if($product['tax_inclusive']) {
            // Price already includes tax
            $tax_amount = $subtotal - ($subtotal / (1 + ($tax_rate/100)));
            $total_with_tax = $subtotal;
        } else {
            // Tax is added
            $tax_amount = $subtotal * ($tax_rate/100);
            $total_with_tax = $subtotal + $tax_amount;
        }
        
        $db->beginTransaction();
        try {
            // Insert sale
            $stmt = $db->prepare("INSERT INTO sales (product_id, cashier_id, quantity, total_price, sale_date) VALUES (?,?,?,?,CURDATE())");
            $stmt->execute([$product_id, $cashier_id, $quantity, $total_with_tax]);
            $sale_id = $db->lastInsertId();
            
            // Insert tax transaction
            $stmt = $db->prepare("INSERT INTO tax_transactions (sale_id, product_id, subtotal, tax_amount, total_with_tax, tax_rate) VALUES (?,?,?,?,?,?)");
            $stmt->execute([$sale_id, $product_id, $subtotal, $tax_amount, $total_with_tax, $tax_rate]);
            
            // Update stock
            $stmt = $db->prepare("UPDATE products SET quantity = quantity - ? WHERE id = ?");
            $stmt->execute([$quantity, $product_id]);
            
            $db->commit();
            
            // Return JSON for AJAX response
            echo json_encode([
                'success' => true,
                'message' => 'Sale completed!',
                'data' => [
                    'subtotal' => number_format($subtotal, 0) . ' RWF',
                    'tax' => number_format($tax_amount, 0) . ' RWF',
                    'total' => number_format($total_with_tax, 0) . ' RWF',
                    'tax_rate' => $tax_rate . '%'
                ]
            ]);
            exit();
            
        } catch(Exception $e) {
            $db->rollBack();
            echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
            exit();
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Insufficient stock!']);
        exit();
    }
}
?>