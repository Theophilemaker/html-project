<?php
// Include this file in pages that need branch selection
// Usage: require_once 'branch_selector.php';
// Then call renderBranchSelector($selected_branch_id, $onchange_js)

function renderBranchSelector($selected_id = null, $onchange = '') {
    global $db;
    
    $branches = $db->query("SELECT id, branch_code, branch_name FROM branches WHERE is_active = 1 ORDER BY branch_name")->fetchAll(PDO::FETCH_ASSOC);
    
    $html = '<select class="form-control branch-selector" name="branch_id" onchange="' . $onchange . '">';
    $html .= '<option value="">All Branches</option>';
    
    foreach($branches as $branch) {
        $selected = ($selected_id == $branch['id']) ? 'selected' : '';
        $html .= '<option value="' . $branch['id'] . '" ' . $selected . '>';
        $html .= $branch['branch_code'] . ' - ' . $branch['branch_name'];
        $html .= '</option>';
    }
    
    $html .= '</select>';
    return $html;
}

function getBranchSwitchJS() {
    return '
    <script>
        function switchBranch(branchId) {
            if(branchId) {
                window.location.href = window.location.pathname + "?branch=" + branchId;
            }
        }
    </script>';
}
?>