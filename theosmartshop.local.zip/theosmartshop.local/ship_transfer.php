<?php
session_start();
require_once 'config/database.php';
require_once 'check_access.php';

if(!isset($_SESSION['user_id'])) { 
    header('Location: login.php'); 
    exit(); 
}

// Only admin can ship transfers
if($_SESSION['role'] !== 'admin') {
    $_SESSION['error'] = "⛔ Access Denied! Admin only.";
    header('Location: index.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();

$transfer_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Get transfer details
$stmt = $db->prepare("SELECT t.*, 
    from_b.branch_name as from_branch, 
    to_b.branch_name as to_branch,
    req.full_name as requested_by_name
    FROM stock_transfers t
    JOIN branches from_b ON t.from_branch_id = from_b.id
    JOIN branches to_b ON t.to_branch_id = to_b.id
    LEFT JOIN users req ON t.requested_by = req.id
    WHERE t.id = ? AND t.status = 'approved'");
$stmt->execute([$transfer_id]);
$transfer = $stmt->fetch(PDO::FETCH_ASSOC);

if(!$transfer) {
    $_SESSION['error'] = "Transfer not found or cannot be shipped!";
    header('Location: transfers.php');
    exit();
}

// Get transfer items
$items = $db->prepare("SELECT ti.*, p.name as product_name 
    FROM transfer_items ti
    JOIN products p ON ti.product_id = p.id
    WHERE ti.transfer_id = ?");
$items->execute([$transfer_id]);
$transfer_items = $items->fetchAll(PDO::FETCH_ASSOC);

// Handle form submission
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_ship'])) {
    
    // Validate shipping details
    $tracking_number = trim($_POST['tracking_number'] ?? '');
    $carrier = trim($_POST['carrier'] ?? '');
    $shipping_date = $_POST['shipping_date'] ?? date('Y-m-d');
    $estimated_arrival = $_POST['estimated_arrival'] ?? '';
    $notes = trim($_POST['notes'] ?? '');
    
    $db->beginTransaction();
    try {
        // Update transfer status
        $stmt = $db->prepare("UPDATE stock_transfers SET 
            status = 'shipped',
            shipping_tracking = ?,
            shipping_carrier = ?,
            shipping_date = ?,
            estimated_arrival = ?,
            shipping_notes = ?
            WHERE id = ?");
        $stmt->execute([
            $tracking_number,
            $carrier,
            $shipping_date,
            $estimated_arrival,
            $notes,
            $transfer_id
        ]);
        
        // Log history
        $log_notes = "Shipped via $carrier" . ($tracking_number ? " (Tracking: $tracking_number)" : "");
        $stmt = $db->prepare("INSERT INTO transfer_history (transfer_id, action, user_id, notes) VALUES (?, 'shipped', ?, ?)");
        $stmt->execute([$transfer_id, $_SESSION['user_id'], $log_notes]);
        
        $db->commit();
        $_SESSION['success'] = "Transfer #" . $transfer['transfer_number'] . " marked as shipped successfully!";
        header('Location: transfer_details.php?id=' . $transfer_id);
        exit();
        
    } catch(Exception $e) {
        $db->rollBack();
        $_SESSION['error'] = "Error shipping transfer: " . $e->getMessage();
    }
}

// Get carriers list
$carriers = [
    'DHL',
    'FedEx',
    'UPS',
    'Rwanda Post',
    'Kigali Express',
    'Company Vehicle',
    'Other'
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Theophile POS - Ship Transfer</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .ship-container {
            max-width: 800px;
            margin: 0 auto;
        }
        .info-panel {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            border-radius: 15px;
            padding: 1.5rem;
            margin-bottom: 2rem;
            border-left: 5px solid var(--info);
        }
        .info-row {
            display: flex;
            margin-bottom: 1rem;
            padding: 0.5rem;
            border-bottom: 1px dashed #dee2e6;
        }
        .info-label {
            font-weight: bold;
            width: 150px;
            color: #495057;
        }
        .info-value {
            flex: 1;
        }
        .item-table {
            margin: 1.5rem 0;
            background: white;
            border-radius: 10px;
            overflow: hidden;
        }
        .item-table th {
            background: var(--primary);
            color: white;
            padding: 1rem;
        }
        .item-table td {
            padding: 1rem;
            border-bottom: 1px solid #f0f0f0;
        }
        .form-section {
            background: white;
            border-radius: 15px;
            padding: 2rem;
            margin-top: 2rem;
        }
        .shipping-details {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 1rem;
        }
        .btn-ship {
            background: linear-gradient(135deg, #17a2b8 0%, #138496 100%);
            color: white;
            border: none;
            padding: 1rem 3rem;
            border-radius: 8px;
            font-size: 1.1rem;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        .btn-ship:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(23,162,184,0.4);
        }
        .tracking-preview {
            margin-top: 1rem;
            padding: 1rem;
            background: #e3f2fd;
            border-radius: 8px;
            display: none;
        }
        .status-badge {
            display: inline-block;
            padding: 5px 15px;
            border-radius: 20px;
            font-weight: bold;
            font-size: 0.9rem;
        }
        .status-approved { background: #cce5ff; color: #004085; }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="logo">
                <h2><i class="fas fa-cash-register"></i> Theophile</h2>
            </div>
            
            <div class="user-info">
                <?php 
                if($_SESSION['role'] === 'admin') {
                    echo '<span class="role-badge role-admin"><i class="fas fa-crown"></i> ADMIN</span>';
                } else {
                    echo '<span class="role-badge role-cashier"><i class="fas fa-user"></i> CASHIER</span>';
                }
                ?>
                <p><i class="fas fa-user"></i> <?php echo htmlspecialchars($_SESSION['full_name']); ?></p>
            </div>
            
            <ul class="nav-links">
                <li><a href="index.php"><i class="fas fa-home"></i> <span>Dashboard</span></a></li>
                <li><a href="products.php"><i class="fas fa-box"></i> <span>Products</span></a></li>
                
                <?php if($_SESSION['role'] === 'admin'): ?>
                <li><a href="branches.php"><i class="fas fa-building"></i> <span>Branches</span></a></li>
                <li><a href="suppliers.php"><i class="fas fa-truck"></i> <span>Suppliers</span></a></li>
                <li><a href="purchase_orders.php"><i class="fas fa-file-invoice"></i> <span>Purchase Orders</span></a></li>
                <li><a href="transfers.php" class="active"><i class="fas fa-exchange-alt"></i> <span>Stock Transfers</span></a></li>
                <li><a href="reports.php"><i class="fas fa-chart-bar"></i> <span>Reports</span></a></li>
                <li><a href="users.php"><i class="fas fa-users-cog"></i> <span>Users</span></a></li>
                <?php endif; ?>
                
                <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> <span>Logout</span></a></li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1><i class="fas fa-ship"></i> Ship Stock Transfer</h1>
                <div class="date">
                    <i class="fas fa-calendar-alt"></i> <?php echo date('l, F j, Y'); ?>
                </div>
            </div>

            <?php if(isset($_SESSION['error'])): ?>
            <div class="notification notification-error show"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
            <?php endif; ?>

            <div class="ship-container">
                <!-- Transfer Info Panel -->
                <div class="info-panel">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                        <h2 style="margin:0; color: var(--primary);">
                            <i class="fas fa-exchange-alt"></i> Transfer #<?php echo $transfer['transfer_number']; ?>
                        </h2>
                        <span class="status-badge status-approved">Approved & Ready to Ship</span>
                    </div>
                    
                    <div class="info-row">
                        <div class="info-label"><i class="fas fa-store"></i> From:</div>
                        <div class="info-value"><strong><?php echo htmlspecialchars($transfer['from_branch']); ?></strong></div>
                    </div>
                    
                    <div class="info-row">
                        <div class="info-label"><i class="fas fa-arrow-right"></i> To:</div>
                        <div class="info-value"><strong><?php echo htmlspecialchars($transfer['to_branch']); ?></strong></div>
                    </div>
                    
                    <div class="info-row">
                        <div class="info-label"><i class="fas fa-calendar"></i> Transfer Date:</div>
                        <div class="info-value"><?php echo date('F j, Y', strtotime($transfer['transfer_date'])); ?></div>
                    </div>
                    
                    <div class="info-row">
                        <div class="info-label"><i class="fas fa-user"></i> Requested By:</div>
                        <div class="info-value"><?php echo htmlspecialchars($transfer['requested_by_name'] ?? 'System'); ?></div>
                    </div>
                    
                    <?php if($transfer['notes']): ?>
                    <div class="info-row">
                        <div class="info-label"><i class="fas fa-sticky-note"></i> Notes:</div>
                        <div class="info-value"><?php echo nl2br(htmlspecialchars($transfer['notes'])); ?></div>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- Items Table -->
                <div class="item-table">
                    <table style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Quantity</th>
                                <th>Unit Price</th>
                                <th>Total Value</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $total_value = 0;
                            foreach($transfer_items as $item): 
                                $total_value += $item['total_value'];
                            ?>
                            <tr>
                                <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                                <td><?php echo $item['quantity']; ?></td>
                                <td><?php echo number_format($item['unit_price']); ?> RWF</td>
                                <td><?php echo number_format($item['total_value']); ?> RWF</td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                        <tfoot>
                            <tr style="background: #f8f9fa; font-weight: bold;">
                                <td colspan="3" style="text-align: right;">Total Value:</td>
                                <td><?php echo number_format($total_value); ?> RWF</td>
                            </tr>
                        </tfoot>
                    </table>
                </div>

                <!-- Shipping Form -->
                <div class="form-section">
                    <h3 style="margin-bottom: 1.5rem; color: var(--primary);">
                        <i class="fas fa-truck"></i> Shipping Details
                    </h3>
                    
                    <form method="POST" action="">
                        <div class="shipping-details">
                            <div class="form-group">
                                <label><i class="fas fa-barcode"></i> Tracking Number</label>
                                <input type="text" name="tracking_number" class="form-control" 
                                       placeholder="e.g., DHL123456789" id="tracking">
                            </div>
                            
                            <div class="form-group">
                                <label><i class="fas fa-truck"></i> Carrier</label>
                                <select name="carrier" class="form-control" id="carrier" required>
                                    <option value="">Select Carrier</option>
                                    <?php foreach($carriers as $carrier): ?>
                                    <option value="<?php echo $carrier; ?>"><?php echo $carrier; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label><i class="fas fa-calendar-day"></i> Shipping Date</label>
                                <input type="date" name="shipping_date" class="form-control" 
                                       value="<?php echo date('Y-m-d'); ?>" required>
                            </div>
                            
                            <div class="form-group">
                                <label><i class="fas fa-calendar-check"></i> Estimated Arrival</label>
                                <input type="date" name="estimated_arrival" class="form-control" 
                                       value="<?php echo date('Y-m-d', strtotime('+3 days')); ?>">
                            </div>
                        </div>
                        
                        <div class="form-group" style="margin-top: 1rem;">
                            <label><i class="fas fa-sticky-note"></i> Shipping Notes</label>
                            <textarea name="notes" class="form-control" rows="3" 
                                      placeholder="Additional shipping instructions, handling notes, etc."></textarea>
                        </div>

                        <!-- Tracking Preview -->
                        <div id="trackingPreview" class="tracking-preview">
                            <i class="fas fa-check-circle" style="color: #17a2b8;"></i>
                            <span id="previewText"></span>
                        </div>
                        
                        <div style="display: flex; gap: 1rem; margin-top: 2rem;">
                            <button type="submit" name="confirm_ship" class="btn-ship">
                                <i class="fas fa-check-circle"></i> Confirm Shipment
                            </button>
                            <a href="transfer_details.php?id=<?php echo $transfer_id; ?>" 
                               class="btn" style="background: #6c757d;">
                                <i class="fas fa-times"></i> Cancel
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="assets/js/script.js"></script>
    <script>
        // Live tracking preview
        const trackingInput = document.getElementById('tracking');
        const carrierSelect = document.getElementById('carrier');
        const preview = document.getElementById('trackingPreview');
        const previewText = document.getElementById('previewText');
        
        function updatePreview() {
            const tracking = trackingInput.value;
            const carrier = carrierSelect.value;
            
            if(tracking && carrier) {
                preview.style.display = 'block';
                previewText.innerHTML = `📦 Shipment will be sent via <strong>${carrier}</strong> with tracking # <strong>${tracking}</strong>`;
            } else if(carrier) {
                preview.style.display = 'block';
                previewText.innerHTML = `📦 Shipment will be sent via <strong>${carrier}</strong>`;
            } else {
                preview.style.display = 'none';
            }
        }
        
        trackingInput.addEventListener('input', updatePreview);
        carrierSelect.addEventListener('change', updatePreview);
        
        // Auto-hide notifications
        setTimeout(() => {
            document.querySelectorAll('.notification').forEach(n => n.classList.remove('show'));
        }, 3000);
    </script>
</body>
</html>