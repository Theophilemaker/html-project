<?php
session_start();
require_once 'config/database.php';
require_once 'check_access.php';

// Check login
if(!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_id = $_POST['product_id'];
    $quantity = $_POST['quantity'];
    $cashier_id = $_SESSION['user_id'];
    
    // Validate inputs
    if(!$product_id || !$quantity || $quantity <= 0) {
        $_SESSION['error'] = "❌ Invalid product or quantity!";
        header('Location: index.php');
        exit();
    }
    
    // Get product details
    $query = "SELECT * FROM products WHERE id = :id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $product_id);
    $stmt->execute();
    $product = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$product) {
        $_SESSION['error'] = "❌ Product not found!";
        header('Location: index.php');
        exit();
    }
    
    // Check stock
    if ($product['quantity'] < $quantity) {
        $_SESSION['error'] = "❌ Insufficient stock! Only {$product['quantity']} left.";
        header('Location: index.php');
        exit();
    }
    
    // Begin transaction
    $db->beginTransaction();
    
    try {
        // Calculate total
        $total_price = $product['selling_price'] * $quantity;
        
        // Insert sale
        $query = "INSERT INTO sales (product_id, cashier_id, quantity, total_price, sale_date) 
                  VALUES (:product_id, :cashier_id, :quantity, :total_price, CURDATE())";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':product_id', $product_id);
        $stmt->bindParam(':cashier_id', $cashier_id);
        $stmt->bindParam(':quantity', $quantity);
        $stmt->bindParam(':total_price', $total_price);
        $stmt->execute();
        
        // Update product quantity
        $new_quantity = $product['quantity'] - $quantity;
        $query = "UPDATE products SET quantity = :quantity WHERE id = :id";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':quantity', $new_quantity);
        $stmt->bindParam(':id', $product_id);
        $stmt->execute();
        
        // Commit transaction
        $db->commit();
        
        $_SESSION['success'] = "✅ Sale completed successfully! " . number_format($total_price) . " RWF";
        
    } catch(Exception $e) {
        // Rollback on error
        $db->rollBack();
        $_SESSION['error'] = "❌ Error processing sale: " . $e->getMessage();
    }
}

header('Location: index.php');
exit();
?>