<?php
session_start();
require_once 'config/database.php';
require_once 'check_access.php';

// Check login and admin
if(!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('HTTP/1.0 403 Forbidden');
    exit('Access denied');
}

$database = new Database();
$db = $database->getConnection();

// Get parameters
$month = isset($_GET['month']) ? $_GET['month'] : date('Y-m');
$format = isset($_GET['format']) ? $_GET['format'] : 'csv';

$year = date('Y', strtotime($month));
$month_num = date('m', strtotime($month));

// Get payroll data
$query = "SELECT 
    e.employee_id,
    e.full_name,
    e.position,
    e.department,
    p.pay_period_start,
    p.pay_period_end,
    p.regular_hours,
    p.overtime_hours,
    p.regular_pay,
    p.overtime_pay,
    p.bonus,
    p.deductions,
    p.tax_amount,
    p.net_pay,
    p.status
    FROM payroll p
    JOIN employees e ON p.employee_id = e.id
    WHERE DATE_FORMAT(p.pay_period_start, '%Y-%m') = ?
    ORDER BY e.full_name";

$stmt = $db->prepare($query);
$stmt->execute([$month]);
$data = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Calculate totals
$totals = [
    'regular_hours' => 0,
    'overtime_hours' => 0,
    'regular_pay' => 0,
    'overtime_pay' => 0,
    'bonus' => 0,
    'deductions' => 0,
    'tax_amount' => 0,
    'net_pay' => 0
];

foreach($data as $row) {
    $totals['regular_hours'] += $row['regular_hours'];
    $totals['overtime_hours'] += $row['overtime_hours'];
    $totals['regular_pay'] += $row['regular_pay'];
    $totals['overtime_pay'] += $row['overtime_pay'];
    $totals['bonus'] += $row['bonus'];
    $totals['deductions'] += $row['deductions'];
    $totals['tax_amount'] += $row['tax_amount'];
    $totals['net_pay'] += $row['net_pay'];
}

// Set headers for download
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="payroll_report_' . $month . '.csv"');

// Create output stream
$output = fopen('php://output', 'w');

// Add UTF-8 BOM for Excel
fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));

// Add headers
fputcsv($output, [
    'Employee ID',
    'Full Name',
    'Position',
    'Department',
    'Period Start',
    'Period End',
    'Regular Hours',
    'Overtime Hours',
    'Regular Pay (RWF)',
    'Overtime Pay (RWF)',
    'Bonus (RWF)',
    'Deductions (RWF)',
    'Tax (RWF)',
    'Net Pay (RWF)',
    'Status'
]);

// Add data rows
foreach($data as $row) {
    fputcsv($output, [
        $row['employee_id'],
        $row['full_name'],
        $row['position'],
        $row['department'],
        $row['pay_period_start'],
        $row['pay_period_end'],
        number_format($row['regular_hours'], 1),
        number_format($row['overtime_hours'], 1),
        number_format($row['regular_pay'], 0),
        number_format($row['overtime_pay'], 0),
        number_format($row['bonus'], 0),
        number_format($row['deductions'], 0),
        number_format($row['tax_amount'], 0),
        number_format($row['net_pay'], 0),
        $row['status']
    ]);
}

// Add summary row
fputcsv($output, []); // Empty row
fputcsv($output, ['SUMMARY', '', '', '', '', '', '', '', '', '', '', '', '', '', '']);
fputcsv($output, [
    'TOTAL',
    '',
    '',
    '',
    '',
    '',
    number_format($totals['regular_hours'], 1),
    number_format($totals['overtime_hours'], 1),
    number_format($totals['regular_pay'], 0),
    number_format($totals['overtime_pay'], 0),
    number_format($totals['bonus'], 0),
    number_format($totals['deductions'], 0),
    number_format($totals['tax_amount'], 0),
    number_format($totals['net_pay'], 0),
    ''
]);

fclose($output);
exit();
?>