<?php
require_once 'config/database.php';

$database = new Database();
$db = $database->getConnection();

echo "<h2>Login Debugger</h2>";

// Check if users table exists and has data
$query = "SHOW TABLES LIKE 'users'";
$stmt = $db->prepare($query);
$stmt->execute();
if($stmt->rowCount() == 0) {
    die("❌ Users table doesn't exist! Did you import database.sql?");
}

// Show all users
$query = "SELECT id, username, password, role, is_active FROM users";
$stmt = $db->prepare($query);
$stmt->execute();
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo "<h3>Users in database:</h3>";
echo "<table border='1' cellpadding='10'>";
echo "<tr><th>ID</th><th>Username</th><th>Password Hash</th><th>Role</th><th>Active</th></tr>";

foreach($users as $user) {
    echo "<tr>";
    echo "<td>" . $user['id'] . "</td>";
    echo "<td>" . $user['username'] . "</td>";
    echo "<td>" . $user['password'] . "</td>";
    echo "<td>" . $user['role'] . "</td>";
    echo "<td>" . ($user['is_active'] ? '✅' : '❌') . "</td>";
    echo "</tr>";
}
echo "</table>";

// Test admin login
$test_username = 'admin';
$test_password = 'admin123';
$hashed = md5($test_password);

echo "<h3>Testing login:</h3>";
echo "Username: " . $test_username . "<br>";
echo "Password: " . $test_password . "<br>";
echo "MD5 Hash: " . $hashed . "<br>";

$query = "SELECT * FROM users WHERE username = :username AND password = :password";
$stmt = $db->prepare($query);
$stmt->bindParam(':username', $test_username);
$stmt->bindParam(':password', $hashed);
$stmt->execute();

if($stmt->rowCount() > 0) {
    echo "<p style='color:green'>✅ Login would succeed! The hash matches.</p>";
} else {
    echo "<p style='color:red'>❌ Login would fail! Hash doesn't match.</p>";
    
    // Show what hash should be
    echo "<p>The expected MD5 of 'admin123' is: <strong>" . md5('admin123') . "</strong></p>";
    echo "<p>Your database has: <strong>" . $users[0]['password'] . "</strong> for admin</p>";
}
?>