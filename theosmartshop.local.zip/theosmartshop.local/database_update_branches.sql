-- =====================================================
-- BRANCH MANAGEMENT TABLES
-- =====================================================

-- Branches table
CREATE TABLE branches (
    id INT PRIMARY KEY AUTO_INCREMENT,
    branch_code VARCHAR(20) UNIQUE NOT NULL,
    branch_name VARCHAR(100) NOT NULL,
    location VARCHAR(255),
    phone VARCHAR(20),
    email VARCHAR(100),
    manager VARCHAR(100),
    address TEXT,
    tax_id VARCHAR(50),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Add branch_id to existing tables
ALTER TABLE products ADD COLUMN branch_id INT DEFAULT 1 AFTER category_id;
ALTER TABLE sales ADD COLUMN branch_id INT DEFAULT 1 AFTER cashier_id;
ALTER TABLE users ADD COLUMN branch_id INT DEFAULT 1 AFTER role;
ALTER TABLE employees ADD COLUMN branch_id INT DEFAULT 1 AFTER user_id;
ALTER TABLE attendance ADD COLUMN branch_id INT DEFAULT 1 AFTER employee_id;

-- Add foreign keys
ALTER TABLE products ADD FOREIGN KEY (branch_id) REFERENCES branches(id);
ALTER TABLE sales ADD FOREIGN KEY (branch_id) REFERENCES branches(id);
ALTER TABLE users ADD FOREIGN KEY (branch_id) REFERENCES branches(id);
ALTER TABLE employees ADD FOREIGN KEY (branch_id) REFERENCES branches(id);
ALTER TABLE attendance ADD FOREIGN KEY (branch_id) REFERENCES branches(id);

-- =====================================================
-- SUPPLIER MANAGEMENT TABLES
-- =====================================================

-- Suppliers table
CREATE TABLE suppliers (
    id INT PRIMARY KEY AUTO_INCREMENT,
    supplier_code VARCHAR(50) UNIQUE NOT NULL,
    company_name VARCHAR(200) NOT NULL,
    contact_person VARCHAR(100),
    phone VARCHAR(20),
    email VARCHAR(100),
    address TEXT,
    tax_id VARCHAR(50),
    payment_terms VARCHAR(100),
    lead_time_days INT DEFAULT 7,
    rating DECIMAL(3,2) DEFAULT 5.0,
    is_active BOOLEAN DEFAULT TRUE,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Purchase Orders table
CREATE TABLE purchase_orders (
    id INT PRIMARY KEY AUTO_INCREMENT,
    po_number VARCHAR(50) UNIQUE NOT NULL,
    supplier_id INT,
    branch_id INT,
    order_date DATE,
    expected_date DATE,
    status ENUM('draft', 'sent', 'received', 'cancelled') DEFAULT 'draft',
    subtotal DECIMAL(10,2),
    tax_amount DECIMAL(10,2),
    total_amount DECIMAL(10,2),
    payment_status ENUM('pending', 'partial', 'paid') DEFAULT 'pending',
    notes TEXT,
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (supplier_id) REFERENCES suppliers(id),
    FOREIGN KEY (branch_id) REFERENCES branches(id),
    FOREIGN KEY (created_by) REFERENCES users(id)
);

-- Purchase Order Items table
CREATE TABLE po_items (
    id INT PRIMARY KEY AUTO_INCREMENT,
    po_id INT,
    product_id INT,
    quantity INT,
    unit_price DECIMAL(10,2),
    total_price DECIMAL(10,2),
    received_quantity INT DEFAULT 0,
    FOREIGN KEY (po_id) REFERENCES purchase_orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id)
);

-- =====================================================
-- STOCK TRANSFER TABLES
-- =====================================================

-- Stock Transfers table
CREATE TABLE stock_transfers (
    id INT PRIMARY KEY AUTO_INCREMENT,
    transfer_number VARCHAR(50) UNIQUE NOT NULL,
    from_branch_id INT,
    to_branch_id INT,
    transfer_date DATE,
    status ENUM('pending', 'approved', 'shipped', 'received', 'cancelled') DEFAULT 'pending',
    requested_by INT,
    approved_by INT,
    received_by INT,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (from_branch_id) REFERENCES branches(id),
    FOREIGN KEY (to_branch_id) REFERENCES branches(id),
    FOREIGN KEY (requested_by) REFERENCES users(id),
    FOREIGN KEY (approved_by) REFERENCES users(id),
    FOREIGN KEY (received_by) REFERENCES users(id)
);

-- Transfer Items table
CREATE TABLE transfer_items (
    id INT PRIMARY KEY AUTO_INCREMENT,
    transfer_id INT,
    product_id INT,
    quantity INT,
    unit_price DECIMAL(10,2),
    total_value DECIMAL(10,2),
    received_quantity INT DEFAULT 0,
    status ENUM('pending', 'partial', 'complete') DEFAULT 'pending',
    FOREIGN KEY (transfer_id) REFERENCES stock_transfers(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id)
);

-- Transfer History table
CREATE TABLE transfer_history (
    id INT PRIMARY KEY AUTO_INCREMENT,
    transfer_id INT,
    action VARCHAR(50),
    user_id INT,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (transfer_id) REFERENCES stock_transfers(id),
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- =====================================================
-- PDF REPORT SETTINGS
-- =====================================================

CREATE TABLE report_settings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    company_name VARCHAR(200),
    company_logo VARCHAR(255),
    company_address TEXT,
    company_phone VARCHAR(20),
    company_email VARCHAR(100),
    company_website VARCHAR(100),
    tax_number VARCHAR(50),
    report_footer TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- =====================================================
-- INSERT DEFAULT DATA
-- =====================================================

-- Insert default branches
INSERT INTO branches (branch_code, branch_name, location, phone, email, manager) VALUES
('HQ', 'Headquarters', 'Kigali', '+250 788 123 456', 'hq@theophile.com', 'General Manager'),
('KGL01', 'Kigali City Branch', 'Downtown Kigali', '+250 788 123 457', 'kigali@theophile.com', 'Branch Manager'),
('HYE01', 'Huye Branch', 'Butare', '+250 788 123 458', 'huye@theophile.com', 'Branch Manager'),
('MSZ01', 'Musanze Branch', 'Ruhengeri', '+250 788 123 459', 'musanze@theophile.com', 'Branch Manager');

-- Insert sample suppliers
INSERT INTO suppliers (supplier_code, company_name, contact_person, phone, email, payment_terms, lead_time_days) VALUES
('SUP001', 'Rwanda Wholesalers Ltd', 'Jean Paul', '+250 788 234 567', 'info@rwandawholesale.rw', 'Net 30', 5),
('SUP002', 'East African Distributors', 'Sarah Johnson', '+250 788 345 678', 'sales@eastafricadist.com', 'Net 15', 3),
('SUP003', 'Global Foods Inc', 'Michael Chen', '+250 788 456 789', 'orders@globalfoods.com', 'Net 45', 10),
('SUP004', 'Local Farmers Cooperative', 'Marie Claire', '+250 788 567 890', 'farmers@coop.rw', 'Cash on Delivery', 2);

-- Update existing products to HQ branch
UPDATE products SET branch_id = 1;

-- Insert report settings
INSERT INTO report_settings (company_name, company_address, company_phone, company_email, company_website, tax_number) VALUES
('Theophile POS Systems', 'KG 123 St, Kigali, Rwanda', '+250 788 123 456', 'info@theophilepos.com', 'www.theophilepos.com', 'TAX123456789');

-- =====================================================
-- CREATE INDEXES FOR PERFORMANCE
-- =====================================================

CREATE INDEX idx_branch_products ON products(branch_id);
CREATE INDEX idx_branch_sales ON sales(branch_id);
CREATE INDEX idx_transfer_status ON stock_transfers(status);
CREATE INDEX idx_po_status ON purchase_orders(status);
CREATE INDEX idx_supplier_rating ON suppliers(rating);