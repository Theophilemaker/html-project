<?php
session_start();
require_once 'config/database.php';
require_once 'check_access.php';

if(!isset($_SESSION['user_id'])) { header('Location: login.php'); exit(); }
checkAdmin();

$database = new Database();
$db = $database->getConnection();

$po_id = $_GET['id'] ?? 0;

// Get PO details
$stmt = $db->prepare("SELECT * FROM purchase_orders WHERE id = ? AND status = 'sent'");
$stmt->execute([$po_id]);
$po = $stmt->fetch(PDO::FETCH_ASSOC);

if(!$po) {
    $_SESSION['error'] = "Purchase order not found or cannot be received!";
    header('Location: purchase_orders.php');
    exit();
}

// Get PO items
$items = $db->prepare("SELECT poi.*, p.name as product_name 
    FROM po_items poi
    JOIN products p ON poi.product_id = p.id
    WHERE poi.po_id = ?");
$items->execute([$po_id]);
$po_items = $items->fetchAll(PDO::FETCH_ASSOC);

if(isset($_POST['confirm_receive'])) {
    $db->beginTransaction();
    try {
        $all_received = true;
        
        foreach($po_items as $item) {
            $received_qty = $_POST['received_' . $item['id']] ?? 0;
            
            if($received_qty > 0) {
                // Update PO item
                $stmt = $db->prepare("UPDATE po_items SET received_quantity = ? WHERE id = ?");
                $stmt->execute([$received_qty, $item['id']]);
                
                // Add to product stock
                $stmt = $db->prepare("UPDATE products SET quantity = quantity + ? WHERE id = ?");
                $stmt->execute([$received_qty, $item['product_id']]);
            }
            
            if($received_qty < $item['quantity']) {
                $all_received = false;
            }
        }
        
        // Update PO status
        $new_status = $all_received ? 'received' : 'partial';
        $stmt = $db->prepare("UPDATE purchase_orders SET status = ? WHERE id = ?");
        $stmt->execute([$new_status, $po_id]);
        
        $db->commit();
        $_SESSION['success'] = "Purchase Order #" . $po['po_number'] . " received successfully!";
        header('Location: purchase_orders.php');
        exit();
    } catch(Exception $e) {
        $db->rollBack();
        $_SESSION['error'] = "Error receiving PO: " . $e->getMessage();
        header('Location: po_details.php?id=' . $po_id);
        exit();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Receive Purchase Order - Theophile POS</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <div class="dashboard-container">
        <div class="sidebar">[sidebar code]</div>
        <div class="main-content">
            <div class="header">
                <h1><i class="fas fa-boxes"></i> Receive Purchase Order</h1>
                <div class="date"><?php echo date('l, F j, Y'); ?></div>
            </div>

            <div class="card">
                <h3>PO #<?php echo $po['po_number']; ?></h3>
                <p>Enter the quantities received:</p>

                <form method="POST">
                    <table>
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Ordered</th>
                                <th>Received</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($po_items as $item): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                                <td><?php echo $item['quantity']; ?></td>
                                <td>
                                    <input type="number" name="received_<?php echo $item['id']; ?>" 
                                           class="form-control" value="<?php echo $item['quantity']; ?>" 
                                           min="0" max="<?php echo $item['quantity']; ?>" style="width: 100px;">
                                </td>
                                <td id="status_<?php echo $item['id']; ?>">Pending</td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    
                    <div style="display: flex; gap: 10px; margin-top: 20px;">
                        <button type="submit" name="confirm_receive" class="btn" style="background: var(--success);">
                            <i class="fas fa-check-circle"></i> Confirm Receipt
                        </button>
                        <a href="po_details.php?id=<?php echo $po_id; ?>" class="btn" style="background: #999;">
                            <i class="fas fa-times"></i> Cancel
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script src="assets/js/script.js"></script>
</body>
</html>