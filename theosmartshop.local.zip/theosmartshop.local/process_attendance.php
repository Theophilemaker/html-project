<?php
session_start();
require_once 'config/database.php';
require_once 'check_access.php';

// Check login
if(!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Not logged in']);
    exit();
}

// Only admin can access
if($_SESSION['role'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Access denied']);
    exit();
}

$database = new Database();
$db = $database->getConnection();

// Get JSON input
$data = json_decode(file_get_contents('php://input'), true);

if(!$data) {
    // Try POST data if JSON fails
    $data = $_POST;
}

$response = ['success' => false, 'message' => 'Invalid request'];

if(isset($data['action']) && isset($data['employee_id'])) {
    $employee_id = intval($data['employee_id']);
    $today = date('Y-m-d');
    
    if($data['action'] == 'clock_in') {
        // Check if already clocked in today
        $check = $db->prepare("SELECT id FROM attendance WHERE employee_id = ? AND DATE(clock_in) = ? AND clock_out IS NULL");
        $check->execute([$employee_id, $today]);
        
        if($check->rowCount() == 0) {
            // Clock in
            $stmt = $db->prepare("INSERT INTO attendance (employee_id, clock_in, status) VALUES (?, NOW(), 'present')");
            if($stmt->execute([$employee_id])) {
                $response = ['success' => true, 'message' => 'Clocked in successfully'];
                
                // Log action
                if(function_exists('logAction')) {
                    logAction($db, $_SESSION['user_id'], 'Clock In', "Employee ID: $employee_id");
                }
            }
        } else {
            $response = ['success' => false, 'message' => 'Already clocked in today'];
        }
    }
    elseif($data['action'] == 'clock_out') {
        // Find active clock-in
        $stmt = $db->prepare("SELECT id, clock_in FROM attendance WHERE employee_id = ? AND DATE(clock_in) = ? AND clock_out IS NULL");
        $stmt->execute([$employee_id, $today]);
        $attendance = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if($attendance) {
            // Calculate hours worked
            $clock_in = new DateTime($attendance['clock_in']);
            $clock_out = new DateTime();
            $hours = $clock_out->diff($clock_in)->h + ($clock_out->diff($clock_in)->i / 60);
            $overtime = max(0, $hours - 8); // Overtime after 8 hours
            
            // Update
            $update = $db->prepare("UPDATE attendance SET clock_out = NOW(), hours_worked = ?, overtime_hours = ? WHERE id = ?");
            if($update->execute([round($hours, 2), round($overtime, 2), $attendance['id']])) {
                $response = ['success' => true, 'message' => 'Clocked out successfully', 'hours' => round($hours, 2)];
                
                // Log action
                if(function_exists('logAction')) {
                    logAction($db, $_SESSION['user_id'], 'Clock Out', "Employee ID: $employee_id, Hours: " . round($hours, 2));
                }
            }
        } else {
            $response = ['success' => false, 'message' => 'No active clock-in found'];
        }
    }
}

header('Content-Type: application/json');
echo json_encode($response);
?>