<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Theophile POS - Installation Wizard</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .install-container {
            max-width: 600px;
            margin: 50px auto;
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
        }
        .step {
            display: none;
        }
        .step.active {
            display: block;
            animation: slideIn 0.5s ease;
        }
        .step-indicator {
            display: flex;
            justify-content: space-between;
            margin-bottom: 30px;
            padding: 0 20px;
        }
        .step-dot {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: #e0e0e0;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            position: relative;
        }
        .step-dot.active {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        .step-dot.completed {
            background: var(--success);
        }
        .step-dot::after {
            content: '';
            position: absolute;
            top: 50%;
            left: 100%;
            width: 50px;
            height: 2px;
            background: #e0e0e0;
        }
        .step-dot:last-child::after {
            display: none;
        }
        .test-connection {
            margin-top: 10px;
            padding: 10px;
            border-radius: 5px;
            display: none;
        }
        .test-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .test-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .progress-bar {
            height: 5px;
            background: linear-gradient(90deg, var(--primary), var(--success));
            width: 0%;
            transition: width 0.3s ease;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <div class="install-container">
        <h1 style="text-align: center; color: var(--dark); margin-bottom: 30px;">
            <i class="fas fa-cash-register"></i> Theophile POS Installation
        </h1>

        <!-- Step Indicator -->
        <div class="step-indicator">
            <div class="step-dot active" id="step1-dot">1</div>
            <div class="step-dot" id="step2-dot">2</div>
            <div class="step-dot" id="step3-dot">3</div>
            <div class="step-dot" id="step4-dot">4</div>
        </div>

        <div class="progress-bar" id="progressBar"></div>

        <!-- Step 1: Welcome & Requirements Check -->
        <div class="step active" id="step1">
            <h2><i class="fas fa-check-circle"></i> System Requirements</h2>
            
            <?php
            $requirements = [
                'PHP Version >= 7.4' => version_compare(PHP_VERSION, '7.4.0', '>='),
                'PDO Extension' => extension_loaded('pdo'),
                'PDO MySQL Extension' => extension_loaded('pdo_mysql'),
                'MySQLi Extension' => extension_loaded('mysqli'),
                'GD Extension' => extension_loaded('gd'),
                'cURL Extension' => extension_loaded('curl'),
                'JSON Extension' => extension_loaded('json'),
                'Session Support' => function_exists('session_start'),
                'config/ folder writable' => is_writable(__DIR__ . '/config'),
                'assets/ folder writable' => is_writable(__DIR__ . '/assets')
            ];
            
            $all_passed = true;
            ?>
            
            <table style="width: 100%; margin: 20px 0;">
                <?php foreach($requirements as $req => $passed): ?>
                <tr>
                    <td><?php echo $req; ?></td>
                    <td style="text-align: right;">
                        <?php if($passed): ?>
                        <span style="color: var(--success);"><i class="fas fa-check-circle"></i> OK</span>
                        <?php else: ?>
                        <span style="color: var(--danger);"><i class="fas fa-times-circle"></i> Failed</span>
                        <?php $all_passed = false; ?>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </table>
            
            <?php if($all_passed): ?>
            <button onclick="nextStep(1)" class="btn" style="width: 100%;">
                <i class="fas fa-arrow-right"></i> Continue to Database Setup
            </button>
            <?php else: ?>
            <div class="notification notification-error show">
                <i class="fas fa-exclamation-triangle"></i>
                Please fix the requirements above before continuing.
            </div>
            <?php endif; ?>
        </div>

        <!-- Step 2: Database Configuration -->
        <div class="step" id="step2">
            <h2><i class="fas fa-database"></i> Database Configuration</h2>
            
            <form id="dbForm">
                <div class="form-group">
                    <label><i class="fas fa-server"></i> Database Host</label>
                    <input type="text" id="db_host" class="form-control" value="localhost" required>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-database"></i> Database Name</label>
                    <input type="text" id="db_name" class="form-control" value="theophile_pos" required>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-user"></i> Username</label>
                    <input type="text" id="db_user" class="form-control" value="root" required>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-lock"></i> Password</label>
                    <input type="password" id="db_pass" class="form-control">
                </div>
                
                <button type="button" onclick="testConnection()" class="btn" style="background: var(--primary); margin-bottom: 15px;">
                    <i class="fas fa-plug"></i> Test Connection
                </button>
                
                <div id="connectionResult" class="test-connection"></div>
            </form>
            
            <div style="display: flex; gap: 10px; margin-top: 20px;">
                <button onclick="prevStep(2)" class="btn" style="background: #6c757d;">
                    <i class="fas fa-arrow-left"></i> Back
                </button>
                <button onclick="nextStep(2)" class="btn" style="flex: 1;" id="nextToStep3" disabled>
                    Next Step <i class="fas fa-arrow-right"></i>
                </button>
            </div>
        </div>

        <!-- Step 3: Admin Account Setup -->
        <div class="step" id="step3">
            <h2><i class="fas fa-user-cog"></i> Admin Account</h2>
            
            <form id="adminForm">
                <div class="form-group">
                    <label><i class="fas fa-user"></i> Admin Username</label>
                    <input type="text" id="admin_user" class="form-control" value="admin" required>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-lock"></i> Admin Password</label>
                    <input type="password" id="admin_pass" class="form-control" required>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-id-card"></i> Full Name</label>
                    <input type="text" id="admin_name" class="form-control" value="Administrator" required>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-envelope"></i> Email</label>
                    <input type="email" id="admin_email" class="form-control" required>
                </div>
            </form>
            
            <div style="display: flex; gap: 10px; margin-top: 20px;">
                <button onclick="prevStep(3)" class="btn" style="background: #6c757d;">
                    <i class="fas fa-arrow-left"></i> Back
                </button>
                <button onclick="nextStep(3)" class="btn" style="flex: 1;">
                    Next Step <i class="fas fa-arrow-right"></i>
                </button>
            </div>
        </div>

        <!-- Step 4: Installation Progress -->
        <div class="step" id="step4">
            <h2><i class="fas fa-cog"></i> Installing...</h2>
            
            <div id="installLog" style="background: #1e1e2f; color: #0f0; padding: 15px; border-radius: 5px; font-family: monospace; height: 200px; overflow-y: auto; margin: 20px 0;">
                <div>Starting installation...</div>
            </div>
            
            <div id="installComplete" style="display: none; text-align: center;">
                <i class="fas fa-check-circle" style="font-size: 48px; color: var(--success); margin: 20px;"></i>
                <h3>Installation Complete!</h3>
                <p>Your Theophile POS system is ready to use.</p>
                <a href="login.php" class="btn" style="margin-top: 20px;">
                    <i class="fas fa-sign-in-alt"></i> Go to Login
                </a>
            </div>
        </div>
    </div>

    <script>
    let dbConfig = {};
    let currentStep = 1;

    function nextStep(step) {
        if(step === 1) {
            document.getElementById('step1').classList.remove('active');
            document.getElementById('step2').classList.add('active');
            document.getElementById('step2-dot').classList.add('active');
            document.getElementById('progressBar').style.width = '33%';
        } else if(step === 2) {
            document.getElementById('step2').classList.remove('active');
            document.getElementById('step3').classList.add('active');
            document.getElementById('step3-dot').classList.add('active');
            document.getElementById('progressBar').style.width = '66%';
        } else if(step === 3) {
            document.getElementById('step3').classList.remove('active');
            document.getElementById('step4').classList.add('active');
            document.getElementById('step4-dot').classList.add('active');
            document.getElementById('progressBar').style.width = '100%';
            
            // Start installation
            startInstallation();
        }
    }

    function prevStep(step) {
        if(step === 2) {
            document.getElementById('step2').classList.remove('active');
            document.getElementById('step1').classList.add('active');
            document.getElementById('step2-dot').classList.remove('active');
            document.getElementById('progressBar').style.width = '0%';
        } else if(step === 3) {
            document.getElementById('step3').classList.remove('active');
            document.getElementById('step2').classList.add('active');
            document.getElementById('step3-dot').classList.remove('active');
            document.getElementById('progressBar').style.width = '33%';
        }
    }

    function testConnection() {
        const host = document.getElementById('db_host').value;
        const name = document.getElementById('db_name').value;
        const user = document.getElementById('db_user').value;
        const pass = document.getElementById('db_pass').value;
        
        dbConfig = { host, name, user, pass };
        
        const result = document.getElementById('connectionResult');
        result.style.display = 'block';
        result.innerHTML = 'Testing connection...';
        result.className = 'test-connection';
        
        // Simulate connection test (in production, make AJAX call)
        setTimeout(() => {
            result.innerHTML = '<i class="fas fa-check-circle"></i> Connection successful!';
            result.classList.add('test-success');
            document.getElementById('nextToStep3').disabled = false;
        }, 1500);
    }

    function startInstallation() {
        const log = document.getElementById('installLog');
        
        const steps = [
            'Creating database configuration...',
            'Testing database connection...',
            'Creating database tables...',
            'Inserting default data...',
            'Creating admin account...',
            'Setting file permissions...',
            'Cleaning up installation files...',
            'Installation complete!'
        ];
        
        let i = 0;
        const interval = setInterval(() => {
            if(i < steps.length) {
                log.innerHTML += '<div>✓ ' + steps[i] + '</div>';
                log.scrollTop = log.scrollHeight;
                i++;
            } else {
                clearInterval(interval);
                document.getElementById('installComplete').style.display = 'block';
                
                // Create installation lock file
                fetch('install_complete.php', {
                    method: 'POST',
                    body: JSON.stringify({ completed: true })
                });
            }
        }, 1000);
    }
    </script>
</body>
</html>