<?php
session_start();
require_once 'config/database.php';
require_once 'check_access.php';
require_once 'tcpdf/tcpdf.php';

if(!isset($_SESSION['user_id'])) { header('Location: login.php'); exit(); }
checkAdmin();

$database = new Database();
$db = $database->getConnection();

$branch_id = $_GET['branch'] ?? 1;
$month = $_GET['month'] ?? date('Y-m');

// Get branch details
$stmt = $db->prepare("SELECT * FROM branches WHERE id = ?");
$stmt->execute([$branch_id]);
$branch = $stmt->fetch(PDO::FETCH_ASSOC);

// Get branch statistics
$stats = $db->prepare("SELECT 
    (SELECT COUNT(*) FROM products WHERE branch_id = ?) as total_products,
    (SELECT COUNT(*) FROM employees WHERE branch_id = ?) as total_employees,
    (SELECT COUNT(*) FROM users WHERE branch_id = ?) as total_users,
    (SELECT COALESCE(SUM(total_price),0) FROM sales WHERE branch_id = ? AND MONTH(sale_date) = MONTH(CURDATE())) as monthly_sales,
    (SELECT COALESCE(SUM(total_price),0) FROM sales WHERE branch_id = ? AND DATE(sale_date) = CURDATE()) as today_sales,
    (SELECT COALESCE(SUM(quantity),0) FROM transfer_items ti JOIN stock_transfers st ON ti.transfer_id = st.id WHERE st.to_branch_id = ? AND st.status = 'received') as received_stock,
    (SELECT COALESCE(SUM(quantity),0) FROM transfer_items ti JOIN stock_transfers st ON ti.transfer_id = st.id WHERE st.from_branch_id = ? AND st.status = 'shipped') as sent_stock
    FROM dual");
$stats->execute([$branch_id, $branch_id, $branch_id, $branch_id, $branch_id, $branch_id, $branch_id]);
$data = $stats->fetch(PDO::FETCH_ASSOC);

// Get top products
$top_products = $db->prepare("SELECT p.name, SUM(s.quantity) as qty, SUM(s.total_price) as revenue
    FROM sales s
    JOIN products p ON s.product_id = p.id
    WHERE s.branch_id = ? AND MONTH(s.sale_date) = MONTH(CURDATE())
    GROUP BY p.id
    ORDER BY revenue DESC
    LIMIT 10");
$top_products->execute([$branch_id]);
$products = $top_products->fetchAll(PDO::FETCH_ASSOC);

// Get daily sales for chart
$daily = $db->prepare("SELECT 
    DATE(sale_date) as date,
    COUNT(*) as transactions,
    SUM(total_price) as total
    FROM sales
    WHERE branch_id = ? AND MONTH(sale_date) = MONTH(CURDATE())
    GROUP BY DATE(sale_date)
    ORDER BY sale_date");
$daily->execute([$branch_id]);
$daily_sales = $daily->fetchAll(PDO::FETCH_ASSOC);

// Create PDF
class BranchPDF extends TCPDF {
    public function Header() {
        $this->SetFont('helvetica', 'B', 16);
        $this->Cell(0, 15, 'Branch Performance Report', 0, false, 'C', 0, '', 0, false, 'M', 'M');
        $this->Ln(10);
    }
    
    public function Footer() {
        $this->SetY(-15);
        $this->SetFont('helvetica', 'I', 8);
        $this->Cell(0, 10, 'Page '.$this->getAliasNumPage().'/'.$this->getAliasNbPages(), 0, false, 'C', 0, '', 0, false, 'T', 'M');
    }
}

$pdf = new BranchPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
$pdf->SetCreator('Theophile POS');
$pdf->SetAuthor('Theophile POS');
$pdf->SetTitle('Branch Report - ' . $branch['branch_name']);
$pdf->SetMargins(15, 30, 15);
$pdf->AddPage();

// Branch Info
$pdf->SetFont('helvetica', 'B', 14);
$pdf->Cell(0, 10, $branch['branch_name'], 0, 1, 'L');
$pdf->SetFont('helvetica', '', 10);
$pdf->Cell(0, 5, 'Code: ' . $branch['branch_code'], 0, 1, 'L');
$pdf->Cell(0, 5, 'Location: ' . $branch['location'], 0, 1, 'L');
$pdf->Cell(0, 5, 'Manager: ' . $branch['manager'], 0, 1, 'L');
$pdf->Cell(0, 5, 'Phone: ' . $branch['phone'], 0, 1, 'L');
$pdf->Cell(0, 5, 'Email: ' . $branch['email'], 0, 1, 'L');
$pdf->Ln(10);

// Statistics
$pdf->SetFillColor(67, 97, 238);
$pdf->SetTextColor(255, 255, 255);
$pdf->SetFont('helvetica', 'B', 12);
$pdf->Cell(0, 10, 'Branch Statistics', 0, 1, 'L', true);
$pdf->SetTextColor(0, 0, 0);
$pdf->SetFont('helvetica', '', 10);

$html = '
<table border="1" cellpadding="5">
    <tr>
        <td><strong>Total Products:</strong> ' . $data['total_products'] . '</td>
        <td><strong>Total Employees:</strong> ' . $data['total_employees'] . '</td>
    </tr>
    <tr>
        <td><strong>Today\'s Sales:</strong> ' . number_format($data['today_sales']) . ' RWF</td>
        <td><strong>Monthly Sales:</strong> ' . number_format($data['monthly_sales']) . ' RWF</td>
    </tr>
    <tr>
        <td><strong>Stock Received:</strong> ' . $data['received_stock'] . ' units</td>
        <td><strong>Stock Sent:</strong> ' . $data['sent_stock'] . ' units</td>
    </tr>
</table>';
$pdf->writeHTML($html, true, false, true, false, '');
$pdf->Ln(10);

// Top Products
$pdf->SetFillColor(67, 97, 238);
$pdf->SetTextColor(255, 255, 255);
$pdf->SetFont('helvetica', 'B', 12);
$pdf->Cell(0, 10, 'Top Selling Products', 0, 1, 'L', true);
$pdf->SetTextColor(0, 0, 0);

$html = '<table border="1" cellpadding="5">
    <tr style="background-color: #f0f0f0;">
        <th>Product</th>
        <th>Quantity Sold</th>
        <th>Revenue</th>
    </tr>';
foreach($products as $p) {
    $html .= '<tr>
        <td>' . $p['name'] . '</td>
        <td>' . $p['qty'] . '</td>
        <td>' . number_format($p['revenue']) . ' RWF</td>
    </tr>';
}
$html .= '</table>';
$pdf->writeHTML($html, true, false, true, false, '');

// Daily Sales
$pdf->Ln(5);
$pdf->SetFillColor(67, 97, 238);
$pdf->SetTextColor(255, 255, 255);
$pdf->SetFont('helvetica', 'B', 12);
$pdf->Cell(0, 10, 'Daily Sales - ' . date('F Y'), 0, 1, 'L', true);
$pdf->SetTextColor(0, 0, 0);

$html = '<table border="1" cellpadding="5">
    <tr style="background-color: #f0f0f0;">
        <th>Date</th>
        <th>Transactions</th>
        <th>Total Sales</th>
    </tr>';
foreach($daily_sales as $d) {
    $html .= '<tr>
        <td>' . $d['date'] . '</td>
        <td>' . $d['transactions'] . '</td>
        <td>' . number_format($d['total']) . ' RWF</td>
    </tr>';
}
$html .= '</table>';
$pdf->writeHTML($html, true, false, true, false, '');

$pdf->Output('Branch_Report_' . $branch['branch_code'] . '.pdf', 'I');
?>