<?php
session_start();
require_once 'config/database.php';
require_once 'check_access.php';

// Check login and admin status
if(!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

checkAdmin(); // Only admin can access this page

$database = new Database();
$db = $database->getConnection();

// Handle Add User
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_user'])) {
    $username = trim($_POST['username']);
    $password = md5($_POST['password']); // In production, use password_hash()
    $full_name = trim($_POST['full_name']);
    $role = $_POST['role'];
    
    // Check if username exists
    $check = $db->prepare("SELECT id FROM users WHERE username = :username");
    $check->bindParam(':username', $username);
    $check->execute();
    
    if($check->rowCount() > 0) {
        $_SESSION['error'] = "❌ Username already exists!";
    } else {
        $query = "INSERT INTO users (username, password, full_name, role) 
                  VALUES (:username, :password, :full_name, :role)";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':username', $username);
        $stmt->bindParam(':password', $password);
        $stmt->bindParam(':full_name', $full_name);
        $stmt->bindParam(':role', $role);
        
        if ($stmt->execute()) {
            $_SESSION['success'] = "✅ User added successfully!";
        } else {
            $_SESSION['error'] = "❌ Error adding user.";
        }
    }
    header('Location: users.php');
    exit();
}

// Handle Toggle User Status
if (isset($_GET['toggle']) && $_GET['toggle'] != $_SESSION['user_id']) {
    $id = $_GET['toggle'];
    $query = "UPDATE users SET is_active = NOT is_active WHERE id = :id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    $_SESSION['success'] = "✅ User status updated!";
    header('Location: users.php');
    exit();
}

// Handle Delete User
if (isset($_GET['delete']) && $_GET['delete'] != $_SESSION['user_id']) {
    $id = $_GET['delete'];
    
    // Check if user has sales
    $check = $db->prepare("SELECT id FROM sales WHERE cashier_id = :id LIMIT 1");
    $check->bindParam(':id', $id);
    $check->execute();
    
    if($check->rowCount() > 0) {
        $_SESSION['error'] = "❌ Cannot delete user with sales history!";
    } else {
        $query = "DELETE FROM users WHERE id = :id";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':id', $id);
        
        if ($stmt->execute()) {
            $_SESSION['success'] = "✅ User deleted successfully!";
        } else {
            $_SESSION['error'] = "❌ Error deleting user.";
        }
    }
    header('Location: users.php');
    exit();
}

// Get all users with statistics
$query = "SELECT u.*, 
          (SELECT COUNT(*) FROM sales WHERE cashier_id = u.id) as total_sales,
          (SELECT COALESCE(SUM(total_price), 0) FROM sales WHERE cashier_id = u.id) as total_amount,
          (SELECT MAX(sale_date) FROM sales WHERE cashier_id = u.id) as last_sale
          FROM users u 
          ORDER BY 
            CASE WHEN u.role = 'admin' THEN 1 ELSE 2 END,
            u.created_at DESC";
$stmt = $db->prepare($query);
$stmt->execute();
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Theophile POS - User Management</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        
<!-- SIDEBAR - NEW VERSION WITH ALL MENU ITEMS -->
<div class="sidebar">
    <div class="logo">
        <h2><i class="fas fa-cash-register"></i> Theophile</h2>
    </div>
    
    <!-- User Info -->
    <div class="user-info">
        <?php 
        if($_SESSION['role'] === 'admin') {
            echo '<span class="role-badge role-admin"><i class="fas fa-crown"></i> ADMIN</span>';
        } else {
            echo '<span class="role-badge role-cashier"><i class="fas fa-user"></i> CASHIER</span>';
        }
        ?>
        <p><i class="fas fa-user"></i> <?php echo htmlspecialchars($_SESSION['full_name']); ?></p>
        <p><i class="fas fa-building"></i> Branch: 
            <?php
            // Get user's branch
            if(isset($db)) {
                $branch_stmt = $db->prepare("SELECT branch_name FROM branches WHERE id = ?");
                $branch_stmt->execute([$_SESSION['branch_id'] ?? 1]);
                $user_branch = $branch_stmt->fetchColumn();
                echo $user_branch ?: 'Headquarters';
            } else {
                echo 'All Branches';
            }
            ?>
        </p>
    </div>
    
    <!-- Navigation Links -->
    <ul class="nav-links">
        <!-- DASHBOARD -->
        <li>
            <a href="index.php" <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-home"></i> <span>Dashboard</span>
            </a>
        </li>
        
        <!-- PRODUCTS -->
        <li>
            <a href="products.php" <?php echo basename($_SERVER['PHP_SELF']) == 'products.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-box"></i> <span>Products</span>
            </a>
        </li>
        
        <!-- ADMIN ONLY SECTION -->
        <?php if($_SESSION['role'] === 'admin'): ?>
        
        <!-- ===== BRANCH MANAGEMENT ===== -->
        <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
            <span>🏢 BRANCH MANAGEMENT</span>
        </li>
        
        <li>
            <a href="branches.php" <?php echo basename($_SERVER['PHP_SELF']) == 'branches.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-building"></i> <span>Branches</span>
            </a>
        </li>
        
        <!-- ===== SUPPLIER MANAGEMENT ===== -->
        <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
            <span>🤝 SUPPLIER MANAGEMENT</span>
        </li>
        
        <li>
            <a href="suppliers.php" <?php echo basename($_SERVER['PHP_SELF']) == 'suppliers.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-truck"></i> <span>Suppliers</span>
            </a>
        </li>
        
        <li>
            <a href="purchase_orders.php" <?php echo basename($_SERVER['PHP_SELF']) == 'purchase_orders.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-file-invoice"></i> <span>Purchase Orders</span>
            </a>
        </li>
        
        <li>
            <a href="supplier_performance.php" <?php echo basename($_SERVER['PHP_SELF']) == 'supplier_performance.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-chart-line"></i> <span>Supplier Analytics</span>
            </a>
        </li>
        
        <!-- ===== STOCK TRANSFERS ===== -->
        <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
            <span>🔄 STOCK TRANSFERS</span>
        </li>
        
        <li>
            <a href="transfers.php" <?php echo basename($_SERVER['PHP_SELF']) == 'transfers.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-exchange-alt"></i> <span>All Transfers</span>
            </a>
        </li>
        
        <!-- ===== REPORTS ===== -->
        <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
            <span>📊 REPORTS</span>
        </li>
        
        <li>
            <a href="reports.php" <?php echo basename($_SERVER['PHP_SELF']) == 'reports.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-chart-bar"></i> <span>Sales Reports</span>
            </a>
        </li>
        
        <li>
            <a href="tax_reports.php" <?php echo basename($_SERVER['PHP_SELF']) == 'tax_reports.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-percent"></i> <span>Tax Reports</span>
            </a>
        </li>
        
        <li>
            <a href="business_intelligence.php" <?php echo basename($_SERVER['PHP_SELF']) == 'business_intelligence.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-chart-line"></i> <span>Business IQ</span>
            </a>
        </li>
        
        <!-- ===== HR MANAGEMENT ===== -->
        <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
            <span>👥 HR MANAGEMENT</span>
        </li>
        
        <li>
            <a href="employees.php" <?php echo basename($_SERVER['PHP_SELF']) == 'employees.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-users"></i> <span>Employees</span>
            </a>
        </li>
        
        <li>
            <a href="attendance.php" <?php echo basename($_SERVER['PHP_SELF']) == 'attendance.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-clock"></i> <span>Attendance</span>
            </a>
        </li>
        
        <li>
            <a href="payroll.php" <?php echo basename($_SERVER['PHP_SELF']) == 'payroll.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-wallet"></i> <span>Payroll</span>
            </a>
        </li>
        
        <!-- ===== SYSTEM ===== -->
        <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
            <span>⚙️ SYSTEM</span>
        </li>
        
        <li>
            <a href="users.php" <?php echo basename($_SERVER['PHP_SELF']) == 'users.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-users-cog"></i> <span>Users</span>
            </a>
        </li>
        
        <?php endif; ?> <!-- End Admin Only -->
        
        <!-- LOGOUT - Always visible -->
        <li style="margin-top: auto; border-top: 1px solid rgba(255,255,255,0.1); padding-top: 10px;">
            <a href="logout.php">
                <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
            </a>
        </li>
    </ul>
</div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1><i class="fas fa-users-cog"></i> User Management</h1>
                <div style="display: flex; gap: 15px; align-items: center;">
                    <?php echo getRoleBadge($_SESSION['role']); ?>
                    <div class="date">
                        <i class="fas fa-calendar-alt"></i> 
                        <?php echo date('l, F j, Y'); ?>
                    </div>
                </div>
            </div>

            <!-- Notifications -->
            <?php if(isset($_SESSION['success'])): ?>
            <div class="notification notification-success show" id="notification">
                <i class="fas fa-check-circle"></i>
                <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
            </div>
            <?php endif; ?>

            <?php if(isset($_SESSION['error'])): ?>
            <div class="notification notification-error show" id="notification">
                <i class="fas fa-exclamation-circle"></i>
                <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
            </div>
            <?php endif; ?>

            <!-- Add User Form -->
            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-user-plus" style="color: var(--success-color);"></i> Add New User</h3>
                    <span class="role-badge role-admin">ADMIN ONLY</span>
                </div>
                <form method="POST" action="">
                    <div class="grid-2">
                        <div class="form-group">
                            <label><i class="fas fa-user"></i> Username</label>
                            <input type="text" name="username" class="form-control" placeholder="Enter username" required>
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-id-card"></i> Full Name</label>
                            <input type="text" name="full_name" class="form-control" placeholder="Enter full name" required>
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-lock"></i> Password</label>
                            <input type="password" name="password" class="form-control" placeholder="Enter password" required>
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-tag"></i> Role</label>
                            <select name="role" class="form-control" required>
                                <option value="cashier">Cashier</option>
                                <option value="admin">Admin</option>
                            </select>
                        </div>
                    </div>
                    <button type="submit" name="add_user" class="btn glow-effect">
                        <i class="fas fa-save"></i> Add User
                    </button>
                </form>
            </div>

            <!-- Users List -->
            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-list"></i> System Users</h3>
                    <div class="search-box">
                        <input type="text" id="searchInput" class="form-control" placeholder="🔍 Search users...">
                        <i class="fas fa-search"></i>
                    </div>
                </div>

                <!-- Stats Summary -->
                <div style="display: flex; gap: 20px; margin-bottom: 20px; padding: 15px; background: #f8f9fa; border-radius: 10px;">
                    <div><strong>Total Users:</strong> <?php echo count($users); ?></div>
                    <div><strong>Admins:</strong> <?php echo count(array_filter($users, function($u) { return $u['role'] == 'admin'; })); ?></div>
                    <div><strong>Cashiers:</strong> <?php echo count(array_filter($users, function($u) { return $u['role'] == 'cashier'; })); ?></div>
                    <div><strong>Active:</strong> <?php echo count(array_filter($users, function($u) { return $u['is_active']; })); ?></div>
                </div>

                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Username</th>
                                <th>Full Name</th>
                                <th>Role</th>
                                <th>Status</th>
                                <th>Total Sales</th>
                                <th>Sales Amount</th>
                                <th>Last Login</th>
                                <th>Last Sale</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($users as $user): ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($user['username']); ?></strong></td>
                                <td><?php echo htmlspecialchars($user['full_name']); ?></td>
                                <td>
                                    <?php echo getRoleBadge($user['role']); ?>
                                </td>
                                <td>
                                    <?php if($user['is_active']): ?>
                                    <span class="status-normal"><i class="fas fa-circle"></i> Active</span>
                                    <?php else: ?>
                                    <span class="status-low"><i class="fas fa-circle"></i> Inactive</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo $user['total_sales']; ?> transactions</td>
                                <td><?php echo number_format($user['total_amount']); ?> RWF</td>
                                <td><?php echo $user['last_login'] ? date('d-m-Y H:i', strtotime($user['last_login'])) : 'Never'; ?></td>
                                <td><?php echo $user['last_sale'] ? date('d-m-Y', strtotime($user['last_sale'])) : 'No sales'; ?></td>
                                <td>
                                    <?php if($user['id'] != $_SESSION['user_id']): ?>
                                    <a href="?toggle=<?php echo $user['id']; ?>" class="btn-small" style="background: <?php echo $user['is_active'] ? '#f8961e' : '#4cc9f0'; ?>;" title="<?php echo $user['is_active'] ? 'Deactivate' : 'Activate'; ?>">
                                        <i class="fas fa-toggle-<?php echo $user['is_active'] ? 'on' : 'off'; ?>"></i>
                                    </a>
                                    <a href="?delete=<?php echo $user['id']; ?>" 
                                       onclick="return confirm('⚠️ Are you sure you want to delete <?php echo htmlspecialchars($user['full_name']); ?>?')" 
                                       class="btn-small" style="background: var(--danger-color);" title="Delete">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                    <?php else: ?>
                                    <span class="btn-small" style="background: #999; cursor: not-allowed;" title="Current user">
                                        <i class="fas fa-user"></i>
                                    </span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="assets/js/script.js"></script>
    <script>
        // Search functionality
        document.getElementById('searchInput').addEventListener('keyup', function() {
            const searchTerm = this.value.toLowerCase();
            const rows = document.querySelectorAll('tbody tr');
            
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                if(text.includes(searchTerm)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        });

        // Auto-hide notifications
        setTimeout(() => {
            const notification = document.getElementById('notification');
            if(notification) {
                notification.classList.remove('show');
            }
        }, 3000);
    </script>
</body>
</html>