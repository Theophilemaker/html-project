<?php
echo "<h2>🔍 System Path Finder</h2>";
echo "<p>This file is located at: <strong>" . __FILE__ . "</strong></p>";
echo "<p>Document Root: <strong>" . $_SERVER['DOCUMENT_ROOT'] . "</strong></p>";
echo "<p>Current Script: <strong>" . $_SERVER['SCRIPT_NAME'] . "</strong></p>";
echo "<p>Server Name: <strong>" . $_SERVER['SERVER_NAME'] . "</strong></p>";
echo "<p>Port: <strong>" . $_SERVER['SERVER_PORT'] . "</strong></p>";
echo "<hr>";

// List all files in current directory
echo "<h3>Files in this directory:</h3>";
$files = scandir(__DIR__);
echo "<ul>";
foreach($files as $file) {
    if($file != '.' && $file != '..') {
        echo "<li>" . ($file == 'find_me.php' ? "<strong style='color:green'>$file ⬅️ THIS FILE</strong>" : $file) . "</li>";
    }
}
echo "</ul>";
?>