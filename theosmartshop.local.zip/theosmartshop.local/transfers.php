<?php
session_start();
require_once 'config/database.php';
require_once 'check_access.php';

if(!isset($_SESSION['user_id'])) { 
    header('Location: login.php'); 
    exit(); 
}

// Only admin can manage transfers
if($_SESSION['role'] !== 'admin') {
    $_SESSION['error'] = "Access Denied!";
    header('Location: index.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();

// Get all transfers
$transfers = $db->query("SELECT t.*, 
    from_b.branch_name as from_branch, 
    to_b.branch_name as to_branch,
    req.full_name as requested_by
    FROM stock_transfers t
    JOIN branches from_b ON t.from_branch_id = from_b.id
    JOIN branches to_b ON t.to_branch_id = to_b.id
    LEFT JOIN users req ON t.requested_by = req.id
    ORDER BY t.created_at DESC")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Theophile POS - Stock Transfers</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .transfer-card {
            background: white;
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            border-left: 5px solid;
        }
        .transfer-card:hover {
            transform: translateX(5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.15);
        }
        .status-pending { border-left-color: var(--warning); }
        .status-approved { border-left-color: var(--primary); }
        .status-shipped { border-left-color: #17a2b8; }
        .status-received { border-left-color: var(--success); }
        .status-cancelled { border-left-color: var(--danger); }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="logo">
                <h2><i class="fas fa-cash-register"></i> Theophile</h2>
            </div>
            <div class="user-info">
                <span class="role-badge role-admin">ADMIN</span>
                <p><i class="fas fa-user"></i> <?php echo htmlspecialchars($_SESSION['full_name']); ?></p>
            </div>
            <ul class="nav-links">
                <li><a href="index.php"><i class="fas fa-home"></i> <span>Dashboard</span></a></li>
                <li><a href="products.php"><i class="fas fa-box"></i> <span>Products</span></a></li>
                <li><a href="branches.php"><i class="fas fa-building"></i> <span>Branches</span></a></li>
                <li><a href="suppliers.php"><i class="fas fa-truck"></i> <span>Suppliers</span></a></li>
                <li><a href="purchase_orders.php"><i class="fas fa-file-invoice"></i> <span>Purchase Orders</span></a></li>
                <li><a href="transfers.php" class="active"><i class="fas fa-exchange-alt"></i> <span>Transfers</span></a></li>
                <li><a href="reports.php"><i class="fas fa-chart-bar"></i> <span>Reports</span></a></li>
                <li><a href="users.php"><i class="fas fa-users-cog"></i> <span>Users</span></a></li>
                <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> <span>Logout</span></a></li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1><i class="fas fa-exchange-alt"></i> Stock Transfers</h1>
                <div class="date">
                    <i class="fas fa-calendar-alt"></i> <?php echo date('l, F j, Y'); ?>
                </div>
            </div>

            <?php if(isset($_SESSION['success'])): ?>
            <div class="notification notification-success show"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
            <?php endif; ?>

            <?php if(isset($_SESSION['error'])): ?>
            <div class="notification notification-error show"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
            <?php endif; ?>

            <!-- New Transfer Button -->
            
<a href="create_transfer.php" class="btn" style="margin-bottom: 20px;">
    <i class="fas fa-plus-circle"></i> New Stock Transfer
</a>

            <!-- Transfers List -->
            <?php if(empty($transfers)): ?>
            <div class="card" style="text-align: center; padding: 40px;">
                <i class="fas fa-exchange-alt" style="font-size: 48px; color: #ccc; margin-bottom: 15px;"></i>
                <h3>No Transfers Found</h3>
                <p>Click "New Stock Transfer" to create your first transfer.</p>
            </div>
            <?php else: ?>
                <?php foreach($transfers as $transfer): ?>
                <div class="transfer-card status-<?php echo $transfer['status']; ?>">
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <div>
                            <h3 style="margin: 0;">Transfer #<?php echo $transfer['transfer_number']; ?></h3>
                            <p style="color: #666; margin: 5px 0;">
                                <i class="fas fa-store"></i> <?php echo htmlspecialchars($transfer['from_branch']); ?>
                                <i class="fas fa-arrow-right"></i>
                                <i class="fas fa-store"></i> <?php echo htmlspecialchars($transfer['to_branch']); ?>
                            </p>
                            <small>Requested by: <?php echo htmlspecialchars($transfer['requested_by'] ?? 'System'); ?></small>
                        </div>
                        <div style="text-align: right;">
                            <span style="padding: 3px 10px; border-radius: 15px; background: <?php 
                                echo $transfer['status'] == 'received' ? '#d4edda' : 
                                    ($transfer['status'] == 'approved' ? '#cce5ff' : 
                                    ($transfer['status'] == 'shipped' ? '#d1ecf1' : 
                                    ($transfer['status'] == 'pending' ? '#fff3cd' : '#f8d7da'))); 
                            ?>;">
                                <?php echo ucfirst($transfer['status']); ?>
                            </span>
                        </div>
                    </div>
                    <div style="margin-top: 10px;">
                        <small>Date: <?php echo date('d/m/Y', strtotime($transfer['transfer_date'])); ?></small>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <script>
        setTimeout(() => {
            document.querySelectorAll('.notification').forEach(n => n.classList.remove('show'));
        }, 3000);
    </script>
    <script src="assets/js/script.js"></script>
</body>
</html>