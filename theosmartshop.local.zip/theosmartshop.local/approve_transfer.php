<?php
session_start();
require_once 'config/database.php';
require_once 'check_access.php';

if(!isset($_SESSION['user_id'])) { header('Location: login.php'); exit(); }
checkAdmin();

$database = new Database();
$db = $database->getConnection();

$transfer_id = $_GET['id'] ?? 0;

// Check if transfer exists and is pending
$stmt = $db->prepare("SELECT * FROM stock_transfers WHERE id = ? AND status = 'pending'");
$stmt->execute([$transfer_id]);
$transfer = $stmt->fetch(PDO::FETCH_ASSOC);

if(!$transfer) {
    $_SESSION['error'] = "Transfer not found or cannot be approved!";
    header('Location: transfers.php');
    exit();
}

// Check stock availability
$items = $db->prepare("SELECT ti.*, p.name, p.quantity as available_stock 
    FROM transfer_items ti
    JOIN products p ON ti.product_id = p.id
    WHERE ti.transfer_id = ?");
$items->execute([$transfer_id]);
$transfer_items = $items->fetchAll(PDO::FETCH_ASSOC);

$insufficient_stock = [];
foreach($transfer_items as $item) {
    if($item['quantity'] > $item['available_stock']) {
        $insufficient_stock[] = $item['name'] . " (Need: " . $item['quantity'] . ", Available: " . $item['available_stock'] . ")";
    }
}

if(!empty($insufficient_stock)) {
    $_SESSION['error'] = "Insufficient stock for: " . implode(", ", $insufficient_stock);
    header('Location: transfer_details.php?id=' . $transfer_id);
    exit();
}

if(isset($_POST['confirm_approve'])) {
    $db->beginTransaction();
    try {
        // Update transfer status
        $stmt = $db->prepare("UPDATE stock_transfers SET status = 'approved', approved_by = ? WHERE id = ?");
        $stmt->execute([$_SESSION['user_id'], $transfer_id]);
        
        // Log history
        $stmt = $db->prepare("INSERT INTO transfer_history (transfer_id, action, user_id, notes) VALUES (?, 'approved', ?, ?)");
        $stmt->execute([$transfer_id, $_SESSION['user_id'], $_POST['notes'] ?? '']);
        
        $db->commit();
        $_SESSION['success'] = "Transfer #" . $transfer['transfer_number'] . " approved successfully!";
        header('Location: transfer_details.php?id=' . $transfer_id);
        exit();
    } catch(Exception $e) {
        $db->rollBack();
        $_SESSION['error'] = "Error approving transfer: " . $e->getMessage();
        header('Location: transfer_details.php?id=' . $transfer_id);
        exit();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Approve Transfer - Theophile POS</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <div class="dashboard-container">
        <div class="sidebar">[sidebar code]</div>
        <div class="main-content">
            <div class="header">
                <h1><i class="fas fa-check-circle"></i> Approve Transfer</h1>
                <div class="date"><?php echo date('l, F j, Y'); ?></div>
            </div>

            <div class="card">
                <h3>Transfer #<?php echo $transfer['transfer_number']; ?></h3>
                <p>Are you sure you want to approve this transfer?</p>
                
                <?php if(!empty($insufficient_stock)): ?>
                <div class="notification notification-error show">
                    <strong>⚠️ Insufficient Stock Warning!</strong><br>
                    <?php echo implode("<br>", $insufficient_stock); ?>
                </div>
                <?php endif; ?>

                <form method="POST">
                    <div class="form-group">
                        <label>Approval Notes (Optional)</label>
                        <textarea name="notes" class="form-control" rows="3"></textarea>
                    </div>
                    
                    <div style="display: flex; gap: 10px; margin-top: 20px;">
                        <button type="submit" name="confirm_approve" class="btn" style="background: var(--success);">
                            <i class="fas fa-check"></i> Confirm Approval
                        </button>
                        <a href="transfer_details.php?id=<?php echo $transfer_id; ?>" class="btn" style="background: #999;">
                            <i class="fas fa-times"></i> Cancel
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script src="assets/js/script.js"></script>
</body>
</html>