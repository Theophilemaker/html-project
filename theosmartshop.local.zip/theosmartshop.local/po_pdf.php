<?php
session_start();
require_once 'config/database.php';
require_once 'check_access.php';
require_once 'tcpdf/tcpdf.php';

if(!isset($_SESSION['user_id'])) { header('Location: login.php'); exit(); }

$database = new Database();
$db = $database->getConnection();

$po_id = $_GET['id'] ?? 0;

// Get PO details
$stmt = $db->prepare("SELECT po.*, s.company_name as supplier, s.phone as supplier_phone, s.email as supplier_email,
    s.address as supplier_address, b.branch_name, u.full_name as created_by_name
    FROM purchase_orders po
    JOIN suppliers s ON po.supplier_id = s.id
    JOIN branches b ON po.branch_id = b.id
    LEFT JOIN users u ON po.created_by = u.id
    WHERE po.id = ?");
$stmt->execute([$po_id]);
$po = $stmt->fetch(PDO::FETCH_ASSOC);

if(!$po) {
    die("Purchase order not found!");
}

// Get PO items
$items = $db->prepare("SELECT poi.*, p.name as product_name 
    FROM po_items poi
    JOIN products p ON poi.product_id = p.id
    WHERE poi.po_id = ?");
$items->execute([$po_id]);
$po_items = $items->fetchAll(PDO::FETCH_ASSOC);

// Create PDF
class POPDF extends TCPDF {
    public function Header() {
        $this->SetFont('helvetica', 'B', 16);
        $this->Cell(0, 15, 'PURCHASE ORDER', 0, false, 'C', 0, '', 0, false, 'M', 'M');
        $this->Ln(10);
    }
    
    public function Footer() {
        $this->SetY(-15);
        $this->SetFont('helvetica', 'I', 8);
        $this->Cell(0, 10, 'Page '.$this->getAliasNumPage().'/'.$this->getAliasNbPages(), 0, false, 'C', 0, '', 0, false, 'T', 'M');
    }
}

$pdf = new POPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
$pdf->SetCreator('Theophile POS');
$pdf->SetAuthor('Theophile POS');
$pdf->SetTitle('Purchase Order #' . $po['po_number']);
$pdf->SetMargins(15, 30, 15);
$pdf->AddPage();

// Company Info
$pdf->SetFont('helvetica', 'B', 12);
$pdf->Cell(0, 5, 'Theophile POS Systems', 0, 1, 'L');
$pdf->SetFont('helvetica', '', 10);
$pdf->Cell(0, 5, 'KG 123 St, Kigali, Rwanda', 0, 1, 'L');
$pdf->Cell(0, 5, 'Tel: +250 788 123 456', 0, 1, 'L');
$pdf->Cell(0, 5, 'Email: info@theophilepos.com', 0, 1, 'L');
$pdf->Ln(10);

// PO Number and Date
$pdf->SetFont('helvetica', 'B', 14);
$pdf->Cell(0, 10, 'PURCHASE ORDER #' . $po['po_number'], 0, 1, 'R');
$pdf->SetFont('helvetica', '', 10);
$pdf->Cell(0, 5, 'Date: ' . date('F j, Y', strtotime($po['order_date'])), 0, 1, 'R');
$pdf->Cell(0, 5, 'Expected Delivery: ' . date('F j, Y', strtotime($po['expected_date'])), 0, 1, 'R');
$pdf->Ln(10);

// Supplier and Branch Info
$html = '
<table border="1" cellpadding="5">
    <tr>
        <td width="50%"><strong>SUPPLIER:</strong><br>
            ' . $po['supplier'] . '<br>
            ' . $po['supplier_address'] . '<br>
            Tel: ' . $po['supplier_phone'] . '<br>
            Email: ' . $po['supplier_email'] . '
        </td>
        <td width="50%"><strong>SHIP TO:</strong><br>
            ' . $po['branch_name'] . ' Branch<br>
            Theophile POS Systems<br>
            KG 123 St, Kigali, Rwanda
        </td>
    </tr>
</table>';
$pdf->writeHTML($html, true, false, true, false, '');
$pdf->Ln(10);

// Items Table
$html = '<table border="1" cellpadding="5">
    <tr style="background-color: #f0f0f0; font-weight: bold;">
        <th>Item</th>
        <th>Quantity</th>
        <th>Unit Price</th>
        <th>Total</th>
    </tr>';
foreach($po_items as $item) {
    $html .= '<tr>
        <td>' . $item['product_name'] . '</td>
        <td>' . $item['quantity'] . '</td>
        <td>' . number_format($item['unit_price']) . ' RWF</td>
        <td>' . number_format($item['total_price']) . ' RWF</td>
    </tr>';
}
$html .= '<tr>
        <td colspan="3" align="right"><strong>Subtotal:</strong></td>
        <td>' . number_format($po['subtotal']) . ' RWF</td>
    </tr>
    <tr>
        <td colspan="3" align="right"><strong>Tax:</strong></td>
        <td>' . number_format($po['tax_amount']) . ' RWF</td>
    </tr>
    <tr>
        <td colspan="3" align="right"><strong>TOTAL:</strong></td>
        <td><strong>' . number_format($po['total_amount']) . ' RWF</strong></td>
    </tr>';
$html .= '</table>';
$pdf->writeHTML($html, true, false, true, false, '');

// Notes
if($po['notes']) {
    $pdf->Ln(10);
    $pdf->SetFont('helvetica', 'B', 10);
    $pdf->Cell(0, 5, 'Notes:', 0, 1, 'L');
    $pdf->SetFont('helvetica', '', 10);
    $pdf->MultiCell(0, 5, $po['notes'], 0, 'L');
}

// Terms
$pdf->Ln(10);
$pdf->SetFont('helvetica', 'I', 9);
$pdf->Cell(0, 5, 'Payment Terms: ' . $po['payment_terms'], 0, 1, 'L');
$pdf->Cell(0, 5, 'This is a computer generated document. No signature required.', 0, 1, 'L');

$pdf->Output('PO_' . $po['po_number'] . '.pdf', 'I');
?>