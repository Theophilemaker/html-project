<?php
// Quick file creator - Run this once to create all files

$files = [
    'branch_report_pdf.php',
    'supplier_report_pdf.php',
    'po_details.php',
    'po_pdf.php',
    'transfer_details.php',
    'transfer_pdf.php',
    'approve_transfer.php',
    'receive_transfer.php',
    'ship_transfer.php',
    'po_receive.php',
    'branch_selector.php',
    'transfer_history.php',
    'supplier_performance.php'
];

echo "<h1>Creating Files...</h1>";
echo "<ul>";

foreach($files as $file) {
    if(!file_exists($file)) {
        $fp = fopen($file, 'w');
        fwrite($fp, "<?php\n// " . $file . " - Created " . date('Y-m-d') . "\n// Add the code from the guide here\n?>");
        fclose($fp);
        echo "<li style='color:green;'>✅ Created: $file</li>";
    } else {
        echo "<li style='color:orange;'>⚠️ Already exists: $file</li>";
    }
}

echo "</ul>";
echo "<p>Now open each file and paste the code from the guide!</p>";
?>