<?php
// Create lock file to prevent reinstallation
file_put_contents(__DIR__ . '/config/installed.lock', date('Y-m-d H:i:s'));

// Redirect to login
header('Location: login.php');
exit();