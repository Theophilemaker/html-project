<?php
/**
 * THEOPHILE POS - ACCESS CONTROL AND HELPER FUNCTIONS
 * This file contains all role-based access control and utility functions
 */

// ============================================
// BASIC ACCESS CONTROL
// ============================================

/**
 * Check if user is logged in
 * Redirects to login page if not
 */
function checkLogin() {
    if(!isset($_SESSION['user_id'])) {
        header('Location: login.php');
        exit();
    }
}

/**
 * Check if user is admin
 * Redirects with error if not
 */
function checkAdmin() {
    if(!isset($_SESSION['user_id'])) {
        header('Location: login.php');
        exit();
    }
    
    if($_SESSION['role'] !== 'admin') {
        $_SESSION['error'] = "⛔ Access Denied! Admin privileges required.";
        header('Location: index.php');
        exit();
    }
}

/**
 * Check if user is cashier or admin
 */
function checkCashier() {
    if(!isset($_SESSION['user_id'])) {
        header('Location: login.php');
        exit();
    }
    
    if($_SESSION['role'] !== 'cashier' && $_SESSION['role'] !== 'admin') {
        $_SESSION['error'] = "⛔ Access Denied! Please login.";
        header('Location: login.php');
        exit();
    }
}

/**
 * Get role badge HTML
 * @param string $role User role (admin/cashier)
 * @return string HTML badge
 */
function getRoleBadge($role) {
    if($role === 'admin') {
        return '<span class="role-badge role-admin"><i class="fas fa-crown"></i> ADMIN</span>';
    } else {
        return '<span class="role-badge role-cashier"><i class="fas fa-user"></i> CASHIER</span>';
    }
}

// ============================================
// BRANCH MANAGEMENT FUNCTIONS
// ============================================

/**
 * Get user's branch ID
 * @return int Branch ID
 */
function getUserBranch() {
    return $_SESSION['branch_id'] ?? 1;
}

/**
 * Get branch filter for SQL queries
 * @return string SQL WHERE clause for branch filtering
 */
function getBranchFilter() {
    if($_SESSION['role'] === 'admin') {
        // Admin sees all branches
        return "";
    } else {
        // Cashier sees only their branch
        return " AND branch_id = " . ($_SESSION['branch_id'] ?? 1);
    }
}

/**
 * Check if user has access to specific branch
 * @param int $branch_id Branch ID to check
 * @return bool True if user has access
 */
function checkBranchAccess($branch_id) {
    if($_SESSION['role'] === 'admin') {
        return true;
    }
    return ($_SESSION['branch_id'] ?? 1) == $branch_id;
}

/**
 * Get branch name by ID
 * @param object $db Database connection
 * @param int $branch_id Branch ID
 * @return string Branch name or 'Unknown'
 */
function getBranchName($db, $branch_id) {
    try {
        $stmt = $db->prepare("SELECT branch_name FROM branches WHERE id = ?");
        $stmt->execute([$branch_id]);
        $name = $stmt->fetchColumn();
        return $name ?: 'Unknown Branch';
    } catch(Exception $e) {
        return 'Unknown Branch';
    }
}

/**
 * Get all active branches for dropdown
 * @param object $db Database connection
 * @return array List of branches
 */
function getActiveBranches($db) {
    try {
        $stmt = $db->query("SELECT id, branch_code, branch_name FROM branches WHERE is_active = 1 ORDER BY branch_name");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch(Exception $e) {
        return [];
    }
}

/**
 * Render branch selector dropdown
 * @param object $db Database connection
 * @param int $selected_id Selected branch ID
 * @param string $onchange JavaScript onchange event
 * @return string HTML dropdown
 */
function renderBranchSelector($db, $selected_id = null, $onchange = '') {
    $branches = getActiveBranches($db);
    
    $html = '<select class="form-control branch-selector" name="branch_id" onchange="' . $onchange . '">';
    $html .= '<option value="">All Branches</option>';
    
    foreach($branches as $branch) {
        $selected = ($selected_id == $branch['id']) ? 'selected' : '';
        $html .= '<option value="' . $branch['id'] . '" ' . $selected . '>';
        $html .= $branch['branch_code'] . ' - ' . $branch['branch_name'];
        $html .= '</option>';
    }
    
    $html .= '</select>';
    return $html;
}

// ============================================
// SUPPLIER MANAGEMENT FUNCTIONS
// ============================================

/**
 * Get supplier name by ID
 * @param object $db Database connection
 * @param int $supplier_id Supplier ID
 * @return string Supplier name
 */
function getSupplierName($db, $supplier_id) {
    try {
        $stmt = $db->prepare("SELECT company_name FROM suppliers WHERE id = ?");
        $stmt->execute([$supplier_id]);
        return $stmt->fetchColumn() ?: 'Unknown Supplier';
    } catch(Exception $e) {
        return 'Unknown Supplier';
    }
}

/**
 * Get supplier rating stars HTML
 * @param float $rating Rating (1-5)
 * @return string HTML stars
 */
function getSupplierStars($rating) {
    $html = '<div class="supplier-rating">';
    for($i = 1; $i <= 5; $i++) {
        if($i <= $rating) {
            $html .= '<i class="fas fa-star"></i>';
        } elseif($i - 0.5 <= $rating) {
            $html .= '<i class="fas fa-star-half-alt"></i>';
        } else {
            $html .= '<i class="far fa-star"></i>';
        }
    }
    $html .= '</div>';
    return $html;
}

/**
 * Get supplier performance badge
 * @param float $rating Supplier rating
 * @return string HTML badge
 */
function getSupplierBadge($rating) {
    if($rating >= 4.5) {
        return '<span class="supplier-badge badge-excellent">Excellent</span>';
    } elseif($rating >= 3.5) {
        return '<span class="supplier-badge badge-good">Good</span>';
    } elseif($rating >= 2.5) {
        return '<span class="supplier-badge badge-average">Average</span>';
    } else {
        return '<span class="supplier-badge badge-poor">Poor</span>';
    }
}

// ============================================
// PURCHASE ORDER FUNCTIONS
// ============================================

/**
 * Generate PO number
 * @return string Unique PO number
 */
function generatePONumber() {
    return 'PO' . date('Ymd') . str_pad(rand(1, 999), 3, '0', STR_PAD_LEFT);
}

/**
 * Get PO status badge
 * @param string $status PO status
 * @return string HTML badge
 */
function getPOStatusBadge($status) {
    $colors = [
        'draft' => '#6c757d',
        'sent' => '#007bff',
        'received' => '#28a745',
        'cancelled' => '#dc3545',
        'partial' => '#ffc107'
    ];
    
    $color = $colors[$status] ?? '#6c757d';
    return '<span style="background: ' . $color . '; color: white; padding: 3px 10px; border-radius: 15px; font-size: 0.8rem;">' . ucfirst($status) . '</span>';
}

// ============================================
// STOCK TRANSFER FUNCTIONS
// ============================================

/**
 * Generate transfer number
 * @return string Unique transfer number
 */
function generateTransferNumber() {
    return 'TR' . date('Ymd') . str_pad(rand(1, 999), 3, '0', STR_PAD_LEFT);
}

/**
 * Get transfer status badge
 * @param string $status Transfer status
 * @return string HTML badge
 */
function getTransferStatusBadge($status) {
    $colors = [
        'pending' => '#ffc107',
        'approved' => '#007bff',
        'shipped' => '#17a2b8',
        'received' => '#28a745',
        'cancelled' => '#dc3545'
    ];
    
    $color = $colors[$status] ?? '#6c757d';
    return '<span style="background: ' . $color . '; color: white; padding: 3px 10px; border-radius: 15px; font-size: 0.8rem;">' . ucfirst($status) . '</span>';
}

/**
 * Check if transfer can be approved
 * @param array $transfer Transfer data
 * @return bool True if approvable
 */
function canApproveTransfer($transfer) {
    return $transfer['status'] === 'pending';
}

/**
 * Check if transfer can be shipped
 * @param array $transfer Transfer data
 * @return bool True if shippable
 */
function canShipTransfer($transfer) {
    return $transfer['status'] === 'approved';
}

/**
 * Check if transfer can be received
 * @param array $transfer Transfer data
 * @return bool True if receivable
 */
function canReceiveTransfer($transfer) {
    return $transfer['status'] === 'shipped';
}

// ============================================
// CASHIER FILTER FUNCTIONS
// ============================================

/**
 * Get cashier filter for SQL queries
 * @return string SQL WHERE clause
 */
function getCashierFilter() {
    if($_SESSION['role'] === 'cashier') {
        return " AND cashier_id = " . $_SESSION['user_id'];
    }
    return "";
}

/**
 * Get date range filter
 * @param string $start Start date
 * @param string $end End date
 * @return string SQL WHERE clause
 */
function getDateFilter($start, $end) {
    return " AND date BETWEEN '$start' AND '$end'";
}

// ============================================
// PERMISSION CHECK FUNCTIONS
// ============================================

/**
 * Check if user can edit products
 * @return bool True if can edit
 */
function canEditProducts() {
    return $_SESSION['role'] === 'admin';
}

/**
 * Check if user can view reports
 * @return bool True if can view
 */
function canViewReports() {
    return $_SESSION['role'] === 'admin';
}

/**
 * Check if user can manage users
 * @return bool True if can manage
 */
function canManageUsers() {
    return $_SESSION['role'] === 'admin';
}

/**
 * Check if user can manage branches
 * @return bool True if can manage
 */
function canManageBranches() {
    return $_SESSION['role'] === 'admin';
}

/**
 * Check if user can manage suppliers
 * @return bool True if can manage
 */
function canManageSuppliers() {
    return $_SESSION['role'] === 'admin';
}

/**
 * Check if user can manage transfers
 * @return bool True if can manage
 */
function canManageTransfers() {
    return $_SESSION['role'] === 'admin';
}

// ============================================
// UTILITY FUNCTIONS
// ============================================

/**
 * Format currency
 * @param float $amount Amount to format
 * @return string Formatted amount
 */
function formatMoney($amount) {
    return number_format($amount, 0) . ' RWF';
}

/**
 * Format date
 * @param string $date Date string
 * @param string $format Format
 * @return string Formatted date
 */
function formatDate($date, $format = 'd/m/Y') {
    if(!$date) return '-';
    return date($format, strtotime($date));
}

/**
 * Get current page name
 * @return string Current page name
 */
function getCurrentPage() {
    return basename($_SERVER['PHP_SELF']);
}

/**
 * Check if current page matches
 * @param string $page Page name
 * @return string 'active' if matches
 */
function isActivePage($page) {
    return getCurrentPage() == $page ? 'active' : '';
}

/**
 * Show success message
 * @param string $message Message to show
 */
function setSuccess($message) {
    $_SESSION['success'] = $message;
}

/**
 * Show error message
 * @param string $message Message to show
 */
function setError($message) {
    $_SESSION['error'] = $message;
}

/**
 * Display notification if exists
 */
function displayNotifications() {
    if(isset($_SESSION['success'])) {
        echo '<div class="notification notification-success show">' . $_SESSION['success'] . '</div>';
        unset($_SESSION['success']);
    }
    if(isset($_SESSION['error'])) {
        echo '<div class="notification notification-error show">' . $_SESSION['error'] . '</div>';
        unset($_SESSION['error']);
    }
}

// ============================================
// AUDIT LOG FUNCTION
// ============================================

/**
 * Log user action
 * @param object $db Database connection
 * @param string $action Action performed
 * @param string $details Additional details
 */
function logAction($db, $action, $details = '') {
    if(!isset($_SESSION['user_id'])) return;
    
    try {
        $stmt = $db->prepare("INSERT INTO audit_logs (user_id, action, details, ip_address, user_agent) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([
            $_SESSION['user_id'],
            $action,
            $details,
            $_SERVER['REMOTE_ADDR'] ?? '',
            $_SERVER['HTTP_USER_AGENT'] ?? ''
        ]);
    } catch(Exception $e) {
        // Silently fail - don't break the application
    }
}

// ============================================
// INITIALIZATION FUNCTION
// ============================================

/**
 * Initialize user session with branch info
 * @param object $db Database connection
 * @param int $user_id User ID
 */
function initUserBranch($db, $user_id) {
    try {
        $stmt = $db->prepare("SELECT branch_id FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        $branch_id = $stmt->fetchColumn();
        if($branch_id) {
            $_SESSION['branch_id'] = $branch_id;
        }
    } catch(Exception $e) {
        $_SESSION['branch_id'] = 1; // Default to HQ
    }
}

// ============================================
// CSS STYLES FOR BADGES
// ============================================
// Add these to your style.css file:
/*
.supplier-badge {
    display: inline-block;
    padding: 3px 10px;
    border-radius: 15px;
    font-size: 0.8rem;
    font-weight: bold;
}
.badge-excellent { background: #d4edda; color: #155724; }
.badge-good { background: #cce5ff; color: #004085; }
.badge-average { background: #fff3cd; color: #856404; }
.badge-poor { background: #f8d7da; color: #721c24; }

.supplier-rating {
    color: #ffc107;
    font-size: 0.9rem;
}

.branch-selector {
    background: white;
    border: 2px solid var(--primary);
    border-radius: 8px;
    padding: 0.5rem 2rem 0.5rem 1rem;
    appearance: none;
    cursor: pointer;
}
*/
?>