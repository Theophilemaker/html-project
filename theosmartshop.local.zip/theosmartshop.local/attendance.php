<?php
session_start();
require_once 'config/database.php';
require_once 'check_access.php';

if(!isset($_SESSION['user_id'])) { 
    header('Location: login.php'); 
    exit(); 
}

// Only admin can access attendance
if($_SESSION['role'] !== 'admin') {
    $_SESSION['error'] = "⛔ Access Denied! Admin only.";
    header('Location: index.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();

// Get selected date or use today
$date = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');

// Handle clock in/out via AJAX
if(isset($_POST['action'])) {
    header('Content-Type: application/json');
    
    if($_POST['action'] == 'clock_in') {
        $emp_id = $_POST['employee_id'];
        
        // Check if already clocked in today
        $check = $db->prepare("SELECT id FROM attendance WHERE employee_id = ? AND DATE(clock_in) = CURDATE() AND clock_out IS NULL");
        $check->execute([$emp_id]);
        
        if($check->rowCount() == 0) {
            $stmt = $db->prepare("INSERT INTO attendance (employee_id, clock_in, status) VALUES (?, NOW(), 'present')");
            $stmt->execute([$emp_id]);
            echo json_encode(['success' => true, 'message' => 'Clocked in successfully']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Already clocked in today']);
        }
        exit();
    }
    
    if($_POST['action'] == 'clock_out') {
        $emp_id = $_POST['employee_id'];
        
        // Calculate hours worked
        $stmt = $db->prepare("UPDATE attendance SET 
            clock_out = NOW(), 
            hours_worked = TIMESTAMPDIFF(HOUR, clock_in, NOW()),
            overtime_hours = GREATEST(TIMESTAMPDIFF(HOUR, clock_in, NOW()) - 8, 0)
            WHERE employee_id = ? AND DATE(clock_in) = CURDATE() AND clock_out IS NULL");
        $stmt->execute([$emp_id]);
        
        if($stmt->rowCount() > 0) {
            echo json_encode(['success' => true, 'message' => 'Clocked out successfully']);
        } else {
            echo json_encode(['success' => false, 'message' => 'No active clock-in found']);
        }
        exit();
    }
}

// Get attendance for selected date
$stmt = $db->prepare("SELECT a.*, e.full_name, e.employee_id, e.position 
    FROM attendance a
    JOIN employees e ON a.employee_id = e.id
    WHERE DATE(a.clock_in) = ?
    ORDER BY a.clock_in DESC");
$stmt->execute([$date]);
$attendance = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get summary for selected date
$stmt = $db->prepare("SELECT 
    COUNT(*) as total,
    SUM(CASE WHEN status = 'present' THEN 1 ELSE 0 END) as present,
    SUM(CASE WHEN status = 'absent' THEN 1 ELSE 0 END) as absent,
    SUM(CASE WHEN status = 'late' THEN 1 ELSE 0 END) as late,
    COALESCE(SUM(hours_worked), 0) as total_hours,
    COALESCE(SUM(overtime_hours), 0) as total_overtime
    FROM attendance 
    WHERE DATE(clock_in) = ?");
$stmt->execute([$date]);
$stats = $stmt->fetch(PDO::FETCH_ASSOC);

// Get all active employees for quick clock
$employees = $db->query("SELECT id, full_name FROM employees WHERE status = 'active' ORDER BY full_name")->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Theophile POS - Attendance</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .clock-btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            color: white;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        .clock-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        .btn-clock-in { background: var(--success); }
        .btn-clock-out { background: var(--danger); }
        .status-badge {
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
        }
        .status-present { background: #d4edda; color: #155724; }
        .status-late { background: #fff3cd; color: #856404; }
        .status-absent { background: #f8d7da; color: #721c24; }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <!-- SIDEBAR - NEW VERSION WITH ALL MENU ITEMS -->
<div class="sidebar">
    <div class="logo">
        <h2><i class="fas fa-cash-register"></i> Theophile</h2>
    </div>
    
    <!-- User Info -->
    <div class="user-info">
        <?php 
        if($_SESSION['role'] === 'admin') {
            echo '<span class="role-badge role-admin"><i class="fas fa-crown"></i> ADMIN</span>';
        } else {
            echo '<span class="role-badge role-cashier"><i class="fas fa-user"></i> CASHIER</span>';
        }
        ?>
        <p><i class="fas fa-user"></i> <?php echo htmlspecialchars($_SESSION['full_name']); ?></p>
        <p><i class="fas fa-building"></i> Branch: 
            <?php
            // Get user's branch
            if(isset($db)) {
                $branch_stmt = $db->prepare("SELECT branch_name FROM branches WHERE id = ?");
                $branch_stmt->execute([$_SESSION['branch_id'] ?? 1]);
                $user_branch = $branch_stmt->fetchColumn();
                echo $user_branch ?: 'Headquarters';
            } else {
                echo 'All Branches';
            }
            ?>
        </p>
    </div>
    
    <!-- Navigation Links -->
    <ul class="nav-links">
        <!-- DASHBOARD -->
        <li>
            <a href="index.php" <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-home"></i> <span>Dashboard</span>
            </a>
        </li>
        
        <!-- PRODUCTS -->
        <li>
            <a href="products.php" <?php echo basename($_SERVER['PHP_SELF']) == 'products.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-box"></i> <span>Products</span>
            </a>
        </li>
        
        <!-- ADMIN ONLY SECTION -->
        <?php if($_SESSION['role'] === 'admin'): ?>
        
        <!-- ===== BRANCH MANAGEMENT ===== -->
        <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
            <span>🏢 BRANCH MANAGEMENT</span>
        </li>
        
        <li>
            <a href="branches.php" <?php echo basename($_SERVER['PHP_SELF']) == 'branches.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-building"></i> <span>Branches</span>
            </a>
        </li>
        
        <!-- ===== SUPPLIER MANAGEMENT ===== -->
        <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
            <span>🤝 SUPPLIER MANAGEMENT</span>
        </li>
        
        <li>
            <a href="suppliers.php" <?php echo basename($_SERVER['PHP_SELF']) == 'suppliers.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-truck"></i> <span>Suppliers</span>
            </a>
        </li>
        
        <li>
            <a href="purchase_orders.php" <?php echo basename($_SERVER['PHP_SELF']) == 'purchase_orders.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-file-invoice"></i> <span>Purchase Orders</span>
            </a>
        </li>
        
        <li>
            <a href="supplier_performance.php" <?php echo basename($_SERVER['PHP_SELF']) == 'supplier_performance.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-chart-line"></i> <span>Supplier Analytics</span>
            </a>
        </li>
        
        <!-- ===== STOCK TRANSFERS ===== -->
        <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
            <span>🔄 STOCK TRANSFERS</span>
        </li>
        
        <li>
            <a href="transfers.php" <?php echo basename($_SERVER['PHP_SELF']) == 'transfers.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-exchange-alt"></i> <span>All Transfers</span>
            </a>
        </li>
        
        <!-- ===== REPORTS ===== -->
        <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
            <span>📊 REPORTS</span>
        </li>
        
        <li>
            <a href="reports.php" <?php echo basename($_SERVER['PHP_SELF']) == 'reports.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-chart-bar"></i> <span>Sales Reports</span>
            </a>
        </li>
        
        <li>
            <a href="tax_reports.php" <?php echo basename($_SERVER['PHP_SELF']) == 'tax_reports.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-percent"></i> <span>Tax Reports</span>
            </a>
        </li>
        
        <li>
            <a href="business_intelligence.php" <?php echo basename($_SERVER['PHP_SELF']) == 'business_intelligence.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-chart-line"></i> <span>Business IQ</span>
            </a>
        </li>
        
        <!-- ===== HR MANAGEMENT ===== -->
        <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
            <span>👥 HR MANAGEMENT</span>
        </li>
        
        <li>
            <a href="employees.php" <?php echo basename($_SERVER['PHP_SELF']) == 'employees.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-users"></i> <span>Employees</span>
            </a>
        </li>
        
        <li>
            <a href="attendance.php" <?php echo basename($_SERVER['PHP_SELF']) == 'attendance.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-clock"></i> <span>Attendance</span>
            </a>
        </li>
        
        <li>
            <a href="payroll.php" <?php echo basename($_SERVER['PHP_SELF']) == 'payroll.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-wallet"></i> <span>Payroll</span>
            </a>
        </li>
        
        <!-- ===== SYSTEM ===== -->
        <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
            <span>⚙️ SYSTEM</span>
        </li>
        
        <li>
            <a href="users.php" <?php echo basename($_SERVER['PHP_SELF']) == 'users.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-users-cog"></i> <span>Users</span>
            </a>
        </li>
        
        <?php endif; ?> <!-- End Admin Only -->
        
        <!-- LOGOUT - Always visible -->
        <li style="margin-top: auto; border-top: 1px solid rgba(255,255,255,0.1); padding-top: 10px;">
            <a href="logout.php">
                <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
            </a>
        </li>
    </ul>
</div>
        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1><i class="fas fa-clock"></i> Attendance Management</h1>
                <form method="GET" style="display: flex; gap: 10px;">
                    <input type="date" name="date" class="form-control" value="<?php echo $date; ?>" style="width: 200px;">
                    <button type="submit" class="btn-small" style="background: var(--primary);">
                        <i class="fas fa-search"></i> View
                    </button>
                </form>
            </div>

            <?php if(isset($_SESSION['success'])): ?>
            <div class="notification notification-success show"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
            <?php endif; ?>

            <?php if(isset($_SESSION['error'])): ?>
            <div class="notification notification-error show"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
            <?php endif; ?>

            <!-- Statistics Cards -->
            <div class="stats-container">
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-users"></i></div>
                    <div class="stat-info">
                        <h3>Total Employees</h3>
                        <p><?php echo $stats['total']; ?></p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon" style="background: var(--success);"><i class="fas fa-check-circle"></i></div>
                    <div class="stat-info">
                        <h3>Present</h3>
                        <p style="color: var(--success);"><?php echo $stats['present']; ?></p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon" style="background: var(--warning);"><i class="fas fa-clock"></i></div>
                    <div class="stat-info">
                        <h3>Late</h3>
                        <p style="color: var(--warning);"><?php echo $stats['late']; ?></p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon" style="background: var(--danger);"><i class="fas fa-times-circle"></i></div>
                    <div class="stat-info">
                        <h3>Absent</h3>
                        <p style="color: var(--danger);"><?php echo $stats['absent']; ?></p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-hourglass-half"></i></div>
                    <div class="stat-info">
                        <h3>Total Hours</h3>
                        <p><?php echo round($stats['total_hours'], 1); ?> hrs</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon" style="background: var(--warning);"><i class="fas fa-clock"></i></div>
                    <div class="stat-info">
                        <h3>Overtime</h3>
                        <p><?php echo round($stats['total_overtime'], 1); ?> hrs</p>
                    </div>
                </div>
            </div>

            <!-- Quick Clock In/Out Section -->
            <div class="card" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white;">
                <div class="card-header">
                    <h3 style="color: white;"><i class="fas fa-fingerprint"></i> Quick Clock In/Out</h3>
                </div>
                <div style="display: flex; gap: 15px; align-items: center; flex-wrap: wrap;">
                    <select id="quickEmployee" class="form-control" style="flex: 2; min-width: 250px;">
                        <option value="">Select Employee</option>
                        <?php foreach($employees as $emp): ?>
                        <option value="<?php echo $emp['id']; ?>"><?php echo htmlspecialchars($emp['full_name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <button onclick="clockIn()" class="clock-btn btn-clock-in">
                        <i class="fas fa-sign-in-alt"></i> Clock In
                    </button>
                    <button onclick="clockOut()" class="clock-btn btn-clock-out">
                        <i class="fas fa-sign-out-alt"></i> Clock Out
                    </button>
                </div>
                <div id="clockMessage" style="margin-top: 10px; padding: 10px; border-radius: 5px; display: none;"></div>
            </div>

            <!-- Attendance Records -->
            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-list"></i> Attendance for <?php echo date('F j, Y', strtotime($date)); ?></h3>
                    <span class="role-badge role-admin">Total: <?php echo count($attendance); ?> records</span>
                </div>
                
                <?php if(empty($attendance)): ?>
                <div style="text-align: center; padding: 40px; color: #999;">
                    <i class="fas fa-clock" style="font-size: 48px; margin-bottom: 15px;"></i>
                    <p>No attendance records for this date.</p>
                </div>
                <?php else: ?>
                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Employee ID</th>
                                <th>Name</th>
                                <th>Position</th>
                                <th>Clock In</th>
                                <th>Clock Out</th>
                                <th>Hours</th>
                                <th>Overtime</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($attendance as $a): ?>
                            <tr>
                                <td><span class="role-badge" style="background: var(--primary);"><?php echo htmlspecialchars($a['employee_id']); ?></span></td>
                                <td><strong><?php echo htmlspecialchars($a['full_name']); ?></strong></td>
                                <td><?php echo htmlspecialchars($a['position']); ?></td>
                                <td><?php echo date('H:i:s', strtotime($a['clock_in'])); ?></td>
                                <td><?php echo $a['clock_out'] ? date('H:i:s', strtotime($a['clock_out'])) : '--'; ?></td>
                                <td><?php echo round($a['hours_worked'] ?? 0, 1); ?> hrs</td>
                                <td><?php echo round($a['overtime_hours'] ?? 0, 1); ?> hrs</td>
                                <td>
                                    <?php 
                                    $statusClass = '';
                                    $statusText = '';
                                    if($a['status'] == 'present') {
                                        $statusClass = 'status-present';
                                        $statusText = 'Present';
                                    } elseif($a['status'] == 'late') {
                                        $statusClass = 'status-late';
                                        $statusText = 'Late';
                                    } else {
                                        $statusClass = 'status-absent';
                                        $statusText = ucfirst($a['status']);
                                    }
                                    ?>
                                    <span class="status-badge <?php echo $statusClass; ?>"><?php echo $statusText; ?></span>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            </div>

            <!-- Summary Card -->
            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-chart-pie"></i> Daily Summary</h3>
                </div>
                <div style="display: flex; gap: 20px; flex-wrap: wrap; justify-content: space-around;">
                    <div style="text-align: center;">
                        <div style="font-size: 24px; font-weight: bold; color: var(--success);"><?php echo $stats['present']; ?></div>
                        <div>Present</div>
                    </div>
                    <div style="text-align: center;">
                        <div style="font-size: 24px; font-weight: bold; color: var(--warning);"><?php echo $stats['late']; ?></div>
                        <div>Late</div>
                    </div>
                    <div style="text-align: center;">
                        <div style="font-size: 24px; font-weight: bold; color: var(--danger);"><?php echo $stats['absent']; ?></div>
                        <div>Absent</div>
                    </div>
                    <div style="text-align: center;">
                        <div style="font-size: 24px; font-weight: bold;"><?php echo round($stats['total_hours'], 1); ?></div>
                        <div>Total Hours</div>
                    </div>
                    <div style="text-align: center;">
                        <div style="font-size: 24px; font-weight: bold; color: var(--warning);"><?php echo round($stats['total_overtime'], 1); ?></div>
                        <div>Overtime</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="assets/js/script.js"></script>
    <script>
    function showMessage(message, isSuccess) {
        const msgDiv = document.getElementById('clockMessage');
        msgDiv.style.display = 'block';
        msgDiv.style.background = isSuccess ? 'var(--success)' : 'var(--danger)';
        msgDiv.style.color = 'white';
        msgDiv.innerHTML = message;
        setTimeout(() => {
            msgDiv.style.display = 'none';
        }, 3000);
    }

    function clockIn() {
        const empId = document.getElementById('quickEmployee').value;
        if(!empId) {
            alert('Please select an employee!');
            return;
        }

        fetch('attendance.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'action=clock_in&employee_id=' + empId
        })
        .then(response => response.json())
        .then(data => {
            if(data.success) {
                showMessage('✅ ' + data.message, true);
                setTimeout(() => location.reload(), 1000);
            } else {
                showMessage('❌ ' + data.message, false);
            }
        })
        .catch(error => {
            showMessage('❌ Error: ' + error, false);
        });
    }

    function clockOut() {
        const empId = document.getElementById('quickEmployee').value;
        if(!empId) {
            alert('Please select an employee!');
            return;
        }

        fetch('attendance.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'action=clock_out&employee_id=' + empId
        })
        .then(response => response.json())
        .then(data => {
            if(data.success) {
                showMessage('✅ ' + data.message, true);
                setTimeout(() => location.reload(), 1000);
            } else {
                showMessage('❌ ' + data.message, false);
            }
        })
        .catch(error => {
            showMessage('❌ Error: ' + error, false);
        });
    }

    // Auto hide notifications
    setTimeout(() => {
        document.querySelectorAll('.notification').forEach(n => n.classList.remove('show'));
    }, 3000);
    </script>
</body>
</html>