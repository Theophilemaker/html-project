<?php
session_start();
require_once 'config/database.php';
require_once 'check_access.php';

if(!isset($_SESSION['user_id'])) { 
    header('Location: login.php'); 
    exit(); 
}

// Only admin can manage suppliers
if($_SESSION['role'] !== 'admin') {
    $_SESSION['error'] = "Access Denied!";
    header('Location: index.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();

// Handle Add Supplier
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_supplier'])) {
    $supplier_code = 'SUP' . str_pad(rand(1,9999), 4, '0', STR_PAD_LEFT);
    $company_name = trim($_POST['company_name']);
    $contact_person = trim($_POST['contact_person']);
    $phone = trim($_POST['phone']);
    $email = trim($_POST['email']);
    $address = trim($_POST['address']);
    $tax_id = trim($_POST['tax_id']);
    $payment_terms = $_POST['payment_terms'];
    $lead_time_days = (int)$_POST['lead_time_days'];
    
    $stmt = $db->prepare("INSERT INTO suppliers (supplier_code, company_name, contact_person, phone, email, address, tax_id, payment_terms, lead_time_days) VALUES (?,?,?,?,?,?,?,?,?)");
    if($stmt->execute([$supplier_code, $company_name, $contact_person, $phone, $email, $address, $tax_id, $payment_terms, $lead_time_days])) {
        $_SESSION['success'] = "Supplier added successfully!";
    } else {
        $_SESSION['error'] = "Error adding supplier!";
    }
    header('Location: suppliers.php');
    exit();
}

// Get all suppliers
$suppliers = $db->query("SELECT s.*, 
    (SELECT COUNT(*) FROM purchase_orders WHERE supplier_id = s.id) as order_count,
    (SELECT COALESCE(SUM(total_amount),0) FROM purchase_orders WHERE supplier_id = s.id) as total_spent,
    (SELECT MAX(order_date) FROM purchase_orders WHERE supplier_id = s.id) as last_order
    FROM suppliers s ORDER BY s.company_name")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Theophile POS - Suppliers</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .supplier-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        .supplier-card {
            background: white;
            border-radius: 15px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            border-left: 5px solid var(--success);
            position: relative;
        }
        .supplier-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
        }
        .supplier-code {
            background: linear-gradient(135deg, var(--success), var(--primary));
            color: white;
            padding: 3px 10px;
            border-radius: 15px;
            font-size: 0.8rem;
            display: inline-block;
        }
        .rating-stars {
            color: #ffc107;
        }
        .stat-box {
            display: flex;
            justify-content: space-around;
            margin: 15px 0;
            padding: 10px;
            background: #f8f9fa;
            border-radius: 10px;
        }
        .stat {
            text-align: center;
        }
        .stat-value {
            font-weight: bold;
            font-size: 1.2rem;
            color: var(--primary);
        }
        .stat-label {
            font-size: 0.7rem;
            color: #666;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="logo">
                <h2><i class="fas fa-cash-register"></i> Theophile</h2>
            </div>
            <div class="user-info">
                <span class="role-badge role-admin">ADMIN</span>
                <p><i class="fas fa-user"></i> <?php echo htmlspecialchars($_SESSION['full_name']); ?></p>
            </div>
            <ul class="nav-links">
                <li><a href="index.php"><i class="fas fa-home"></i> <span>Dashboard</span></a></li>
                <li><a href="products.php"><i class="fas fa-box"></i> <span>Products</span></a></li>
                <li><a href="branches.php"><i class="fas fa-building"></i> <span>Branches</span></a></li>
                <li><a href="suppliers.php" class="active"><i class="fas fa-truck"></i> <span>Suppliers</span></a></li>
                <li><a href="purchase_orders.php"><i class="fas fa-file-invoice"></i> <span>Purchase Orders</span></a></li>
                <li><a href="transfers.php"><i class="fas fa-exchange-alt"></i> <span>Transfers</span></a></li>
                <li><a href="reports.php"><i class="fas fa-chart-bar"></i> <span>Reports</span></a></li>
                <li><a href="users.php"><i class="fas fa-users-cog"></i> <span>Users</span></a></li>
                <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> <span>Logout</span></a></li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1><i class="fas fa-truck"></i> Supplier Management</h1>
                <div class="date">
                    <i class="fas fa-calendar-alt"></i> <?php echo date('l, F j, Y'); ?>
                </div>
            </div>

            <?php if(isset($_SESSION['success'])): ?>
            <div class="notification notification-success show"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
            <?php endif; ?>

            <?php if(isset($_SESSION['error'])): ?>
            <div class="notification notification-error show"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
            <?php endif; ?>

            <!-- Add Supplier Button -->
            <button onclick="showForm()" class="btn" style="margin-bottom: 20px;">
                <i class="fas fa-plus-circle"></i> Add New Supplier
            </button>

            <!-- Add Supplier Form -->
            <div id="supplierForm" class="card" style="display: none; margin-bottom: 20px;">
                <div class="card-header">
                    <h3>Add New Supplier</h3>
                    <button onclick="hideForm()" class="btn-small" style="background: #999;"><i class="fas fa-times"></i></button>
                </div>
                <form method="POST">
                    <div class="grid-3">
                        <div class="form-group">
                            <label>Company Name</label>
                            <input type="text" name="company_name" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label>Contact Person</label>
                            <input type="text" name="contact_person" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label>Phone</label>
                            <input type="text" name="phone" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label>Email</label>
                            <input type="email" name="email" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label>Tax ID</label>
                            <input type="text" name="tax_id" class="form-control">
                        </div>
                        <div class="form-group">
                            <label>Payment Terms</label>
                            <select name="payment_terms" class="form-control">
                                <option>Cash on Delivery</option>
                                <option>Net 15</option>
                                <option>Net 30</option>
                                <option>Net 45</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Lead Time (Days)</label>
                            <input type="number" name="lead_time_days" class="form-control" value="7">
                        </div>
                        <div class="form-group">
                            <label>Address</label>
                            <textarea name="address" class="form-control" rows="2"></textarea>
                        </div>
                    </div>
                    <button type="submit" name="add_supplier" class="btn">
                        <i class="fas fa-save"></i> Save Supplier
                    </button>
                </form>
            </div>

            <!-- Suppliers Grid -->
            <?php if(empty($suppliers)): ?>
            <div class="card" style="text-align: center; padding: 40px;">
                <i class="fas fa-truck" style="font-size: 48px; color: #ccc; margin-bottom: 15px;"></i>
                <h3>No Suppliers Found</h3>
                <p>Click "Add New Supplier" to create your first supplier.</p>
            </div>
            <?php else: ?>
            <div class="supplier-grid">
                <?php foreach($suppliers as $supplier): ?>
                <div class="supplier-card">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                        <span class="supplier-code"><?php echo $supplier['supplier_code']; ?></span>
                        <span class="rating-stars">
                            <?php for($i=1; $i<=5; $i++): ?>
                                <i class="fas fa-star<?php echo $i <= $supplier['rating'] ? '' : '-o'; ?>"></i>
                            <?php endfor; ?>
                        </span>
                    </div>
                    
                    <h3 style="margin: 0 0 5px 0;"><?php echo htmlspecialchars($supplier['company_name']); ?></h3>
                    <p style="color: #666;">
                        <i class="fas fa-user"></i> <?php echo htmlspecialchars($supplier['contact_person']); ?><br>
                        <i class="fas fa-phone"></i> <?php echo $supplier['phone']; ?><br>
                        <i class="fas fa-envelope"></i> <?php echo $supplier['email']; ?>
                    </p>

                    <div class="stat-box">
                        <div class="stat">
                            <div class="stat-value"><?php echo $supplier['order_count']; ?></div>
                            <div class="stat-label">Orders</div>
                        </div>
                        <div class="stat">
                            <div class="stat-value"><?php echo number_format($supplier['total_spent'], 0); ?></div>
                            <div class="stat-label">Spent</div>
                        </div>
                        <div class="stat">
                            <div class="stat-value"><?php echo $supplier['lead_time_days']; ?></div>
                            <div class="stat-label">Lead Time</div>
                        </div>
                    </div>

                    <div style="display: flex; gap: 10px;">
                        <a href="purchase_orders.php?supplier=<?php echo $supplier['id']; ?>" class="btn-small" style="background: var(--primary); flex: 1;">
                            <i class="fas fa-file-invoice"></i> New Order
                        </a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <script>
        function showForm() {
            document.getElementById('supplierForm').style.display = 'block';
            document.getElementById('supplierForm').scrollIntoView({ behavior: 'smooth' });
        }
        
        function hideForm() {
            document.getElementById('supplierForm').style.display = 'none';
        }
        
        setTimeout(() => {
            document.querySelectorAll('.notification').forEach(n => n.classList.remove('show'));
        }, 3000);
    </script>
    <script src="assets/js/script.js"></script>
</body>
</html>