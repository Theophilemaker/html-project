<?php
session_start();
require_once 'config/database.php';
require_once 'check_access.php';
require_once 'tcpdf/tcpdf.php';

if(!isset($_SESSION['user_id'])) { header('Location: login.php'); exit(); }

$database = new Database();
$db = $database->getConnection();

$transfer_id = $_GET['id'] ?? 0;

// Get transfer details
$stmt = $db->prepare("SELECT t.*, 
    from_b.branch_name as from_branch, from_b.location as from_location,
    to_b.branch_name as to_branch, to_b.location as to_location,
    req.full_name as requested_by_name
    FROM stock_transfers t
    JOIN branches from_b ON t.from_branch_id = from_b.id
    JOIN branches to_b ON t.to_branch_id = to_b.id
    LEFT JOIN users req ON t.requested_by = req.id
    WHERE t.id = ?");
$stmt->execute([$transfer_id]);
$transfer = $stmt->fetch(PDO::FETCH_ASSOC);

if(!$transfer) {
    die("Transfer not found!");
}

// Get transfer items
$items = $db->prepare("SELECT ti.*, p.name as product_name 
    FROM transfer_items ti
    JOIN products p ON ti.product_id = p.id
    WHERE ti.transfer_id = ?");
$items->execute([$transfer_id]);
$transfer_items = $items->fetchAll(PDO::FETCH_ASSOC);

// Create PDF
class TransferPDF extends TCPDF {
    public function Header() {
        $this->SetFont('helvetica', 'B', 16);
        $this->Cell(0, 15, 'STOCK TRANSFER NOTE', 0, false, 'C', 0, '', 0, false, 'M', 'M');
        $this->Ln(10);
    }
    
    public function Footer() {
        $this->SetY(-15);
        $this->SetFont('helvetica', 'I', 8);
        $this->Cell(0, 10, 'Page '.$this->getAliasNumPage().'/'.$this->getAliasNbPages(), 0, false, 'C', 0, '', 0, false, 'T', 'M');
    }
}

$pdf = new TransferPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
$pdf->SetCreator('Theophile POS');
$pdf->SetTitle('Stock Transfer #' . $transfer['transfer_number']);
$pdf->SetMargins(15, 30, 15);
$pdf->AddPage();

// Transfer Info
$pdf->SetFont('helvetica', 'B', 14);
$pdf->Cell(0, 10, 'TRANSFER #' . $transfer['transfer_number'], 0, 1, 'C');
$pdf->Ln(5);

$html = '
<table border="1" cellpadding="5">
    <tr>
        <td width="50%"><strong>FROM BRANCH:</strong><br>
            ' . $transfer['from_branch'] . '<br>
            ' . $transfer['from_location'] . '
        </td>
        <td width="50%"><strong>TO BRANCH:</strong><br>
            ' . $transfer['to_branch'] . '<br>
            ' . $transfer['to_location'] . '
        </td>
    </tr>
    <tr>
        <td><strong>Transfer Date:</strong> ' . date('F j, Y', strtotime($transfer['transfer_date'])) . '</td>
        <td><strong>Status:</strong> ' . ucfirst($transfer['status']) . '</td>
    </tr>
    <tr>
        <td colspan="2"><strong>Requested By:</strong> ' . ($transfer['requested_by_name'] ?? 'System') . '</td>
    </tr>
</table>';
$pdf->writeHTML($html, true, false, true, false, '');
$pdf->Ln(10);

// Items Table
$html = '<table border="1" cellpadding="5">
    <tr style="background-color: #f0f0f0; font-weight: bold;">
        <th>Product</th>
        <th>Quantity</th>
        <th>Unit Price</th>
        <th>Total Value</th>
    </tr>';
$total_value = 0;
foreach($transfer_items as $item) {
    $total_value += $item['total_value'];
    $html .= '<tr>
        <td>' . $item['product_name'] . '</td>
        <td>' . $item['quantity'] . '</td>
        <td>' . number_format($item['unit_price']) . ' RWF</td>
        <td>' . number_format($item['total_value']) . ' RWF</td>
    </tr>';
}
$html .= '<tr>
        <td colspan="3" align="right"><strong>TOTAL VALUE:</strong></td>
        <td><strong>' . number_format($total_value) . ' RWF</strong></td>
    </tr>';
$html .= '</table>';
$pdf->writeHTML($html, true, false, true, false, '');

// Notes
if($transfer['notes']) {
    $pdf->Ln(10);
    $pdf->SetFont('helvetica', 'B', 10);
    $pdf->Cell(0, 5, 'Notes:', 0, 1, 'L');
    $pdf->SetFont('helvetica', '', 10);
    $pdf->MultiCell(0, 5, $transfer['notes'], 0, 'L');
}

// Signatures
$pdf->Ln(15);
$html = '<table border="0" cellpadding="10">
    <tr>
        <td width="33%">_________________________<br>Requested By</td>
        <td width="33%">_________________________<br>Approved By</td>
        <td width="33%">_________________________<br>Received By</td>
    </tr>
</table>';
$pdf->writeHTML($html, true, false, true, false, '');

$pdf->Output('Transfer_' . $transfer['transfer_number'] . '.pdf', 'I');
?>