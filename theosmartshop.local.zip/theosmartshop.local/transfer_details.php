<?php
session_start();
require_once 'config/database.php';
require_once 'check_access.php';

if(!isset($_SESSION['user_id'])) { header('Location: login.php'); exit(); }
checkAdmin();

$database = new Database();
$db = $database->getConnection();

$transfer_id = $_GET['id'] ?? 0;

// Get transfer details
$stmt = $db->prepare("SELECT t.*, 
    from_b.branch_name as from_branch, from_b.location as from_location,
    to_b.branch_name as to_branch, to_b.location as to_location,
    req.full_name as requested_by_name,
    app.full_name as approved_by_name,
    rec.full_name as received_by_name
    FROM stock_transfers t
    JOIN branches from_b ON t.from_branch_id = from_b.id
    JOIN branches to_b ON t.to_branch_id = to_b.id
    LEFT JOIN users req ON t.requested_by = req.id
    LEFT JOIN users app ON t.approved_by = app.id
    LEFT JOIN users rec ON t.received_by = rec.id
    WHERE t.id = ?");
$stmt->execute([$transfer_id]);
$transfer = $stmt->fetch(PDO::FETCH_ASSOC);

if(!$transfer) {
    $_SESSION['error'] = "Transfer not found!";
    header('Location: transfers.php');
    exit();
}

// Get transfer items
$items = $db->prepare("SELECT ti.*, p.name as product_name 
    FROM transfer_items ti
    JOIN products p ON ti.product_id = p.id
    WHERE ti.transfer_id = ?");
$items->execute([$transfer_id]);
$transfer_items = $items->fetchAll(PDO::FETCH_ASSOC);

// Get transfer history
$history = $db->prepare("SELECT th.*, u.full_name as user_name 
    FROM transfer_history th
    LEFT JOIN users u ON th.user_id = u.id
    WHERE th.transfer_id = ?
    ORDER BY th.created_at ASC");
$history->execute([$transfer_id]);
$transfer_history = $history->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Transfer Details - Theophile POS</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .timeline {
            position: relative;
            padding: 20px 0;
        }
        .timeline-item {
            padding: 10px 0 10px 30px;
            border-left: 2px solid var(--primary);
            position: relative;
            margin-left: 20px;
        }
        .timeline-item::before {
            content: '';
            position: absolute;
            left: -8px;
            top: 15px;
            width: 14px;
            height: 14px;
            border-radius: 50%;
            background: var(--primary);
        }
        .timeline-item.completed::before {
            background: var(--success);
        }
        .timeline-date {
            font-size: 0.8rem;
            color: #666;
        }
        .timeline-action {
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <!-- SIDEBAR - NEW VERSION WITH ALL MENU ITEMS -->
<div class="sidebar">
    <div class="logo">
        <h2><i class="fas fa-cash-register"></i> Theophile</h2>
    </div>
    
    <!-- User Info -->
    <div class="user-info">
        <?php 
        if($_SESSION['role'] === 'admin') {
            echo '<span class="role-badge role-admin"><i class="fas fa-crown"></i> ADMIN</span>';
        } else {
            echo '<span class="role-badge role-cashier"><i class="fas fa-user"></i> CASHIER</span>';
        }
        ?>
        <p><i class="fas fa-user"></i> <?php echo htmlspecialchars($_SESSION['full_name']); ?></p>
        <p><i class="fas fa-building"></i> Branch: 
            <?php
            // Get user's branch
            if(isset($db)) {
                $branch_stmt = $db->prepare("SELECT branch_name FROM branches WHERE id = ?");
                $branch_stmt->execute([$_SESSION['branch_id'] ?? 1]);
                $user_branch = $branch_stmt->fetchColumn();
                echo $user_branch ?: 'Headquarters';
            } else {
                echo 'All Branches';
            }
            ?>
        </p>
    </div>
    
    <!-- Navigation Links -->
    <ul class="nav-links">
        <!-- DASHBOARD -->
        <li>
            <a href="index.php" <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-home"></i> <span>Dashboard</span>
            </a>
        </li>
        
        <!-- PRODUCTS -->
        <li>
            <a href="products.php" <?php echo basename($_SERVER['PHP_SELF']) == 'products.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-box"></i> <span>Products</span>
            </a>
        </li>
        
        <!-- ADMIN ONLY SECTION -->
        <?php if($_SESSION['role'] === 'admin'): ?>
        
        <!-- ===== BRANCH MANAGEMENT ===== -->
        <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
            <span>🏢 BRANCH MANAGEMENT</span>
        </li>
        
        <li>
            <a href="branches.php" <?php echo basename($_SERVER['PHP_SELF']) == 'branches.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-building"></i> <span>Branches</span>
            </a>
        </li>
        
        <!-- ===== SUPPLIER MANAGEMENT ===== -->
        <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
            <span>🤝 SUPPLIER MANAGEMENT</span>
        </li>
        
        <li>
            <a href="suppliers.php" <?php echo basename($_SERVER['PHP_SELF']) == 'suppliers.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-truck"></i> <span>Suppliers</span>
            </a>
        </li>
        
        <li>
            <a href="purchase_orders.php" <?php echo basename($_SERVER['PHP_SELF']) == 'purchase_orders.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-file-invoice"></i> <span>Purchase Orders</span>
            </a>
        </li>
        
        <li>
            <a href="supplier_performance.php" <?php echo basename($_SERVER['PHP_SELF']) == 'supplier_performance.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-chart-line"></i> <span>Supplier Analytics</span>
            </a>
        </li>
        
        <!-- ===== STOCK TRANSFERS ===== -->
        <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
            <span>🔄 STOCK TRANSFERS</span>
        </li>
        
        <li>
            <a href="transfers.php" <?php echo basename($_SERVER['PHP_SELF']) == 'transfers.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-exchange-alt"></i> <span>All Transfers</span>
            </a>
        </li>
        
        <!-- ===== REPORTS ===== -->
        <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
            <span>📊 REPORTS</span>
        </li>
        
        <li>
            <a href="reports.php" <?php echo basename($_SERVER['PHP_SELF']) == 'reports.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-chart-bar"></i> <span>Sales Reports</span>
            </a>
        </li>
        
        <li>
            <a href="tax_reports.php" <?php echo basename($_SERVER['PHP_SELF']) == 'tax_reports.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-percent"></i> <span>Tax Reports</span>
            </a>
        </li>
        
        <li>
            <a href="business_intelligence.php" <?php echo basename($_SERVER['PHP_SELF']) == 'business_intelligence.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-chart-line"></i> <span>Business IQ</span>
            </a>
        </li>
        
        <!-- ===== HR MANAGEMENT ===== -->
        <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
            <span>👥 HR MANAGEMENT</span>
        </li>
        
        <li>
            <a href="employees.php" <?php echo basename($_SERVER['PHP_SELF']) == 'employees.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-users"></i> <span>Employees</span>
            </a>
        </li>
        
        <li>
            <a href="attendance.php" <?php echo basename($_SERVER['PHP_SELF']) == 'attendance.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-clock"></i> <span>Attendance</span>
            </a>
        </li>
        
        <li>
            <a href="payroll.php" <?php echo basename($_SERVER['PHP_SELF']) == 'payroll.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-wallet"></i> <span>Payroll</span>
            </a>
        </li>
        
        <!-- ===== SYSTEM ===== -->
        <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
            <span>⚙️ SYSTEM</span>
        </li>
        
        <li>
            <a href="users.php" <?php echo basename($_SERVER['PHP_SELF']) == 'users.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-users-cog"></i> <span>Users</span>
            </a>
        </li>
        
        <?php endif; ?> <!-- End Admin Only -->
        
        <!-- LOGOUT - Always visible -->
        <li style="margin-top: auto; border-top: 1px solid rgba(255,255,255,0.1); padding-top: 10px;">
            <a href="logout.php">
                <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
            </a>
        </li>
    </ul>
</div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1><i class="fas fa-exchange-alt"></i> Stock Transfer Details</h1>
                <div class="date"><?php echo date('l, F j, Y'); ?></div>
            </div>

            <!-- Action Buttons -->
            <div style="display: flex; gap: 10px; margin-bottom: 20px;">
                <a href="transfers.php" class="btn-small" style="background: var(--primary);">
                    <i class="fas fa-arrow-left"></i> Back
                </a>
                <a href="transfer_pdf.php?id=<?php echo $transfer_id; ?>" class="btn-small" style="background: var(--success);">
                    <i class="fas fa-file-pdf"></i> Download PDF
                </a>
                <?php if($transfer['status'] == 'pending'): ?>
                <a href="approve_transfer.php?id=<?php echo $transfer_id; ?>" class="btn-small" style="background: var(--success);">
                    <i class="fas fa-check"></i> Approve
                </a>
                <a href="cancel_transfer.php?id=<?php echo $transfer_id; ?>" class="btn-small" style="background: var(--danger);">
                    <i class="fas fa-times"></i> Cancel
                </a>
                <?php endif; ?>
                <?php if($transfer['status'] == 'approved'): ?>
                <a href="ship_transfer.php?id=<?php echo $transfer_id; ?>" class="btn-small" style="background: var(--info);">
                    <i class="fas fa-truck"></i> Mark as Shipped
                </a>
                <?php endif; ?>
                <?php if($transfer['status'] == 'shipped'): ?>
                <a href="receive_transfer.php?id=<?php echo $transfer_id; ?>" class="btn-small" style="background: var(--warning);">
                    <i class="fas fa-check-circle"></i> Receive Stock
                </a>
                <?php endif; ?>
            </div>

            <!-- Transfer Info Card -->
            <div class="card">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                    <h2>Transfer #<?php echo $transfer['transfer_number']; ?></h2>
                    <span class="status-badge status-<?php echo $transfer['status']; ?>">
                        <?php echo ucfirst($transfer['status']); ?>
                    </span>
                </div>

                <div class="grid-2">
                    <div>
                        <h4><i class="fas fa-store"></i> From Branch</h4>
                        <p><strong><?php echo htmlspecialchars($transfer['from_branch']); ?></strong><br>
                        <?php echo htmlspecialchars($transfer['from_location']); ?></p>
                    </div>
                    <div>
                        <h4><i class="fas fa-arrow-right"></i> To Branch</h4>
                        <p><strong><?php echo htmlspecialchars($transfer['to_branch']); ?></strong><br>
                        <?php echo htmlspecialchars($transfer['to_location']); ?></p>
                    </div>
                    <div>
                        <h4>Transfer Date</h4>
                        <p><?php echo date('F j, Y', strtotime($transfer['transfer_date'])); ?></p>
                    </div>
                    <div>
                        <h4>Total Value</h4>
                        <p style="font-size: 1.5rem; color: var(--primary);">
                            <?php echo number_format(array_sum(array_column($transfer_items, 'total_value'))); ?> RWF
                        </p>
                    </div>
                </div>

                <?php if($transfer['notes']): ?>
                <div style="margin-top: 20px; padding: 15px; background: #f8f9fa; border-radius: 8px;">
                    <strong>Notes:</strong>
                    <p><?php echo nl2br(htmlspecialchars($transfer['notes'])); ?></p>
                </div>
                <?php endif; ?>
            </div>

            <!-- Transfer Items -->
            <div class="card">
                <h3>Transfer Items</h3>
                <table>
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>Quantity</th>
                            <th>Unit Price</th>
                            <th>Total Value</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($transfer_items as $item): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                            <td><?php echo $item['quantity']; ?></td>
                            <td><?php echo number_format($item['unit_price']); ?> RWF</td>
                            <td><?php echo number_format($item['total_value']); ?> RWF</td>
                            <td>
                                <?php if($item['status'] == 'complete'): ?>
                                <span class="status-normal">Complete</span>
                                <?php elseif($item['received_quantity'] > 0): ?>
                                <span class="status-expiring">Partial (<?php echo $item['received_quantity']; ?>)</span>
                                <?php else: ?>
                                <span class="status-low">Pending</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <!-- Transfer Timeline -->
            <div class="card">
                <h3>Transfer Timeline</h3>
                <div class="timeline">
                    <?php foreach($transfer_history as $event): ?>
                    <div class="timeline-item <?php echo $event['action'] == 'received' ? 'completed' : ''; ?>">
                        <div class="timeline-date"><?php echo date('M j, Y H:i', strtotime($event['created_at'])); ?></div>
                        <div class="timeline-action">
                            <?php 
                            $action = ucfirst($event['action']);
                            if($event['user_name']) {
                                $action .= " by " . $event['user_name'];
                            }
                            echo $action;
                            ?>
                        </div>
                        <?php if($event['notes']): ?>
                        <div style="font-size: 0.9rem; color: #666;"><?php echo $event['notes']; ?></div>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
    <?php if($transfer['shipping_tracking']): ?>
<div class="card">
    <h3><i class="fas fa-truck"></i> Shipping Information</h3>
    <div class="info-row">
        <span class="info-label">Tracking #:</span>
        <span class="info-value"><?php echo $transfer['shipping_tracking']; ?></span>
    </div>
    <div class="info-row">
        <span class="info-label">Carrier:</span>
        <span class="info-value"><?php echo $transfer['shipping_carrier']; ?></span>
    </div>
    <div class="info-row">
        <span class="info-label">Shipped Date:</span>
        <span class="info-value"><?php echo date('d/m/Y', strtotime($transfer['shipping_date'])); ?></span>
    </div>
    <?php if($transfer['estimated_arrival']): ?>
    <div class="info-row">
        <span class="info-label">Est. Arrival:</span>
        <span class="info-value"><?php echo date('d/m/Y', strtotime($transfer['estimated_arrival'])); ?></span>
    </div>
    <?php endif; ?>
</div>
<?php endif; ?>
    <script src="assets/js/script.js"></script>
</body>
</html>