<?php
session_start();
require_once 'config/database.php';
require_once 'check_access.php';
checkAdmin();

$database = new Database();
$db = $database->getConnection();

$month = $_GET['month'] ?? date('Y-m');
$year = date('Y', strtotime($month));
$month_num = date('m', strtotime($month));

// Calculate payroll for the month
if(isset($_POST['calculate_payroll'])) {
    // Get all active employees
    $employees = $db->query("SELECT * FROM employees WHERE status = 'active'")->fetchAll();
    
    foreach($employees as $emp) {
        // Get attendance for the month
        $stmt = $db->prepare("SELECT 
            COALESCE(SUM(hours_worked), 0) as total_hours,
            COALESCE(SUM(overtime_hours), 0) as total_overtime
            FROM attendance 
            WHERE employee_id = ? 
            AND MONTH(clock_in) = ? 
            AND YEAR(clock_in) = ?");
        $stmt->execute([$emp['id'], $month_num, $year]);
        $attendance = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Calculate pay
        $hourly_rate = $emp['hourly_rate'] ?: ($emp['base_salary'] / 160); // Assuming 160 hours/month
        $regular_pay = $attendance['total_hours'] * $hourly_rate;
        $overtime_pay = $attendance['total_overtime'] * ($hourly_rate * 1.5);
        
        // Get deductions
        $deductions_total = 0;
        $deductions = $db->prepare("SELECT d.*, ed.amount as custom_amount 
            FROM employee_deductions ed
            JOIN deductions d ON ed.deduction_id = d.id
            WHERE ed.employee_id = ? AND ed.status = 'active'");
        $deductions->execute([$emp['id']]);
        foreach($deductions as $ded) {
            if($ded['type'] == 'percentage') {
                $amount = ($regular_pay + $overtime_pay) * ($ded['amount'] / 100);
            } else {
                $amount = $ded['custom_amount'] ?: $ded['amount'];
            }
            $deductions_total += $amount;
        }
        
        // Tax (PAYE - 15% of gross)
        $gross = $regular_pay + $overtime_pay;
        $tax = $gross * 0.15;
        $net_pay = $gross - $tax - $deductions_total;
        
        // Insert payroll record
        $stmt = $db->prepare("INSERT INTO payroll 
            (employee_id, pay_period_start, pay_period_end, regular_hours, overtime_hours, 
             regular_pay, overtime_pay, deductions, tax_amount, net_pay, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')");
        $stmt->execute([
            $emp['id'],
            $year . '-' . $month_num . '-01',
            date('Y-m-t', strtotime($year . '-' . $month_num . '-01')),
            $attendance['total_hours'],
            $attendance['total_overtime'],
            $regular_pay,
            $overtime_pay,
            $deductions_total,
            $tax,
            $net_pay
        ]);
    }
    $_SESSION['success'] = "Payroll calculated successfully!";
    header('Location: payroll.php?month=' . $month);
    exit();
}

// Get payroll for selected month
$stmt = $db->prepare("SELECT p.*, e.full_name, e.employee_id, e.position 
    FROM payroll p
    JOIN employees e ON p.employee_id = e.id
    WHERE DATE_FORMAT(p.pay_period_start, '%Y-%m') = ?
    ORDER BY p.created_at DESC");
$stmt->execute([$month]);
$payroll = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Calculate totals
$total_gross = array_sum(array_column($payroll, 'regular_pay')) + array_sum(array_column($payroll, 'overtime_pay'));
$total_deductions = array_sum(array_column($payroll, 'deductions'));
$total_tax = array_sum(array_column($payroll, 'tax_amount'));
$total_net = array_sum(array_column($payroll, 'net_pay'));
?>

<!DOCTYPE html>
<html>
<head>
    <title>Payroll - Theophile POS</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        
<!-- SIDEBAR - NEW VERSION WITH ALL MENU ITEMS -->
<div class="sidebar">
    <div class="logo">
        <h2><i class="fas fa-cash-register"></i> Theophile</h2>
    </div>
    
    <!-- User Info -->
    <div class="user-info">
        <?php 
        if($_SESSION['role'] === 'admin') {
            echo '<span class="role-badge role-admin"><i class="fas fa-crown"></i> ADMIN</span>';
        } else {
            echo '<span class="role-badge role-cashier"><i class="fas fa-user"></i> CASHIER</span>';
        }
        ?>
        <p><i class="fas fa-user"></i> <?php echo htmlspecialchars($_SESSION['full_name']); ?></p>
        <p><i class="fas fa-building"></i> Branch: 
            <?php
            // Get user's branch
            if(isset($db)) {
                $branch_stmt = $db->prepare("SELECT branch_name FROM branches WHERE id = ?");
                $branch_stmt->execute([$_SESSION['branch_id'] ?? 1]);
                $user_branch = $branch_stmt->fetchColumn();
                echo $user_branch ?: 'Headquarters';
            } else {
                echo 'All Branches';
            }
            ?>
        </p>
    </div>
    
    <!-- Navigation Links -->
    <ul class="nav-links">
        <!-- DASHBOARD -->
        <li>
            <a href="index.php" <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-home"></i> <span>Dashboard</span>
            </a>
        </li>
        
        <!-- PRODUCTS -->
        <li>
            <a href="products.php" <?php echo basename($_SERVER['PHP_SELF']) == 'products.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-box"></i> <span>Products</span>
            </a>
        </li>
        
        <!-- ADMIN ONLY SECTION -->
        <?php if($_SESSION['role'] === 'admin'): ?>
        
        <!-- ===== BRANCH MANAGEMENT ===== -->
        <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
            <span>🏢 BRANCH MANAGEMENT</span>
        </li>
        
        <li>
            <a href="branches.php" <?php echo basename($_SERVER['PHP_SELF']) == 'branches.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-building"></i> <span>Branches</span>
            </a>
        </li>
        
        <!-- ===== SUPPLIER MANAGEMENT ===== -->
        <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
            <span>🤝 SUPPLIER MANAGEMENT</span>
        </li>
        
        <li>
            <a href="suppliers.php" <?php echo basename($_SERVER['PHP_SELF']) == 'suppliers.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-truck"></i> <span>Suppliers</span>
            </a>
        </li>
        
        <li>
            <a href="purchase_orders.php" <?php echo basename($_SERVER['PHP_SELF']) == 'purchase_orders.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-file-invoice"></i> <span>Purchase Orders</span>
            </a>
        </li>
        
        <li>
            <a href="supplier_performance.php" <?php echo basename($_SERVER['PHP_SELF']) == 'supplier_performance.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-chart-line"></i> <span>Supplier Analytics</span>
            </a>
        </li>
        
        <!-- ===== STOCK TRANSFERS ===== -->
        <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
            <span>🔄 STOCK TRANSFERS</span>
        </li>
        
        <li>
            <a href="transfers.php" <?php echo basename($_SERVER['PHP_SELF']) == 'transfers.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-exchange-alt"></i> <span>All Transfers</span>
            </a>
        </li>
        
        <!-- ===== REPORTS ===== -->
        <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
            <span>📊 REPORTS</span>
        </li>
        
        <li>
            <a href="reports.php" <?php echo basename($_SERVER['PHP_SELF']) == 'reports.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-chart-bar"></i> <span>Sales Reports</span>
            </a>
        </li>
        
        <li>
            <a href="tax_reports.php" <?php echo basename($_SERVER['PHP_SELF']) == 'tax_reports.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-percent"></i> <span>Tax Reports</span>
            </a>
        </li>
        
        <li>
            <a href="business_intelligence.php" <?php echo basename($_SERVER['PHP_SELF']) == 'business_intelligence.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-chart-line"></i> <span>Business IQ</span>
            </a>
        </li>
        
        <!-- ===== HR MANAGEMENT ===== -->
        <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
            <span>👥 HR MANAGEMENT</span>
        </li>
        
        <li>
            <a href="employees.php" <?php echo basename($_SERVER['PHP_SELF']) == 'employees.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-users"></i> <span>Employees</span>
            </a>
        </li>
        
        <li>
            <a href="attendance.php" <?php echo basename($_SERVER['PHP_SELF']) == 'attendance.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-clock"></i> <span>Attendance</span>
            </a>
        </li>
        
        <li>
            <a href="payroll.php" <?php echo basename($_SERVER['PHP_SELF']) == 'payroll.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-wallet"></i> <span>Payroll</span>
            </a>
        </li>
        
        <!-- ===== SYSTEM ===== -->
        <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
            <span>⚙️ SYSTEM</span>
        </li>
        
        <li>
            <a href="users.php" <?php echo basename($_SERVER['PHP_SELF']) == 'users.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-users-cog"></i> <span>Users</span>
            </a>
        </li>
        
        <?php endif; ?> <!-- End Admin Only -->
        
        <!-- LOGOUT - Always visible -->
        <li style="margin-top: auto; border-top: 1px solid rgba(255,255,255,0.1); padding-top: 10px;">
            <a href="logout.php">
                <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
            </a>
        </li>
    </ul>
</div>
        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1><i class="fas fa-wallet"></i> Payroll Management</h1>
                <div class="date"><?php echo date('F Y', strtotime($month)); ?></div>
            </div>

            <!-- Month Selector -->
            <div class="card">
                <form method="GET" class="grid-3">
                    <div class="form-group">
                        <label>Pay Period</label>
                        <input type="month" name="month" class="form-control" value="<?php echo $month; ?>">
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn" style="margin-top: 24px;">
                            <i class="fas fa-filter"></i> Load Payroll
                        </button>
                    </div>
                    <div class="form-group">
                        <form method="POST">
                            <button type="submit" name="calculate_payroll" class="btn" style="margin-top: 24px; background: var(--success);">
                                <i class="fas fa-calculator"></i> Calculate Payroll
                            </button>
                        </form>
                    </div>
                </form>
            </div>

            <!-- Payroll Summary Cards -->
            <div class="stats-container">
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-users"></i></div>
                    <div><h3>Employees</h3><p><?php echo count($payroll); ?></p></div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-money-bill-wave"></i></div>
                    <div><h3>Gross Pay</h3><p><?php echo number_format($total_gross); ?> RWF</p></div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon" style="background: var(--warning);"><i class="fas fa-percent"></i></div>
                    <div><h3>Deductions</h3><p style="color: var(--warning);"><?php echo number_format($total_deductions); ?> RWF</p></div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon" style="background: var(--danger);"><i class="fas fa-calculator"></i></div>
                    <div><h3>Tax</h3><p style="color: var(--danger);"><?php echo number_format($total_tax); ?> RWF</p></div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon" style="background: var(--success);"><i class="fas fa-hand-holding-usd"></i></div>
                    <div><h3>Net Pay</h3><p style="color: var(--success);"><?php echo number_format($total_net); ?> RWF</p></div>
                </div>
            </div>

            <!-- Payroll Table -->
            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-list"></i> Payroll Details</h3>
                    <div>
                        <button onclick="exportPayroll()" class="btn-small" style="background: var(--success);">
                            <i class="fas fa-file-excel"></i> Export
                        </button>
                        <button onclick="processPayments()" class="btn-small" style="background: var(--primary);">
                            <i class="fas fa-check-circle"></i> Process Payments
                        </button>
                    </div>
                </div>
                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Employee</th>
                                <th>Position</th>
                                <th>Regular Hours</th>
                                <th>Overtime</th>
                                <th>Regular Pay</th>
                                <th>Overtime Pay</th>
                                <th>Gross</th>
                                <th>Deductions</th>
                                <th>Tax</th>
                                <th>Net Pay</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($payroll as $p): 
                                $gross = $p['regular_pay'] + $p['overtime_pay'];
                            ?>
                            <tr>
                                <td>
                                    <strong><?php echo $p['full_name']; ?></strong><br>
                                    <small><?php echo $p['employee_id']; ?></small>
                                </td>
                                <td><?php echo $p['position']; ?></td>
                                <td><?php echo $p['regular_hours']; ?> hrs</td>
                                <td><?php echo $p['overtime_hours']; ?> hrs</td>
                                <td><?php echo number_format($p['regular_pay']); ?> RWF</td>
                                <td><?php echo number_format($p['overtime_pay']); ?> RWF</td>
                                <td><strong><?php echo number_format($gross); ?> RWF</strong></td>
                                <td style="color: var(--warning);"><?php echo number_format($p['deductions']); ?> RWF</td>
                                <td style="color: var(--danger);"><?php echo number_format($p['tax_amount']); ?> RWF</td>
                                <td style="color: var(--success); font-weight: bold;"><?php echo number_format($p['net_pay']); ?> RWF</td>
                                <td>
                                    <?php if($p['status'] == 'pending'): ?>
                                    <span class="status-expiring">Pending</span>
                                    <?php elseif($p['status'] == 'paid'): ?>
                                    <span class="status-normal">Paid</span>
                                    <?php else: ?>
                                    <span class="status-low">Cancelled</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Payroll Chart -->
            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-chart-pie"></i> Payroll Breakdown</h3>
                </div>
                <div class="grid-2">
                    <div class="chart-container" style="height: 300px;">
                        <canvas id="payrollPieChart"></canvas>
                    </div>
                    <div class="chart-container" style="height: 300px;">
                        <canvas id="payrollBarChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
    // Payroll Pie Chart
    new Chart(document.getElementById('payrollPieChart'), {
        type: 'doughnut',
        data: {
            labels: ['Regular Pay', 'Overtime', 'Deductions', 'Tax'],
            datasets: [{
                data: [
                    <?php echo array_sum(array_column($payroll, 'regular_pay')); ?>,
                    <?php echo array_sum(array_column($payroll, 'overtime_pay')); ?>,
                    <?php echo $total_deductions; ?>,
                    <?php echo $total_tax; ?>
                ],
                backgroundColor: ['#4361ee', '#4cc9f0', '#f8961e', '#f72585']
            }]
        }
    });

    // Payroll Bar Chart (Top 5 employees)
    new Chart(document.getElementById('payrollBarChart'), {
        type: 'bar',
        data: {
            labels: [<?php foreach(array_slice($payroll, 0, 5) as $p) echo "'" . $p['full_name'] . "',"; ?>],
            datasets: [{
                label: 'Net Pay',
                data: [<?php foreach(array_slice($payroll, 0, 5) as $p) echo $p['net_pay'] . ","; ?>],
                backgroundColor: '#4361ee'
            }]
        }
    });

    function exportPayroll() {
        window.location.href = 'export_payroll.php?month=<?php echo $month; ?>';
    }

    function processPayments() {
        if(confirm('Mark all pending payroll as paid?')) {
            fetch('process_payroll_payments.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({month: '<?php echo $month; ?>'})
            })
            .then(response => response.json())
            .then(data => {
                if(data.success) location.reload();
            });
        }
    }
    </script>
</body>
</html>