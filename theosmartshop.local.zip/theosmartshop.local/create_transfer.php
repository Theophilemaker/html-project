<?php
session_start();
require_once 'config/database.php';
require_once 'check_access.php';

// Check login and admin status
if(!isset($_SESSION['user_id'])) { 
    header('Location: login.php'); 
    exit(); 
}

if($_SESSION['role'] !== 'admin') {
    $_SESSION['error'] = "Access Denied! Only admin can create transfers.";
    header('Location: transfers.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();

// Get active branches for dropdown
$branches = $db->query("SELECT id, branch_code, branch_name FROM branches WHERE is_active = 1 ORDER BY branch_name")->fetchAll(PDO::FETCH_ASSOC);

// Get products for transfer
$products = $db->query("SELECT id, name, selling_price, quantity FROM products ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);

// Handle form submission
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_transfer'])) {
    
    $transfer_number = 'TR' . date('Ymd') . str_pad(rand(1, 999), 3, '0', STR_PAD_LEFT);
    $from_branch = $_POST['from_branch'];
    $to_branch = $_POST['to_branch'];
    $transfer_date = $_POST['transfer_date'];
    $notes = $_POST['notes'] ?? '';
    
    // Validate branches are different
    if($from_branch == $to_branch) {
        $_SESSION['error'] = "Source and destination branches must be different!";
        header('Location: create_transfer.php');
        exit();
    }
    
    // Get items from JSON
    $items = json_decode($_POST['items_json'], true);
    
    if(empty($items)) {
        $_SESSION['error'] = "Please add at least one product to transfer!";
        header('Location: create_transfer.php');
        exit();
    }
    
    $db->beginTransaction();
    try {
        // Calculate total value
        $total_value = 0;
        foreach($items as $item) {
            $total_value += $item['quantity'] * $item['price'];
        }
        
        // Insert transfer header
        $stmt = $db->prepare("INSERT INTO stock_transfers 
            (transfer_number, from_branch_id, to_branch_id, transfer_date, status, requested_by, notes, total_value) 
            VALUES (?, ?, ?, ?, 'pending', ?, ?, ?)");
        
        $stmt->execute([
            $transfer_number,
            $from_branch,
            $to_branch,
            $transfer_date,
            $_SESSION['user_id'],
            $notes,
            $total_value
        ]);
        
        $transfer_id = $db->lastInsertId();
        
        // Insert transfer items
        $item_stmt = $db->prepare("INSERT INTO transfer_items 
            (transfer_id, product_id, quantity, unit_price, total_value) 
            VALUES (?, ?, ?, ?, ?)");
        
        foreach($items as $item) {
            // Check if enough stock in source branch
            $stock_check = $db->prepare("SELECT quantity FROM products WHERE id = ? AND branch_id = ?");
            $stock_check->execute([$item['id'], $from_branch]);
            $available = $stock_check->fetchColumn();
            
            if($available < $item['quantity']) {
                throw new Exception("Insufficient stock for product ID " . $item['id']);
            }
            
            $item_total = $item['quantity'] * $item['price'];
            $item_stmt->execute([
                $transfer_id,
                $item['id'],
                $item['quantity'],
                $item['price'],
                $item_total
            ]);
        }
        
        // Log the action
        $log_stmt = $db->prepare("INSERT INTO transfer_history (transfer_id, action, user_id, notes) VALUES (?, 'created', ?, ?)");
        $log_stmt->execute([$transfer_id, $_SESSION['user_id'], "Transfer created"]);
        
        $db->commit();
        $_SESSION['success'] = "Transfer #$transfer_number created successfully!";
        header('Location: transfers.php');
        exit();
        
    } catch(Exception $e) {
        $db->rollBack();
        $_SESSION['error'] = "Error creating transfer: " . $e->getMessage();
        header('Location: create_transfer.php');
        exit();
    }
}

// Get available stock for a product in a branch (for AJAX)
if(isset($_GET['ajax']) && isset($_GET['product_id']) && isset($_GET['branch_id'])) {
    header('Content-Type: application/json');
    try {
        $stmt = $db->prepare("SELECT quantity FROM products WHERE id = ? AND branch_id = ?");
        $stmt->execute([$_GET['product_id'], $_GET['branch_id']]);
        $quantity = $stmt->fetchColumn();
        echo json_encode(['success' => true, 'quantity' => $quantity ?: 0]);
    } catch(Exception $e) {
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Theophile POS - Create Stock Transfer</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .transfer-container {
            max-width: 1200px;
            margin: 0 auto;
        }
        .product-row {
            display: grid;
            grid-template-columns: 3fr 1fr 1fr 1fr 0.5fr;
            gap: 10px;
            margin-bottom: 10px;
            align-items: center;
            background: #f8f9fa;
            padding: 10px;
            border-radius: 8px;
            transition: all 0.3s ease;
        }
        .product-row:hover {
            background: #e9ecef;
            transform: translateX(5px);
        }
        .stock-warning {
            color: #dc3545;
            font-size: 0.85rem;
            margin-top: 5px;
        }
        .stock-ok {
            color: #28a745;
            font-size: 0.85rem;
        }
        .summary-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 15px;
            margin-bottom: 20px;
        }
        .remove-btn {
            background: #dc3545;
            color: white;
            border: none;
            border-radius: 5px;
            width: 35px;
            height: 35px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        .remove-btn:hover {
            background: #c82333;
            transform: scale(1.1);
        }
        .add-btn {
            background: var(--primary);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            cursor: pointer;
            margin: 10px 0;
            transition: all 0.3s ease;
        }
        .add-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(67,97,238,0.3);
        }
        .total-display {
            font-size: 1.5rem;
            font-weight: bold;
            color: var(--primary);
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="logo">
                <h2><i class="fas fa-cash-register"></i> Theophile</h2>
            </div>
            <div class="user-info">
                <span class="role-badge role-admin">ADMIN</span>
                <p><i class="fas fa-user"></i> <?php echo htmlspecialchars($_SESSION['full_name']); ?></p>
            </div>
            <ul class="nav-links">
                <li><a href="index.php"><i class="fas fa-home"></i> <span>Dashboard</span></a></li>
                <li><a href="products.php"><i class="fas fa-box"></i> <span>Products</span></a></li>
                <li><a href="branches.php"><i class="fas fa-building"></i> <span>Branches</span></a></li>
                <li><a href="suppliers.php"><i class="fas fa-truck"></i> <span>Suppliers</span></a></li>
                <li><a href="purchase_orders.php"><i class="fas fa-file-invoice"></i> <span>Purchase Orders</span></a></li>
                <li><a href="transfers.php"><i class="fas fa-exchange-alt"></i> <span>Transfers</span></a></li>
                <li><a href="reports.php"><i class="fas fa-chart-bar"></i> <span>Reports</span></a></li>
                <li><a href="users.php"><i class="fas fa-users-cog"></i> <span>Users</span></a></li>
                <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> <span>Logout</span></a></li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1><i class="fas fa-exchange-alt"></i> Create Stock Transfer</h1>
                <div class="date">
                    <i class="fas fa-calendar-alt"></i> <?php echo date('l, F j, Y'); ?>
                </div>
            </div>

            <?php if(isset($_SESSION['success'])): ?>
            <div class="notification notification-success show"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
            <?php endif; ?>

            <?php if(isset($_SESSION['error'])): ?>
            <div class="notification notification-error show"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
            <?php endif; ?>

            <div class="transfer-container">
                <form method="POST" id="transferForm" onsubmit="return validateForm()">
                    <!-- Branch Selection -->
                    <div class="card">
                        <div class="card-header">
                            <h3><i class="fas fa-store"></i> Select Branches</h3>
                        </div>
                        <div class="grid-2">
                            <div class="form-group">
                                <label>From Branch (Source)</label>
                                <select name="from_branch" id="fromBranch" class="form-control" required onchange="updateStockInfo()">
                                    <option value="">Select Source Branch</option>
                                    <?php foreach($branches as $b): ?>
                                    <option value="<?php echo $b['id']; ?>"><?php echo $b['branch_code'] . ' - ' . $b['branch_name']; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>To Branch (Destination)</label>
                                <select name="to_branch" id="toBranch" class="form-control" required>
                                    <option value="">Select Destination Branch</option>
                                    <?php foreach($branches as $b): ?>
                                    <option value="<?php echo $b['id']; ?>"><?php echo $b['branch_code'] . ' - ' . $b['branch_name']; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Transfer Date</label>
                                <input type="date" name="transfer_date" class="form-control" value="<?php echo date('Y-m-d'); ?>" required>
                            </div>
                        </div>
                    </div>

                    <!-- Products Section -->
                    <div class="card">
                        <div class="card-header">
                            <h3><i class="fas fa-boxes"></i> Products to Transfer</h3>
                            <button type="button" onclick="addProductRow()" class="btn-small" style="background: var(--primary);">
                                <i class="fas fa-plus"></i> Add Product
                            </button>
                        </div>

                        <div id="products-container">
                            <!-- Product rows will be added here -->
                        </div>

                        <!-- Summary -->
                        <div class="summary-card">
                            <div style="display: flex; justify-content: space-between; align-items: center;">
                                <div>
                                    <h4 style="color: white; margin: 0;">Total Transfer Value</h4>
                                    <p style="margin: 5px 0 0 0;">Number of items: <span id="itemCount">0</span></p>
                                </div>
                                <div class="total-display" style="color: white;">
                                    <span id="totalValue">0</span> RWF
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label>Notes (Optional)</label>
                            <textarea name="notes" class="form-control" rows="3" placeholder="Add any notes about this transfer..."></textarea>
                        </div>

                        <input type="hidden" name="items_json" id="items_json">
                        <input type="hidden" name="total_value" id="total_value">

                        <div style="display: flex; gap: 10px; margin-top: 20px;">
                            <button type="submit" name="create_transfer" class="btn" style="flex: 1;">
                                <i class="fas fa-paper-plane"></i> Create Transfer Request
                            </button>
                            <a href="transfers.php" class="btn" style="background: #6c757d; flex: 0.3;">
                                <i class="fas fa-times"></i> Cancel
                            </a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        let products = <?php echo json_encode($products); ?>;
        let rowCount = 0;
        let productRows = [];

        function addProductRow() {
            let container = document.getElementById('products-container');
            let rowId = rowCount;
            
            let row = document.createElement('div');
            row.className = 'product-row';
            row.id = 'row_' + rowId;
            
            // Product select
            let select = document.createElement('select');
            select.className = 'form-control';
            select.id = 'product_' + rowId;
            select.onchange = function() { updateProductInfo(rowId); };
            select.innerHTML = '<option value="">Select Product</option>' + 
                products.map(p => `<option value="${p.id}" data-price="${p.selling_price}" data-name="${p.name}">${p.name} (Stock: ${p.quantity})</option>`).join('');
            
            // Quantity input
            let qtyInput = document.createElement('input');
            qtyInput.type = 'number';
            qtyInput.className = 'form-control';
            qtyInput.id = 'qty_' + rowId;
            qtyInput.placeholder = 'Quantity';
            qtyInput.min = '1';
            qtyInput.value = '1';
            qtyInput.oninput = function() { calculateRowTotal(rowId); checkStock(rowId); };
            
            // Price display
            let priceSpan = document.createElement('span');
            priceSpan.className = 'form-control';
            priceSpan.id = 'price_' + rowId;
            priceSpan.style.background = '#e9ecef';
            priceSpan.innerHTML = '0';
            
            // Total display
            let totalSpan = document.createElement('span');
            totalSpan.className = 'form-control';
            totalSpan.id = 'total_' + rowId;
            totalSpan.style.background = '#e9ecef';
            totalSpan.style.fontWeight = 'bold';
            totalSpan.innerHTML = '0';
            
            // Remove button
            let removeBtn = document.createElement('button');
            removeBtn.type = 'button';
            removeBtn.className = 'remove-btn';
            removeBtn.innerHTML = '<i class="fas fa-trash"></i>';
            removeBtn.onclick = function() { removeRow(rowId); };
            
            row.appendChild(select);
            row.appendChild(qtyInput);
            row.appendChild(priceSpan);
            row.appendChild(totalSpan);
            row.appendChild(removeBtn);
            
            container.appendChild(row);
            
            productRows.push({
                id: rowId,
                element: row
            });
            
            rowCount++;
            updateItemCount();
        }

        function updateProductInfo(rowId) {
            let select = document.getElementById('product_' + rowId);
            let priceSpan = document.getElementById('price_' + rowId);
            let selected = select.options[select.selectedIndex];
            
            if(selected.value) {
                priceSpan.innerHTML = selected.dataset.price;
                calculateRowTotal(rowId);
                checkStock(rowId);
            } else {
                priceSpan.innerHTML = '0';
            }
        }

        function calculateRowTotal(rowId) {
            let priceSpan = document.getElementById('price_' + rowId);
            let qtyInput = document.getElementById('qty_' + rowId);
            let totalSpan = document.getElementById('total_' + rowId);
            
            let price = parseFloat(priceSpan.innerHTML) || 0;
            let qty = parseInt(qtyInput.value) || 0;
            let total = price * qty;
            
            totalSpan.innerHTML = total.toFixed(0);
            
            calculateGrandTotal();
        }

        function checkStock(rowId) {
            let select = document.getElementById('product_' + rowId);
            let qtyInput = document.getElementById('qty_' + rowId);
            let fromBranch = document.getElementById('fromBranch').value;
            
            if(!fromBranch) {
                alert('Please select source branch first!');
                qtyInput.value = '';
                return;
            }
            
            let selected = select.options[select.selectedIndex];
            if(selected.value && fromBranch) {
                // You could add AJAX call here to check actual stock
                let availableStock = selected.text.match(/Stock: (\d+)/);
                if(availableStock) {
                    let stock = parseInt(availableStock[1]);
                    let requested = parseInt(qtyInput.value) || 0;
                    
                    if(requested > stock) {
                        qtyInput.style.borderColor = '#dc3545';
                        alert('Warning: Requested quantity exceeds available stock!');
                    } else {
                        qtyInput.style.borderColor = '#28a745';
                    }
                }
            }
        }

        function calculateGrandTotal() {
            let total = 0;
            let itemCount = 0;
            
            for(let i = 0; i < rowCount; i++) {
                let totalSpan = document.getElementById('total_' + i);
                if(totalSpan && totalSpan.innerHTML != '0') {
                    total += parseFloat(totalSpan.innerHTML) || 0;
                    itemCount++;
                }
            }
            
            document.getElementById('totalValue').innerHTML = total.toFixed(0);
            document.getElementById('total_value').value = total;
            document.getElementById('itemCount').innerHTML = itemCount;
        }

        function removeRow(rowId) {
            let row = document.getElementById('row_' + rowId);
            if(row) {
                row.remove();
                productRows = productRows.filter(r => r.id != rowId);
                calculateGrandTotal();
                updateItemCount();
            }
        }

        function updateItemCount() {
            let count = 0;
            for(let i = 0; i < rowCount; i++) {
                let select = document.getElementById('product_' + i);
                if(select && select.value) {
                    count++;
                }
            }
            document.getElementById('itemCount').innerHTML = count;
        }

        function updateStockInfo() {
            // This would ideally make an AJAX call to get current stock
            console.log('Branch changed, updating stock info...');
        }

        function validateForm() {
            let fromBranch = document.getElementById('fromBranch').value;
            let toBranch = document.getElementById('toBranch').value;
            
            if(fromBranch == toBranch) {
                alert('Source and destination branches must be different!');
                return false;
            }
            
            let hasProducts = false;
            let items = [];
            
            for(let i = 0; i < rowCount; i++) {
                let select = document.getElementById('product_' + i);
                let qty = document.getElementById('qty_' + i);
                
                if(select && select.value && qty && qty.value) {
                    hasProducts = true;
                    items.push({
                        id: select.value,
                        name: select.options[select.selectedIndex].dataset.name,
                        quantity: qty.value,
                        price: document.getElementById('price_' + i).innerHTML,
                        total: document.getElementById('total_' + i).innerHTML
                    });
                }
            }
            
            if(!hasProducts) {
                alert('Please add at least one product to transfer!');
                return false;
            }
            
            document.getElementById('items_json').value = JSON.stringify(items);
            return true;
        }

        // Add first product row automatically
        window.onload = function() {
            addProductRow();
        };

        // Auto-hide notifications
        setTimeout(() => {
            document.querySelectorAll('.notification').forEach(n => n.classList.remove('show'));
        }, 3000);
    </script>
    <script src="assets/js/script.js"></script>
</body>
</html>