<?php
session_start();
require_once 'config/database.php';
require_once 'check_access.php';
require_once 'tcpdf/tcpdf.php';

if(!isset($_SESSION['user_id'])) { header('Location: login.php'); exit(); }
checkAdmin();

$database = new Database();
$db = $database->getConnection();

$supplier_id = $_GET['id'] ?? 1;

// Get supplier details
$stmt = $db->prepare("SELECT * FROM suppliers WHERE id = ?");
$stmt->execute([$supplier_id]);
$supplier = $stmt->fetch(PDO::FETCH_ASSOC);

// Get purchase orders history
$pos = $db->prepare("SELECT 
    po.*,
    b.branch_name,
    COUNT(poi.id) as items_count
    FROM purchase_orders po
    JOIN branches b ON po.branch_id = b.id
    LEFT JOIN po_items poi ON po.id = poi.po_id
    WHERE po.supplier_id = ?
    GROUP BY po.id
    ORDER BY po.order_date DESC");
$pos->execute([$supplier_id]);
$orders = $pos->fetchAll(PDO::FETCH_ASSOC);

// Calculate totals
$total_orders = count($orders);
$total_spent = array_sum(array_column($orders, 'total_amount'));
$avg_order = $total_orders > 0 ? $total_spent / $total_orders : 0;

// Create PDF
class SupplierPDF extends TCPDF {
    public function Header() {
        $this->SetFont('helvetica', 'B', 16);
        $this->Cell(0, 15, 'Supplier Performance Report', 0, false, 'C', 0, '', 0, false, 'M', 'M');
        $this->Ln(10);
    }
    
    public function Footer() {
        $this->SetY(-15);
        $this->SetFont('helvetica', 'I', 8);
        $this->Cell(0, 10, 'Page '.$this->getAliasNumPage().'/'.$this->getAliasNbPages(), 0, false, 'C', 0, '', 0, false, 'T', 'M');
    }
}

$pdf = new SupplierPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
$pdf->SetCreator('Theophile POS');
$pdf->SetTitle('Supplier Report - ' . $supplier['company_name']);
$pdf->SetMargins(15, 30, 15);
$pdf->AddPage();

// Supplier Info
$pdf->SetFont('helvetica', 'B', 14);
$pdf->Cell(0, 10, $supplier['company_name'], 0, 1, 'L');
$pdf->SetFont('helvetica', '', 10);
$pdf->Cell(0, 5, 'Code: ' . $supplier['supplier_code'], 0, 1, 'L');
$pdf->Cell(0, 5, 'Contact: ' . $supplier['contact_person'], 0, 1, 'L');
$pdf->Cell(0, 5, 'Phone: ' . $supplier['phone'], 0, 1, 'L');
$pdf->Cell(0, 5, 'Email: ' . $supplier['email'], 0, 1, 'L');
$pdf->Cell(0, 5, 'Payment Terms: ' . $supplier['payment_terms'], 0, 1, 'L');
$pdf->Cell(0, 5, 'Lead Time: ' . $supplier['lead_time_days'] . ' days', 0, 1, 'L');
$pdf->Cell(0, 5, 'Rating: ' . $supplier['rating'] . ' / 5', 0, 1, 'L');
$pdf->Ln(10);

// Summary Statistics
$pdf->SetFillColor(67, 97, 238);
$pdf->SetTextColor(255, 255, 255);
$pdf->SetFont('helvetica', 'B', 12);
$pdf->Cell(0, 10, 'Summary Statistics', 0, 1, 'L', true);
$pdf->SetTextColor(0, 0, 0);

$html = '
<table border="1" cellpadding="5">
    <tr>
        <td><strong>Total Orders:</strong> ' . $total_orders . '</td>
        <td><strong>Total Spent:</strong> ' . number_format($total_spent) . ' RWF</td>
    </tr>
    <tr>
        <td><strong>Average Order Value:</strong> ' . number_format($avg_order) . ' RWF</td>
        <td><strong>Last Order:</strong> ' . ($orders[0]['order_date'] ?? 'N/A') . '</td>
    </tr>
</table>';
$pdf->writeHTML($html, true, false, true, false, '');
$pdf->Ln(10);

// Purchase Order History
$pdf->SetFillColor(67, 97, 238);
$pdf->SetTextColor(255, 255, 255);
$pdf->SetFont('helvetica', 'B', 12);
$pdf->Cell(0, 10, 'Purchase Order History', 0, 1, 'L', true);
$pdf->SetTextColor(0, 0, 0);

$html = '<table border="1" cellpadding="5">
    <tr style="background-color: #f0f0f0;">
        <th>PO Number</th>
        <th>Date</th>
        <th>Branch</th>
        <th>Items</th>
        <th>Status</th>
        <th>Amount</th>
    </tr>';
foreach($orders as $po) {
    $html .= '<tr>
        <td>' . $po['po_number'] . '</td>
        <td>' . $po['order_date'] . '</td>
        <td>' . $po['branch_name'] . '</td>
        <td>' . $po['items_count'] . '</td>
        <td>' . ucfirst($po['status']) . '</td>
        <td>' . number_format($po['total_amount']) . ' RWF</td>
    </tr>';
}
$html .= '</table>';
$pdf->writeHTML($html, true, false, true, false, '');

$pdf->Output('Supplier_Report_' . $supplier['supplier_code'] . '.pdf', 'I');
?>