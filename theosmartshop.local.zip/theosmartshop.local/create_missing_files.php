<?php
session_start();
require_once 'config/database.php';

if(!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    die("Access denied!");
}

// Function to create file with content
function createFile($filename, $content) {
    $filepath = __DIR__ . '/' . $filename;
    if(file_exists($filepath)) {
        return "<span style='color:orange;'>⚠️ $filename already exists</span>";
    }
    
    $result = file_put_contents($filepath, $content);
    if($result !== false) {
        return "<span style='color:green;'>✅ Created: $filename</span>";
    } else {
        return "<span style='color:red;'>❌ Failed to create: $filename</span>";
    }
}

echo "<!DOCTYPE html>
<html>
<head>
    <title>Creating Missing Files</title>
    <style>
        body { font-family: Arial; margin: 20px; background: #f5f5f5; }
        .container { max-width: 800px; margin: 0 auto; background: white; padding: 20px; border-radius: 10px; }
        h1 { color: #4361ee; }
        .success { color: green; }
        .error { color: red; }
        .warning { color: orange; }
    </style>
</head>
<body>
    <div class='container'>
        <h1>📦 Creating Missing Theophile POS Files</h1>";

// Branch Management Files
echo "<h2>🏢 Branch Management Files</h2>";
echo "<p>" . createFile('branches.php', '<?php
// Branch Management Page
// Copy the full branches.php code from previous messages
?>') . "</p>";

echo "<p>" . createFile('branch_report_pdf.php', '<?php
// Branch Report PDF
// Copy the full branch_report_pdf.php code from previous messages
?>') . "</p>";

echo "<p>" . createFile('branch_selector.php', '<?php
// Branch Selector Component
// Copy the full branch_selector.php code from previous messages
?>') . "</p>";

// Supplier Management Files
echo "<h2>🤝 Supplier Management Files</h2>";
echo "<p>" . createFile('suppliers.php', '<?php
// Suppliers Management Page
// Copy the full suppliers.php code from previous messages
?>') . "</p>";

echo "<p>" . createFile('supplier_report_pdf.php', '<?php
// Supplier Report PDF
// Copy the full supplier_report_pdf.php code from previous messages
?>') . "</p>";

echo "<p>" . createFile('supplier_performance.php', '<?php
// Supplier Performance Page
// Copy the full supplier_performance.php code from previous messages
?>') . "</p>";

// Purchase Order Files
echo "<h2>📦 Purchase Order Files</h2>";
echo "<p>" . createFile('purchase_orders.php', '<?php
// Purchase Orders Management
// Copy the full purchase_orders.php code from previous messages
?>') . "</p>";

echo "<p>" . createFile('po_details.php', '<?php
// Purchase Order Details
// Copy the full po_details.php code from previous messages
?>') . "</p>";

echo "<p>" . createFile('po_pdf.php', '<?php
// Purchase Order PDF
// Copy the full po_pdf.php code from previous messages
?>') . "</p>";

echo "<p>" . createFile('po_receive.php', '<?php
// Receive Purchase Order
// Copy the full po_receive.php code from previous messages
?>') . "</p>";

// Stock Transfer Files
echo "<h2>🔄 Stock Transfer Files</h2>";
echo "<p>" . createFile('transfers.php', '<?php
// Stock Transfers Management
// Copy the full transfers.php code from previous messages
?>') . "</p>";

echo "<p>" . createFile('transfer_details.php', '<?php
// Transfer Details
// Copy the full transfer_details.php code from previous messages
?>') . "</p>";

echo "<p>" . createFile('transfer_pdf.php', '<?php
// Transfer PDF
// Copy the full transfer_pdf.php code from previous messages
?>') . "</p>";

echo "<p>" . createFile('transfer_history.php', '<?php
// Transfer History Component
// Copy the full transfer_history.php code from previous messages
?>') . "</p>";

echo "<p>" . createFile('approve_transfer.php', '<?php
// Approve Transfer
// Copy the full approve_transfer.php code from previous messages
?>') . "</p>";

echo "<p>" . createFile('receive_transfer.php', '<?php
// Receive Transfer
// Copy the full receive_transfer.php code from previous messages
?>') . "</p>";

echo "<p>" . createFile('ship_transfer.php', '<?php
// Ship Transfer
// Copy the full ship_transfer.php code from previous messages
?>') . "</p>";

echo "<hr>
<p><strong>Next Steps:</strong></p>
<ol>
    <li>Open each newly created file</li>
    <li>Replace the placeholder code with the actual code from the previous messages</li>
    <li>Run the database update SQL</li>
    <li>Refresh the navigation page</li>
</ol>

<p><a href='diagnose_navigation.php' style='background: #4361ee; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Back to Diagnostic</a></p>";

echo "</div></body></html>";
?>