<?php
session_start();
require_once 'config/database.php';
require_once 'check_access.php';
checkAdmin();

$database = new Database();
$db = $database->getConnection();

$month = $_GET['month'] ?? date('Y-m');
$year = date('Y', strtotime($month));
$month_num = date('m', strtotime($month));

// Get monthly tax summary
$stmt = $db->prepare("SELECT 
    DATE_FORMAT(s.sale_date, '%Y-%m-%d') as day,
    COUNT(DISTINCT s.id) as transactions,
    COALESCE(SUM(tt.subtotal), 0) as daily_sales,
    COALESCE(SUM(tt.tax_amount), 0) as daily_tax,
    COALESCE(SUM(tt.total_with_tax), 0) as daily_total
    FROM sales s
    LEFT JOIN tax_transactions tt ON s.id = tt.sale_id
    WHERE MONTH(s.sale_date) = ? AND YEAR(s.sale_date) = ?
    GROUP BY s.sale_date
    ORDER BY s.sale_date DESC");
$stmt->execute([$month_num, $year]);
$daily_tax = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Calculate totals
$total_sales = array_sum(array_column($daily_tax, 'daily_sales'));
$total_tax = array_sum(array_column($daily_tax, 'daily_tax'));
$total_with_tax = array_sum(array_column($daily_tax, 'daily_total'));

// Tax by product category
$stmt = $db->prepare("SELECT 
    c.name as category,
    COUNT(*) as items,
    COALESCE(SUM(tt.tax_amount), 0) as tax_collected
    FROM tax_transactions tt
    JOIN products p ON tt.product_id = p.id
    JOIN categories c ON p.category_id = c.id
    JOIN sales s ON tt.sale_id = s.id
    WHERE MONTH(s.sale_date) = ? AND YEAR(s.sale_date) = ?
    GROUP BY c.id
    ORDER BY tax_collected DESC");
$stmt->execute([$month_num, $year]);
$tax_by_category = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Tax Reports - Theophile POS</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar (same as before) -->
        
<!-- SIDEBAR - NEW VERSION WITH ALL MENU ITEMS -->
<div class="sidebar">
    <div class="logo">
        <h2><i class="fas fa-cash-register"></i> Theophile</h2>
    </div>
    
    <!-- User Info -->
    <div class="user-info">
        <?php 
        if($_SESSION['role'] === 'admin') {
            echo '<span class="role-badge role-admin"><i class="fas fa-crown"></i> ADMIN</span>';
        } else {
            echo '<span class="role-badge role-cashier"><i class="fas fa-user"></i> CASHIER</span>';
        }
        ?>
        <p><i class="fas fa-user"></i> <?php echo htmlspecialchars($_SESSION['full_name']); ?></p>
        <p><i class="fas fa-building"></i> Branch: 
            <?php
            // Get user's branch
            if(isset($db)) {
                $branch_stmt = $db->prepare("SELECT branch_name FROM branches WHERE id = ?");
                $branch_stmt->execute([$_SESSION['branch_id'] ?? 1]);
                $user_branch = $branch_stmt->fetchColumn();
                echo $user_branch ?: 'Headquarters';
            } else {
                echo 'All Branches';
            }
            ?>
        </p>
    </div>
    
    <!-- Navigation Links -->
    <ul class="nav-links">
        <!-- DASHBOARD -->
        <li>
            <a href="index.php" <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-home"></i> <span>Dashboard</span>
            </a>
        </li>
        
        <!-- PRODUCTS -->
        <li>
            <a href="products.php" <?php echo basename($_SERVER['PHP_SELF']) == 'products.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-box"></i> <span>Products</span>
            </a>
        </li>
        
        <!-- ADMIN ONLY SECTION -->
        <?php if($_SESSION['role'] === 'admin'): ?>
        
        <!-- ===== BRANCH MANAGEMENT ===== -->
        <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
            <span>🏢 BRANCH MANAGEMENT</span>
        </li>
        
        <li>
            <a href="branches.php" <?php echo basename($_SERVER['PHP_SELF']) == 'branches.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-building"></i> <span>Branches</span>
            </a>
        </li>
        
        <!-- ===== SUPPLIER MANAGEMENT ===== -->
        <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
            <span>🤝 SUPPLIER MANAGEMENT</span>
        </li>
        
        <li>
            <a href="suppliers.php" <?php echo basename($_SERVER['PHP_SELF']) == 'suppliers.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-truck"></i> <span>Suppliers</span>
            </a>
        </li>
        
        <li>
            <a href="purchase_orders.php" <?php echo basename($_SERVER['PHP_SELF']) == 'purchase_orders.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-file-invoice"></i> <span>Purchase Orders</span>
            </a>
        </li>
        
        <li>
            <a href="supplier_performance.php" <?php echo basename($_SERVER['PHP_SELF']) == 'supplier_performance.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-chart-line"></i> <span>Supplier Analytics</span>
            </a>
        </li>
        
        <!-- ===== STOCK TRANSFERS ===== -->
        <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
            <span>🔄 STOCK TRANSFERS</span>
        </li>
        
        <li>
            <a href="transfers.php" <?php echo basename($_SERVER['PHP_SELF']) == 'transfers.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-exchange-alt"></i> <span>All Transfers</span>
            </a>
        </li>
        
        <!-- ===== REPORTS ===== -->
        <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
            <span>📊 REPORTS</span>
        </li>
        
        <li>
            <a href="reports.php" <?php echo basename($_SERVER['PHP_SELF']) == 'reports.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-chart-bar"></i> <span>Sales Reports</span>
            </a>
        </li>
        
        <li>
            <a href="tax_reports.php" <?php echo basename($_SERVER['PHP_SELF']) == 'tax_reports.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-percent"></i> <span>Tax Reports</span>
            </a>
        </li>
        
        <li>
            <a href="business_intelligence.php" <?php echo basename($_SERVER['PHP_SELF']) == 'business_intelligence.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-chart-line"></i> <span>Business IQ</span>
            </a>
        </li>
        
        <!-- ===== HR MANAGEMENT ===== -->
        <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
            <span>👥 HR MANAGEMENT</span>
        </li>
        
        <li>
            <a href="employees.php" <?php echo basename($_SERVER['PHP_SELF']) == 'employees.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-users"></i> <span>Employees</span>
            </a>
        </li>
        
        <li>
            <a href="attendance.php" <?php echo basename($_SERVER['PHP_SELF']) == 'attendance.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-clock"></i> <span>Attendance</span>
            </a>
        </li>
        
        <li>
            <a href="payroll.php" <?php echo basename($_SERVER['PHP_SELF']) == 'payroll.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-wallet"></i> <span>Payroll</span>
            </a>
        </li>
        
        <!-- ===== SYSTEM ===== -->
        <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
            <span>⚙️ SYSTEM</span>
        </li>
        
        <li>
            <a href="users.php" <?php echo basename($_SERVER['PHP_SELF']) == 'users.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-users-cog"></i> <span>Users</span>
            </a>
        </li>
        
        <?php endif; ?> <!-- End Admin Only -->
        
        <!-- LOGOUT - Always visible -->
        <li style="margin-top: auto; border-top: 1px solid rgba(255,255,255,0.1); padding-top: 10px;">
            <a href="logout.php">
                <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
            </a>
        </li>
    </ul>
</div>
        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1><i class="fas fa-percent"></i> Tax Reports</h1>
                <div class="date">
                    <i class="fas fa-calendar-alt"></i> 
                    <?php echo date('F Y', strtotime($month)); ?>
                </div>
            </div>

            <!-- Month Selector -->
            <div class="card">
                <form method="GET" class="grid-2" style="align-items: center;">
                    <div class="form-group">
                        <label><i class="fas fa-calendar"></i> Select Month</label>
                        <input type="month" name="month" class="form-control" value="<?php echo $month; ?>">
                    </div>
                    <button type="submit" class="btn" style="margin-top: 24px;">
                        <i class="fas fa-filter"></i> Generate Report
                    </button>
                </form>
            </div>

            <!-- Tax Summary Cards -->
            <div class="stats-container">
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-shopping-cart"></i></div>
                    <div class="stat-info">
                        <h3>Total Sales (excl. Tax)</h3>
                        <p><?php echo number_format($total_sales); ?> RWF</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon" style="background: var(--warning);"><i class="fas fa-percent"></i></div>
                    <div class="stat-info">
                        <h3>Total Tax Collected</h3>
                        <p style="color: var(--warning);"><?php echo number_format($total_tax); ?> RWF</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon" style="background: var(--success);"><i class="fas fa-hand-holding-usd"></i></div>
                    <div class="stat-info">
                        <h3>Total with Tax</h3>
                        <p><?php echo number_format($total_with_tax); ?> RWF</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon" style="background: var(--danger);"><i class="fas fa-chart-line"></i></div>
                    <div class="stat-info">
                        <h3>Avg Daily Tax</h3>
                        <p><?php echo count($daily_tax) ? number_format($total_tax / count($daily_tax)) : 0; ?> RWF</p>
                    </div>
                </div>
            </div>

            <!-- Tax Charts -->
            <div class="grid-2">
                <!-- Tax by Category -->
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-chart-pie"></i> Tax by Category</h3>
                    </div>
                    <div class="chart-container" style="height: 300px;">
                        <canvas id="categoryTaxChart"></canvas>
                    </div>
                </div>

                <!-- Daily Tax Trend -->
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-chart-line"></i> Daily Tax Collection</h3>
                    </div>
                    <div class="chart-container" style="height: 300px;">
                        <canvas id="dailyTaxChart"></canvas>
                    </div>
                </div>
            </div>

            <!-- Daily Tax Table -->
            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-table"></i> Daily Tax Breakdown</h3>
                    <button onclick="exportToExcel()" class="btn-small" style="background: var(--success);">
                        <i class="fas fa-file-excel"></i> Export
                    </button>
                </div>
                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Transactions</th>
                                <th>Sales (excl. Tax)</th>
                                <th>Tax Collected</th>
                                <th>Total with Tax</th>
                                <th>Effective Tax Rate</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($daily_tax as $day): ?>
                            <tr>
                                <td><strong><?php echo date('d M Y', strtotime($day['day'])); ?></strong></td>
                                <td><?php echo $day['transactions']; ?></td>
                                <td><?php echo number_format($day['daily_sales']); ?> RWF</td>
                                <td style="color: var(--warning); font-weight: bold;"><?php echo number_format($day['daily_tax']); ?> RWF</td>
                                <td><?php echo number_format($day['daily_total']); ?> RWF</td>
                                <td>
                                    <?php 
                                    $rate = $day['daily_sales'] > 0 ? round(($day['daily_tax'] / $day['daily_sales']) * 100, 2) : 0;
                                    echo $rate . '%';
                                    ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                        <tfoot>
                            <tr style="background: #f8f9fa; font-weight: bold;">
                                <td>Total</td>
                                <td><?php echo array_sum(array_column($daily_tax, 'transactions')); ?></td>
                                <td><?php echo number_format($total_sales); ?> RWF</td>
                                <td style="color: var(--warning);"><?php echo number_format($total_tax); ?> RWF</td>
                                <td><?php echo number_format($total_with_tax); ?> RWF</td>
                                <td><?php echo $total_sales > 0 ? round(($total_tax / $total_sales) * 100, 2) : 0; ?>%</td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script>
    // Category Tax Chart
    new Chart(document.getElementById('categoryTaxChart'), {
        type: 'pie',
        data: {
            labels: [<?php foreach($tax_by_category as $cat) echo "'" . $cat['category'] . "',"; ?>],
            datasets: [{
                data: [<?php foreach($tax_by_category as $cat) echo $cat['tax_collected'] . ","; ?>],
                backgroundColor: [
                    '#4361ee', '#f72585', '#4cc9f0', '#f8961e', '#43aa8b'
                ]
            }]
        },
        options: {
            plugins: {
                legend: { position: 'bottom' },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            let value = context.raw;
                            let total = context.dataset.data.reduce((a,b) => a + b, 0);
                            let percentage = ((value / total) * 100).toFixed(1);
                            return context.label + ': ' + value.toLocaleString() + ' RWF (' + percentage + '%)';
                        }
                    }
                }
            }
        }
    });

    // Daily Tax Chart
    new Chart(document.getElementById('dailyTaxChart'), {
        type: 'line',
        data: {
            labels: [<?php foreach($daily_tax as $day) echo "'" . date('d M', strtotime($day['day'])) . "',"; ?>],
            datasets: [{
                label: 'Tax Collected',
                data: [<?php foreach($daily_tax as $day) echo $day['daily_tax'] . ","; ?>],
                borderColor: '#f8961e',
                backgroundColor: 'rgba(248,150,30,0.1)',
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            plugins: {
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return 'Tax: ' + context.parsed.y.toLocaleString() + ' RWF';
                        }
                    }
                }
            }
        }
    });

    function exportToExcel() {
        window.location.href = 'export_tax_report.php?month=<?php echo $month; ?>';
    }
    </script>
</body>
</html>