<?php
session_start();
require_once 'config/database.php';
require_once 'check_access.php';

if(!isset($_SESSION['user_id'])) { 
    header('Location: login.php'); 
    exit(); 
}

// Only admin can access supplier performance
if($_SESSION['role'] !== 'admin') {
    $_SESSION['error'] = "⛔ Access Denied! Admin only.";
    header('Location: index.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();

// Get supplier performance metrics
$suppliers = $db->query("SELECT 
    s.*,
    COUNT(po.id) as order_count,
    COALESCE(SUM(po.total_amount),0) as total_spent,
    AVG(DATEDIFF(po.expected_date, po.order_date)) as avg_lead_time,
    MAX(po.order_date) as last_order,
    MIN(po.order_date) as first_order
    FROM suppliers s
    LEFT JOIN purchase_orders po ON s.id = po.supplier_id
    GROUP BY s.id
    ORDER BY total_spent DESC")->fetchAll(PDO::FETCH_ASSOC);

// Calculate overall statistics
$total_suppliers = count($suppliers);
$total_orders = array_sum(array_column($suppliers, 'order_count'));
$total_spent_all = array_sum(array_column($suppliers, 'total_spent'));
$avg_lead_time_all = $total_orders > 0 ? array_sum(array_column($suppliers, 'avg_lead_time')) / $total_suppliers : 0;

// Get monthly spending trend
$monthly = $db->query("SELECT 
    DATE_FORMAT(order_date, '%Y-%m') as month,
    COUNT(*) as orders,
    SUM(total_amount) as spent
    FROM purchase_orders
    WHERE order_date >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
    GROUP BY DATE_FORMAT(order_date, '%Y-%m')
    ORDER BY month DESC")->fetchAll(PDO::FETCH_ASSOC);

// Get top products by supplier
$top_products = $db->query("SELECT 
    p.name as product_name,
    s.company_name as supplier,
    COUNT(poi.id) as times_ordered,
    SUM(poi.quantity) as total_quantity,
    SUM(poi.total_price) as total_value
    FROM po_items poi
    JOIN purchase_orders po ON poi.po_id = po.id
    JOIN products p ON poi.product_id = p.id
    JOIN suppliers s ON po.supplier_id = s.id
    GROUP BY p.id, s.id
    ORDER BY total_value DESC
    LIMIT 10")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Theophile POS - Supplier Performance</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .performance-card {
            background: white;
            border-radius: 15px;
            padding: 1.5rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            height: 100%;
        }
        .performance-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
        }
        .rating-stars {
            color: #ffc107;
            font-size: 0.9rem;
        }
        .supplier-badge {
            display: inline-block;
            padding: 3px 10px;
            border-radius: 15px;
            font-size: 0.8rem;
            font-weight: bold;
        }
        .badge-excellent { background: #d4edda; color: #155724; }
        .badge-good { background: #cce5ff; color: #004085; }
        .badge-average { background: #fff3cd; color: #856404; }
        .badge-poor { background: #f8d7da; color: #721c24; }
        .metric-value {
            font-size: 1.8rem;
            font-weight: bold;
            color: var(--primary);
        }
        .metric-label {
            font-size: 0.9rem;
            color: #666;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .trend-up { color: var(--success); }
        .trend-down { color: var(--danger); }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- ==================== UPDATED SIDEBAR ==================== -->
        <div class="sidebar">
            <div class="logo">
                <h2><i class="fas fa-cash-register"></i> Theophile</h2>
            </div>
            
            <!-- User Info -->
            <div class="user-info">
                <?php 
                if($_SESSION['role'] === 'admin') {
                    echo '<span class="role-badge role-admin"><i class="fas fa-crown"></i> ADMIN</span>';
                } else {
                    echo '<span class="role-badge role-cashier"><i class="fas fa-user"></i> CASHIER</span>';
                }
                ?>
                <p><i class="fas fa-user"></i> <?php echo htmlspecialchars($_SESSION['full_name']); ?></p>
                <p><i class="fas fa-building"></i> Branch: 
                    <?php
                    // Get user's branch
                    $branch_stmt = $db->prepare("SELECT branch_name FROM branches WHERE id = ?");
                    $branch_stmt->execute([$_SESSION['branch_id'] ?? 1]);
                    $user_branch = $branch_stmt->fetchColumn();
                    echo $user_branch ?: 'Headquarters';
                    ?>
                </p>
            </div>
            
            <!-- Navigation Links -->
            <ul class="nav-links">
                <!-- DASHBOARD -->
                <li>
                    <a href="index.php">
                        <i class="fas fa-home"></i> <span>Dashboard</span>
                    </a>
                </li>
                
                <!-- PRODUCTS -->
                <li>
                    <a href="products.php">
                        <i class="fas fa-box"></i> <span>Products</span>
                    </a>
                </li>
                
                <!-- ADMIN ONLY SECTION -->
                <?php if($_SESSION['role'] === 'admin'): ?>
                
                <!-- ===== BRANCH MANAGEMENT ===== -->
                <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
                    <span>🏢 BRANCH MANAGEMENT</span>
                </li>
                
                <li>
                    <a href="branches.php">
                        <i class="fas fa-building"></i> <span>Branches</span>
                    </a>
                </li>
                
                <!-- ===== SUPPLIER MANAGEMENT ===== -->
                <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
                    <span>🤝 SUPPLIER MANAGEMENT</span>
                </li>
                
                <li>
                    <a href="suppliers.php">
                        <i class="fas fa-truck"></i> <span>Suppliers</span>
                    </a>
                </li>
                
                <li>
                    <a href="purchase_orders.php">
                        <i class="fas fa-file-invoice"></i> <span>Purchase Orders</span>
                    </a>
                </li>
                
                <li>
                    <a href="supplier_performance.php" class="active">
                        <i class="fas fa-chart-line"></i> <span>Supplier Analytics</span>
                    </a>
                </li>
                
                <!-- ===== STOCK TRANSFERS ===== -->
                <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
                    <span>🔄 STOCK TRANSFERS</span>
                </li>
                
                <li>
                    <a href="transfers.php">
                        <i class="fas fa-exchange-alt"></i> <span>All Transfers</span>
                    </a>
                </li>
                
                <!-- ===== REPORTS ===== -->
                <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
                    <span>📊 REPORTS</span>
                </li>
                
                <li>
                    <a href="reports.php">
                        <i class="fas fa-chart-bar"></i> <span>Sales Reports</span>
                    </a>
                </li>
                
                <li>
                    <a href="tax_reports.php">
                        <i class="fas fa-percent"></i> <span>Tax Reports</span>
                    </a>
                </li>
                
                <li>
                    <a href="business_intelligence.php">
                        <i class="fas fa-chart-line"></i> <span>Business IQ</span>
                    </a>
                </li>
                
                <!-- ===== HR MANAGEMENT ===== -->
                <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
                    <span>👥 HR MANAGEMENT</span>
                </li>
                
                <li>
                    <a href="employees.php">
                        <i class="fas fa-users"></i> <span>Employees</span>
                    </a>
                </li>
                
                <li>
                    <a href="attendance.php">
                        <i class="fas fa-clock"></i> <span>Attendance</span>
                    </a>
                </li>
                
                <li>
                    <a href="payroll.php">
                        <i class="fas fa-wallet"></i> <span>Payroll</span>
                    </a>
                </li>
                
                <!-- ===== SYSTEM ===== -->
                <li style="margin: 10px 0 5px 0; font-size: 0.8rem; color: #999; text-transform: uppercase; letter-spacing: 1px;">
                    <span>⚙️ SYSTEM</span>
                </li>
                
                <li>
                    <a href="users.php">
                        <i class="fas fa-users-cog"></i> <span>Users</span>
                    </a>
                </li>
                
                <?php endif; ?> <!-- End Admin Only -->
                
                <!-- LOGOUT - Always visible -->
                <li style="margin-top: auto; border-top: 1px solid rgba(255,255,255,0.1); padding-top: 10px;">
                    <a href="logout.php">
                        <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
                    </a>
                </li>
            </ul>
        </div>
        <!-- ==================== END SIDEBAR ==================== -->

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1><i class="fas fa-chart-line"></i> Supplier Performance Analytics</h1>
                <div class="date">
                    <i class="fas fa-calendar-alt"></i> <?php echo date('l, F j, Y'); ?>
                </div>
            </div>

            <?php if(isset($_SESSION['success'])): ?>
            <div class="notification notification-success show"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
            <?php endif; ?>

            <?php if(isset($_SESSION['error'])): ?>
            <div class="notification notification-error show"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
            <?php endif; ?>

            <!-- Summary Cards -->
            <div class="stats-container">
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-truck"></i></div>
                    <div class="stat-info">
                        <h3>Total Suppliers</h3>
                        <p><?php echo $total_suppliers; ?></p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-shopping-cart"></i></div>
                    <div class="stat-info">
                        <h3>Total Orders</h3>
                        <p><?php echo $total_orders; ?></p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-money-bill-wave"></i></div>
                    <div class="stat-info">
                        <h3>Total Spent</h3>
                        <p><?php echo number_format($total_spent_all); ?> RWF</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-clock"></i></div>
                    <div class="stat-info">
                        <h3>Avg Lead Time</h3>
                        <p><?php echo round($avg_lead_time_all); ?> days</p>
                    </div>
                </div>
            </div>

            <!-- Charts Row -->
            <div class="grid-2">
                <!-- Monthly Spending Chart -->
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-chart-bar"></i> Monthly Spending (12 Months)</h3>
                    </div>
                    <div class="chart-container" style="height: 300px;">
                        <canvas id="monthlyChart"></canvas>
                    </div>
                </div>

                <!-- Top Products Chart -->
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-chart-pie"></i> Top Products by Supplier</h3>
                    </div>
                    <div class="chart-container" style="height: 300px;">
                        <canvas id="productsChart"></canvas>
                    </div>
                </div>
            </div>

            <!-- Supplier Performance Table -->
            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-list"></i> Supplier Performance Details</h3>
                    <div style="display: flex; gap: 10px;">
                        <input type="text" id="searchInput" class="form-control" placeholder="Search suppliers..." style="width: 250px;">
                        <select id="sortSelect" class="form-control" style="width: 150px;" onchange="sortTable()">
                            <option value="spent">Sort by Spent</option>
                            <option value="orders">Sort by Orders</option>
                            <option value="rating">Sort by Rating</option>
                            <option value="name">Sort by Name</option>
                        </select>
                    </div>
                </div>

                <div class="table-container">
                    <table id="supplierTable">
                        <thead>
                            <tr>
                                <th>Supplier</th>
                                <th>Contact</th>
                                <th>Orders</th>
                                <th>Total Spent</th>
                                <th>Avg Order</th>
                                <th>Lead Time</th>
                                <th>Last Order</th>
                                <th>Rating</th>
                                <th>Performance</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($suppliers as $s): 
                                $avg_order = $s['order_count'] > 0 ? $s['total_spent'] / $s['order_count'] : 0;
                                
                                // Determine performance badge
                                if($s['rating'] >= 4.5) $badge = 'badge-excellent';
                                elseif($s['rating'] >= 3.5) $badge = 'badge-good';
                                elseif($s['rating'] >= 2.5) $badge = 'badge-average';
                                else $badge = 'badge-poor';
                                
                                $performance = $s['rating'] >= 4 ? 'Excellent' : ($s['rating'] >= 3 ? 'Good' : ($s['rating'] >= 2 ? 'Average' : 'Poor'));
                            ?>
                            <tr>
                                <td>
                                    <strong><?php echo htmlspecialchars($s['company_name']); ?></strong><br>
                                    <small><?php echo $s['supplier_code']; ?></small>
                                </td>
                                <td>
                                    <?php echo htmlspecialchars($s['contact_person']); ?><br>
                                    <small><?php echo $s['phone']; ?></small>
                                </td>
                                <td class="metric-value" style="font-size: 1.2rem;"><?php echo $s['order_count']; ?></td>
                                <td><strong><?php echo number_format($s['total_spent']); ?> RWF</strong></td>
                                <td><?php echo number_format($avg_order); ?> RWF</td>
                                <td><?php echo round($s['avg_lead_time']); ?> days</td>
                                <td><?php echo $s['last_order'] ? date('d/m/Y', strtotime($s['last_order'])) : 'Never'; ?></td>
                                <td>
                                    <div class="rating-stars">
                                        <?php for($i=1; $i<=5; $i++): ?>
                                            <?php if($i <= $s['rating']): ?>
                                                <i class="fas fa-star"></i>
                                            <?php elseif($i - 0.5 <= $s['rating']): ?>
                                                <i class="fas fa-star-half-alt"></i>
                                            <?php else: ?>
                                                <i class="far fa-star"></i>
                                            <?php endif; ?>
                                        <?php endfor; ?>
                                        <br><small><?php echo $s['rating']; ?>/5</small>
                                    </div>
                                </td>
                                <td>
                                    <span class="supplier-badge <?php echo $badge; ?>"><?php echo $performance; ?></span>
                                </td>
                                <td>
                                    <div style="display: flex; gap: 5px;">
                                        <a href="supplier_report_pdf.php?id=<?php echo $s['id']; ?>" class="btn-small" style="background: var(--success);" title="Download PDF">
                                            <i class="fas fa-file-pdf"></i>
                                        </a>
                                        <a href="purchase_orders.php?supplier=<?php echo $s['id']; ?>" class="btn-small" style="background: var(--primary);" title="View Orders">
                                            <i class="fas fa-file-invoice"></i>
                                        </a>
                                        <a href="suppliers.php?edit=<?php echo $s['id']; ?>" class="btn-small" style="background: var(--warning);" title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Top Products Table -->
            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-crown"></i> Top Products by Supplier</h3>
                </div>
                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Supplier</th>
                                <th>Times Ordered</th>
                                <th>Total Quantity</th>
                                <th>Total Value</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($top_products as $tp): ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($tp['product_name']); ?></strong></td>
                                <td><?php echo htmlspecialchars($tp['supplier']); ?></td>
                                <td><?php echo $tp['times_ordered']; ?></td>
                                <td><?php echo $tp['total_quantity']; ?></td>
                                <td><?php echo number_format($tp['total_value']); ?> RWF</td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Export Buttons -->
            <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px;">
                <button onclick="exportToExcel()" class="btn-small" style="background: var(--success);">
                    <i class="fas fa-file-excel"></i> Export to Excel
                </button>
                <button onclick="window.print()" class="btn-small" style="background: var(--primary);">
                    <i class="fas fa-print"></i> Print Report
                </button>
            </div>
        </div>
    </div>

    <script src="assets/js/script.js"></script>
    <script>
        // Monthly Spending Chart
        new Chart(document.getElementById('monthlyChart'), {
            type: 'bar',
            data: {
                labels: [<?php foreach(array_reverse($monthly) as $m) echo "'" . date('M Y', strtotime($m['month'] . '-01')) . "',"; ?>],
                datasets: [{
                    label: 'Monthly Spending',
                    data: [<?php foreach(array_reverse($monthly) as $m) echo $m['spent'] . ","; ?>],
                    backgroundColor: '#4361ee',
                    borderRadius: 5
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return 'Spent: ' + context.parsed.y.toLocaleString() + ' RWF';
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        ticks: {
                            callback: function(value) {
                                return value.toLocaleString() + ' RWF';
                            }
                        }
                    }
                }
            }
        });

        // Top Products Chart
        new Chart(document.getElementById('productsChart'), {
            type: 'doughnut',
            data: {
                labels: [<?php foreach($top_products as $tp) echo "'" . addslashes($tp['product_name']) . "',"; ?>],
                datasets: [{
                    data: [<?php foreach($top_products as $tp) echo $tp['total_value'] . ","; ?>],
                    backgroundColor: [
                        '#4361ee', '#f72585', '#4cc9f0', '#f8961e', '#43aa8b',
                        '#3f37c9', '#b5179e', '#4895ef', '#560bad', '#f15bb5'
                    ]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: { boxWidth: 12 }
                    }
                }
            }
        });

        // Search functionality
        document.getElementById('searchInput').addEventListener('keyup', function() {
            let searchText = this.value.toLowerCase();
            let rows = document.querySelectorAll('#supplierTable tbody tr');
            
            rows.forEach(row => {
                let text = row.textContent.toLowerCase();
                row.style.display = text.includes(searchText) ? '' : 'none';
            });
        });

        // Sort table
        function sortTable() {
            let sortBy = document.getElementById('sortSelect').value;
            let tbody = document.querySelector('#supplierTable tbody');
            let rows = Array.from(tbody.querySelectorAll('tr'));
            
            rows.sort((a, b) => {
                let aVal, bVal;
                
                switch(sortBy) {
                    case 'spent':
                        aVal = parseFloat(a.cells[3].textContent.replace(/[^0-9]/g, ''));
                        bVal = parseFloat(b.cells[3].textContent.replace(/[^0-9]/g, ''));
                        return bVal - aVal;
                    case 'orders':
                        aVal = parseInt(a.cells[2].textContent);
                        bVal = parseInt(b.cells[2].textContent);
                        return bVal - aVal;
                    case 'rating':
                        aVal = parseFloat(a.cells[7].textContent);
                        bVal = parseFloat(b.cells[7].textContent);
                        return bVal - aVal;
                    case 'name':
                        aVal = a.cells[0].textContent;
                        bVal = b.cells[0].textContent;
                        return aVal.localeCompare(bVal);
                }
            });
            
            tbody.innerHTML = '';
            rows.forEach(row => tbody.appendChild(row));
        }

        // Export to Excel
        function exportToExcel() {
            let table = document.getElementById('supplierTable');
            let html = table.outerHTML;
            let url = 'data:application/vnd.ms-excel,' + encodeURIComponent(html);
            let link = document.createElement('a');
            link.href = url;
            link.download = 'supplier_performance.xls';
            link.click();
        }

        // Auto-hide notifications
        setTimeout(() => {
            document.querySelectorAll('.notification').forEach(n => n.classList.remove('show'));
        }, 3000);
    </script>
</body>
</html>