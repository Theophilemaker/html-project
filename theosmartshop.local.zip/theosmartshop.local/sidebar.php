<?php

require_once 'check_access.php';
$menu_items = getSidebarMenu();
$current_page = basename($_SERVER['PHP_SELF']);
?>
<div class="sidebar">
    <div class="logo">
        <h2>Theophile POS</h2>
        <div class="user-info">
            <?php echo getRoleBadge($_SESSION['role']); ?>
            <p class="user-name">
                <i class="fas fa-user-circle"></i> 
                <?php echo htmlspecialchars($_SESSION['full_name']); ?>
            </p>
        </div>
    </div>
    <ul class="nav-links">
        <?php foreach($menu_items as $item): ?>
            <?php if(in_array($_SESSION['role'], $item['roles'])): ?>
            <li>
                <a href="<?php echo $item['url']; ?>" 
                   class="<?php echo ($current_page == $item['url']) ? 'active' : ''; ?>">
                    <i class="fas fa-<?php echo $item['icon']; ?>"></i>
                    <span><?php echo $item['label']; ?></span>
                </a>
            </li>
            <?php endif; ?>
        <?php endforeach; ?>
    </ul>
    
    <?php if(isCashier()): ?>
    <div class="cashier-info">
        <i class="fas fa-info-circle"></i>
        <small>You are logged in as Cashier. Some features are limited.</small>
    </div>
    <?php endif; ?>
</div>