<?php
// Add to config/database.php or create new security.php

class Security {
    
    // CSRF Protection
    public static function generateCSRFToken() {
        if(!isset($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }
    
    public static function verifyCSRFToken($token) {
        if(!isset($_SESSION['csrf_token']) || $token !== $_SESSION['csrf_token']) {
            die('CSRF validation failed');
        }
        return true;
    }
    
    // Rate Limiting
    public static function checkRateLimit($action, $max_attempts = 5, $time_window = 300) {
        $key = 'rate_limit_' . $action . '_' . $_SERVER['REMOTE_ADDR'];
        $attempts = isset($_SESSION[$key]) ? $_SESSION[$key] : ['count' => 0, 'first_attempt' => time()];
        
        if(time() - $attempts['first_attempt'] > $time_window) {
            $attempts = ['count' => 1, 'first_attempt' => time()];
        } else {
            $attempts['count']++;
        }
        
        $_SESSION[$key] = $attempts;
        
        if($attempts['count'] > $max_attempts) {
            http_response_code(429);
            die('Too many attempts. Please try again later.');
        }
    }
    
    // Input Sanitization
    public static function sanitize($input) {
        return htmlspecialchars(strip_tags(trim($input)));
    }
    
    // Password Hashing (use this instead of MD5)
    public static function hashPassword($password) {
        return password_hash($password, PASSWORD_BCRYPT);
    }
    
    public static function verifyPassword($password, $hash) {
        return password_verify($password, $hash);
    }
    
    // Session Security
    public static function secureSession() {
        ini_set('session.cookie_httponly', 1);
        ini_set('session.use_only_cookies', 1);
        ini_set('session.cookie_secure', 1);
        
        session_regenerate_id(true);
    }
    
    // Audit Log
    public static function logAction($db, $user_id, $action, $details = '') {
        $stmt = $db->prepare("INSERT INTO audit_logs (user_id, action, details, ip_address, user_agent) VALUES (?,?,?,?,?)");
        $stmt->execute([$user_id, $action, $details, $_SERVER['REMOTE_ADDR'], $_SERVER['HTTP_USER_AGENT']]);
    }
}

// Add audit logs table
$audit_table = "
CREATE TABLE IF NOT EXISTS audit_logs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    action VARCHAR(255),
    details TEXT,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
)";
$db->exec($audit_table);