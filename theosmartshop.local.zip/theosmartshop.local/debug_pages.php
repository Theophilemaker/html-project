<?php
echo "<h1>🔍 Theophile POS - Page Debugger</h1>";

$base_path = __DIR__;
echo "<p><strong>Current Directory:</strong> " . $base_path . "</p>";

$pages_to_check = [
    'branches.php',
    'suppliers.php',
    'purchase_orders.php',
    'transfers.php',
    'check_access.php',
    'config/database.php'
];

echo "<h2>📁 File Check:</h2>";
echo "<table border='1' cellpadding='8' style='border-collapse: collapse;'>";
echo "<tr><th>File</th><th>Status</th><th>Size</th><th>Last Modified</th></tr>";

foreach($pages_to_check as $page) {
    $file_path = $base_path . '/' . $page;
    if(file_exists($file_path)) {
        $size = filesize($file_path);
        $modified = date("Y-m-d H:i:s", filemtime($file_path));
        echo "<tr style='background: #d4edda;'>";
        echo "<td>$page</td>";
        echo "<td style='color:green;'>✅ EXISTS</td>";
        echo "<td>$size bytes</td>";
        echo "<td>$modified</td>";
    } else {
        echo "<tr style='background: #f8d7da;'>";
        echo "<td>$page</td>";
        echo "<td style='color:red;'>❌ MISSING</td>";
        echo "<td>-</td>";
        echo "<td>-</td>";
    }
    echo "</tr>";
}
echo "</table>";

// Check PHP syntax in each file
echo "<h2>🔧 PHP Syntax Check:</h2>";
foreach(['branches.php', 'suppliers.php', 'purchase_orders.php', 'transfers.php'] as $page) {
    $file_path = $base_path . '/' . $page;
    if(file_exists($file_path)) {
        echo "<h3>$page</h3>";
        $content = file_get_contents($file_path);
        
        // Check for common errors
        $errors = [];
        
        // Check for opening PHP tag
        if(strpos($content, '<?php') === false) {
            $errors[] = "❌ Missing PHP opening tag <strong>&lt;?php</strong>";
        }
        
        // Check for closing tag issues
        if(substr_count($content, '?>') > 1) {
            $errors[] = "⚠️ Multiple PHP closing tags found";
        }
        
        // Check for syntax errors (basic)
        if(preg_match('/\b(require|include)_once\s*\(\s*[\'"]config\/database\.php[\'"]\s*\)/', $content) === 0) {
            $errors[] = "⚠️ May be missing database include";
        }
        
        if(empty($errors)) {
            echo "<p style='color:green;'>✅ Syntax looks okay</p>";
        } else {
            foreach($errors as $error) {
                echo "<p style='color:red;'>$error</p>";
            }
        }
    }
}

// Check database connection
echo "<h2>🗄️ Database Connection:</h2>";
try {
    require_once 'config/database.php';
    $database = new Database();
    $db = $database->getConnection();
    
    if($db) {
        echo "<p style='color:green;'>✅ Database connected successfully</p>";
        
        // Check if tables exist
        $tables = ['branches', 'suppliers', 'purchase_orders', 'stock_transfers'];
        foreach($tables as $table) {
            try {
                $result = $db->query("SELECT 1 FROM $table LIMIT 1");
                echo "<p style='color:green;'>✅ Table '$table' exists</p>";
            } catch(Exception $e) {
                echo "<p style='color:red;'>❌ Table '$table' missing - Run database update</p>";
            }
        }
    }
} catch(Exception $e) {
    echo "<p style='color:red;'>❌ Database connection failed: " . $e->getMessage() . "</p>";
}

// Check Apache error log location
echo "<h2>📋 Apache Error Log:</h2>";
echo "<p>Check WAMP logs at: <strong>C:\wamp64\logs\php_error.log</strong></p>";
echo "<p>Or click: <a href='http://localhost/?phpinfo=1' target='_blank'>Check PHP Info</a></p>";
?>